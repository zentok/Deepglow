# Deepglow art pass 2: beetle-style (dark chitin shell + glowing teal) tools/armor, gem ores, gem blocks, ingot, egg.
import random
from PIL import Image
OUT='/home/claude/dg/src/main/resources/assets/deepglow/textures/'
RP='/home/claude/rp1/assets/minecraft/textures/block/'
def hx(s): return tuple(int(s[i:i+2],16) for i in (1,3,5))+(255,)
L0=hx('#eafffb');L1=hx('#9ff7e8');L2=hx('#3fd3c1');L3=hx('#1a9a9a');L4=hx('#0e6670');L5=hx('#093a44')
K=hx('#070d12')   # outline
S0=hx('#1b1f29');S1=hx('#2a303d');S2=hx('#3a4254');S3=hx('#4e5870');S4=hx('#6a7590')  # chitin shell
def new(w=16,h=16): return Image.new('RGBA',(w,h),(0,0,0,0))
def P(im,pts,c):
    p=im.load()
    for x,y in pts:
        if 0<=x<im.width and 0<=y<im.height: p[x,y]=c
def outline(im,c=K):
    p=im.load(); w,h=im.size; add=[]
    for y in range(h):
        for x in range(w):
            if p[x,y][3]==0:
                for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                    X,Y=x+dx,y+dy
                    if 0<=X<w and 0<=Y<h and p[X,Y][3]>0 and p[X,Y]!=c: add.append((x,y)); break
    for x,y in add: p[x,y]=c
def grid(rows,key):
    im=new(); p=im.load()
    for y,r in enumerate(rows):
        for x,ch in enumerate(r):
            if ch in key: p[x,y]=key[ch]
    return im
KEY={'a':S0,'b':S1,'c':S2,'d':S3,'e':S4,'t':L2,'u':L1,'w':L0,'g':L3,'f':L4,'k':K,'h':hx('#262a35'),'i':hx('#3a4050'),'j':hx('#505872')}
# ---- tools: slim chitin handle with glowing bands + shell head ----
import math
def handle(im,a,b,bands=(0.35,0.7)):
    (x0,y0),(x1,y1)=a,b; n=max(abs(x1-x0),abs(y1-y0))
    for i in range(n+1):
        x=round(x0+(x1-x0)*i/n); y=round(y0+(y1-y0)*i/n)
        P(im,[(x,y)],hx('#3a4050')); P(im,[(x+1,y)],hx('#262a35'))
        for bnd in bands:
            if abs(i/n-bnd)<0.5/n+0.03: P(im,[(x,y)],L2); P(im,[(x+1,y)],L3)
    P(im,[(x0,y0),(x0+1,y0)],S0)
def headgrid(im,rows,ox=0,oy=0):
    for y,r in enumerate(rows):
        for x,ch in enumerate(r):
            if ch in KEY: P(im,[(x+ox,y+oy)],KEY[ch])
def tool_pick():
    im=new(); handle(im,(2,14),(11,5)); p=im.load()
    cx,cy=7.0,9.0
    for y in range(16):
        for x in range(16):
            dx,dy=x-cx,y-cy; r=math.hypot(dx,dy); th=math.degrees(math.atan2(dy,dx))
            if 5.0<=r<=7.0 and -118<=th<=22:
                t=(th+118)/140.0
                c=S3 if r<5.8 else S2
                if r>6.2: c=S1
                if t<0.12 or t>0.88: c=L2 if r<6.1 else L3      # glowing tips
                if t<0.06 or t>0.94: c=L1
                p[x,y]=c
    P(im,[(11,3),(12,3),(11,4)],L0); P(im,[(10,3),(11,2)],L2)
    outline(im); return im
def tool_axe():
    im=new(); handle(im,(2,14),(10,6))
    headgrid(im,[
"................",
"................",
"........kkkk....",
".......kdccbk...",
"......kdcbtbk...",
".....kdcbtwtk...",
"....kdcbbtgbk...",
"...kectbbbbbk...",
"..kutgkbbbbk....",
"..kgkk.kkkk.....",],0,0)
    outline(im); return im
def tool_shovel():
    im=new(); handle(im,(2,14),(10,6))
    headgrid(im,[
"................",
"...........kkk..",
"..........kdccbk",
".........kdcbtbk",
".........kcbtwtk",
".........kbbtgbk",
"..........kbtbk.",
"...........kbk.."],0,0)
    outline(im); return im
def tool_hoe():
    im=new(); handle(im,(2,14),(10,6))
    headgrid(im,[
"................",
"................",
"......kkkkkk....",
".....kdcccbbk...",
"....kdcbbtgbk...",
"....kutbk.kbk...",
"....kgkk........"],0,0)
    outline(im); return im
def tool_sword():
    im=new()
    for i in range(10):          # blade, 2px wide with glowing core
        x,y=5+i,10-i
        P(im,[(x,y)],S3); P(im,[(x+1,y)],S1); P(im,[(x,y-1)],S2)
        P(im,[(x+1,y-1)],L2 if i%4!=3 else L1)
    P(im,[(14,0),(15,0),(15,1)],L1); P(im,[(14,1)],L0)
    for k in range(-2,3): P(im,[(4+k,10-k-1+1)],S2)  # crossguard (diagonal)
    P(im,[(2,10),(3,11),(4,12),(5,13)] ,S3); P(im,[(6,8),(7,9),(8,10),(9,11)],S3)
    P(im,[(5,9),(4,10)],L2); P(im,[(6,10)],L2)
    handle(im,(3,13),(1,15),()); P(im,[(4,11),(3,12)],hx('#3a4050')); P(im,[(5,11),(4,12)],hx('#262a35'))
    P(im,[(0,15)],L2)
    outline(im); return im
for n,f in (('pickaxe',tool_pick),('axe',tool_axe),('shovel',tool_shovel),('hoe',tool_hoe),('sword',tool_sword)):
    f().save(OUT+'item/lumenite_%s.png'%n)
# ---- armor icons ----
def plate(spans,seams,glow,hi=None):
    im=new(); p=im.load()
    for y,lst in spans.items():
        for a,b in lst:
            for x in range(a,b+1):
                t=((x-2)/12.0)*0.55+((y-2)/12.0)*0.45
                p[x,y]=S4 if t<0.12 else S3 if t<0.3 else S2 if t<0.55 else S1 if t<0.8 else S0
    for pts,c in seams: P(im,pts,c)
    P(im,glow[0],L2); P(im,glow[1],L1); P(im,glow[2],L0)
    outline(im); return im
helm=plate({2:[(5,10)],3:[(4,11)],4:[(3,12)],5:[(3,12)],6:[(3,12)],7:[(3,12)],8:[(3,12)],9:[(3,5),(10,12)],10:[(3,5),(10,12)]},
    [([(x,6) for x in range(4,12)],S0),([(x,3) for x in range(5,11)],S3)],
    ([(4,7),(5,7),(10,7),(11,7),(7,3),(8,3)],[(5,7),(10,7),(7,4),(8,4)],[(7,2),(8,2)]))
P(helm,[(4,6),(5,6),(6,6),(9,6),(10,6),(11,6)],S0)
chest=plate({2:[(2,5),(10,13)],3:[(2,6),(9,13)],4:[(2,13)],5:[(3,12)],6:[(4,11)],7:[(4,11)],8:[(4,11)],9:[(4,11)],10:[(4,11)],11:[(4,11)],12:[(5,10)]},
    [([(x,6) for x in range(5,11)],S0),([(x,8) for x in range(5,11)],S0),([(x,10) for x in range(5,11)],S0),([(7,y) for y in range(4,12)],S0),([(8,y) for y in range(4,12)],S0)],
    ([(5,7),(6,7),(9,7),(10,7),(5,9),(10,9),(6,11),(9,11)],[(6,7),(9,7),(7,5),(8,5)],[(7,5),(8,5)]))
legs=plate({2:[(4,11)],3:[(4,11)],4:[(4,11)],5:[(4,11)],6:[(4,6),(9,11)],7:[(4,6),(9,11)],8:[(4,6),(9,11)],9:[(4,6),(9,11)],10:[(4,6),(9,11)],11:[(4,6),(9,11)],12:[(4,6),(9,11)]},
    [([(x,4) for x in range(4,12)],S0)],
    ([(5,3),(6,3),(9,3),(10,3),(5,8),(10,8),(5,11),(10,11)],[(6,3),(9,3),(5,8),(10,8)],[(7,3),(8,3)]))
boots=plate({6:[(3,6),(9,12)],7:[(3,6),(9,12)],8:[(3,6),(9,12)],9:[(3,6),(9,12)],10:[(2,6),(9,13)],11:[(2,6),(9,13)],12:[(2,6),(9,13)]},
    [([(x,8) for x in (3,4,5,6,9,10,11,12)],S0)],
    ([(3,9),(4,9),(11,9),(12,9),(2,12),(13,12)],[(3,9),(12,9)],[(5,11),(10,11)]))
for n,im in (('helmet',helm),('chestplate',chest),('leggings',legs),('boots',boots)): im.save(OUT+'item/lumenite_%s.png'%n)
# ---- ingot (faceted gem-metal bar) ----
ing=new(); p=ing.load()
rows={4:(6,13),5:(5,12),6:(4,11),7:(3,10)}
for y,(a,b) in rows.items():
    for x in range(a,b+1): p[x,y]=L0 if (y==4 and x<9) else L1 if y<6 else L2
for y in (8,9,10):
    for x in range(2,10): p[x,y]=L2 if y==8 else L3 if y==9 else L4
for y,(a,b) in {8:(10,12),9:(10,12),10:(10,11)}.items():
    pass
# right side face
for i,(x,y) in enumerate([(11,7),(11,8),(11,9),(11,10),(12,4),(12,5),(12,6),(12,7),(12,8),(12,9)]): p[x,y]=L3 if y<8 else L4
for (x,y) in [(13,4),(13,5),(13,6),(13,7),(12,8)]: p[x,y]=L4
# facet lines
P(ing,[(8,5),(7,6),(6,7),(5,8)],L2); P(ing,[(6,4),(7,4)],L0); P(ing,[(3,8),(4,8)],L1)
P(ing,[(9,9),(8,9)],L2)
outline(ing,L5); outline(ing,K) if False else None
ing.save(OUT+'item/lumenite_ingot.png')
# ---- spawn egg ----
egg=new(); p=egg.load()
import math
for y in range(16):
    for x in range(16):
        dx=(x-7.5)/5.0; dy=(y-8.2)/6.3
        # egg is slightly narrower at top
        if dy<0: dx*=1+0.25*(-dy)
        r=dx*dx+dy*dy
        if r<=1:
            p[x,y]=S1 if r>0.6 else S2
            if x+y<10 and r<0.55: p[x,y]=S3
# glowing spots like the beetle abdomen
for (x,y,c) in [(5,6,L2),(9,5,L1),(7,9,L2),(10,9,L3),(6,12,L3),(10,12,L2),(8,7,L3)]:
    P(egg,[(x,y),(x+1,y)],c); P(egg,[(x,y+1)],L4)
P(egg,[(5,6),(9,5),(7,9)],L1); P(egg,[(9,5)],L0)
P(egg,[(5,4),(6,3),(5,5)],S4)
outline(egg); egg.save(OUT+'item/glow_beetle_spawn_egg.png')
# ---- blocks: jewel style ----
def blk(fn):
    im=new(); p=im.load()
    for y in range(16):
        for x in range(16): p[x,y]=fn(x,y)
    return im
def jewel(x,y):
    dx=x-7.5; dy=y-7.5; c=max(abs(dx),abs(dy))
    if c>7: return L1 if (x<=y and dx<0 or dy<0 and abs(dx)<=abs(dy)) and not (dx>0 and dy>0) else L3
    if c>6: return L2
    if c>3.2:
        # four trapezoid facets
        if abs(dx)==abs(dy) or abs(abs(dx)-abs(dy))<0.5: return L0 if dx<0 or dy<0 else L4
        if abs(dy)>abs(dx): return L1 if dy<0 else L4
        return L2 if dx<0 else L3
    if c>2.2: return L4 if (dx>0 or dy>0) else L1
    return L0 if c<1.2 else L1
lum=blk(jewel)
P(lum,[(3,3),(12,3),(3,12),(12,12)],L0); P(lum,[(7,0),(8,0)],L0)
def pol(x,y):
    rnd=((x*7+y*13)%5==0)
    if y==0 or x==0: return L1
    if y==15 or x==15: return L5
    if y==1 or x==1: return L2
    if y==14 or x==14: return L4
    # inset panel
    if 4<=x<=11 and 4<=y<=11:
        if x==4 or y==4: return L4
        if x==11 or y==11: return L1
        return L2 if not ((x+y)%7==0) else L1
    return L3 if not rnd else L2
poli=blk(pol); P(poli,[(2,2),(13,2),(2,13),(13,13)],L0); P(poli,[(6,6),(7,6),(6,7)],L0)
random.seed(31)
def rawf(x,y): return random.choice([L5,L4,L4,L3,L5])
raw=blk(rawf)
CH=[(2,2),(9,1),(5,8),(11,9),(1,11),(8,12)]
for (cx,cy) in CH:
    for (dx,dy,c) in [(0,0,L1),(1,0,L2),(0,1,L2),(1,1,L3),(2,1,L4),(1,2,L4),(2,2,L5)]:
        P(raw,[(cx+dx,cy+dy)],c)
    P(raw,[(cx,cy)],L0)
raw.save(OUT+'block/raw_lumenite_block.png'); lum.save(OUT+'block/lumenite_block.png'); poli.save(OUT+'block/polished_lumenite.png')
# ---- ores: round gems between diamond and emerald ----
def ore(base_name,seed):
    im=Image.open(RP+base_name).convert('RGBA'); random.seed(seed)
    big=[(2,2),(9,3),(5,9),(11,10)]
    G=["efe.","futd","ftwd",".ddk"]
    cmap={'e':L3,'f':L4,'u':L1,'t':L2,'w':L0,'d':L3,'k':L5}
    for (bx,by) in big:
        for j,r in enumerate(G):
            for i,ch in enumerate(r):
                if ch in cmap: P(im,[(bx+i,by+j)],cmap[ch])
    # small gems
    for (sx,sy) in [(1,9),(13,5),(7,13),(7,1)]:
        P(im,[(sx,sy),(sx+1,sy)],L2); P(im,[(sx,sy+1)],L4); P(im,[(sx,sy)],L1)
    # diamond-like streaks
    for (sx,sy) in [(5,5),(13,13),(3,13),(14,1)]:
        P(im,[(sx,sy),(sx+1,sy)],L1)
    return im
ore('stone.png',1).save(OUT+'block/lumenite_ore.png'); ore('deepslate.png',2).save(OUT+'block/deepslate_lumenite_ore.png')
print('art2 ok')
# ---- armor layers (vanilla UV layout): chitin plates with glowing segment seams ----
def region(u,v,dx,dy,dz):
    return {'top':(u+dz,v,dx,dz),'bottom':(u+dz+dx,v,dx,dz),'west':(u,v+dz,dz,dy),'front':(u+dz,v+dz,dx,dy),'east':(u+dz+dx,v+dz,dz,dy),'back':(u+2*dz+dx,v+dz,dx,dy)}
def layer(seed):
    im=new(64,32); p=im.load(); random.seed(seed)
    parts=[('head',0,0,8,8,8),('body',16,16,8,12,4),('arm',40,16,4,12,4),('leg',0,16,4,12,4)]
    for name,u,v,dx,dy,dz in parts:
        for fn,(x0,y0,w,h) in region(u,v,dx,dy,dz).items():
            for y in range(h):
                for x in range(w):
                    c=random.choice([S1,S1,S2,S2,S3]) 
                    if fn=='top': c=random.choice([S3,S3,S4])
                    if fn=='bottom': c=S0
                    p[x0+x,y0+y]=c
            for x in range(w):
                p[x0+x,y0]=S4 if fn!='bottom' else S0
                p[x0+x,y0+h-1]=S0
            for y in range(h):
                p[x0,y0+y]=S3 if fn in('front','back') else p[x0,y0+y]
                p[x0+w-1,y0+y]=S0
            if fn in('front','back','west','east') and name in('body','leg','arm'):
                # glowing seams every 4 rows
                for yy in range(3,h-1,4):
                    for xx in range(1,w-1):
                        p[x0+xx,y0+yy]=L0 if (xx+yy)%5==0 else (L2 if fn in('front','back') else L3)
                    for xx in range(1,w-1): p[x0+xx,y0+yy+1]=S0 if yy+1<h-1 else p[x0+xx,y0+yy+1]
            if name=='head' and fn in('front','west','east'):
                for xx in range(1,w-1):
                    if fn=='front': p[x0+xx,y0+3]=S0; p[x0+xx,y0+4]=L2 if xx not in(3,4) else S0
                    else: p[x0+xx,y0+4]=L3
                if fn=='front': p[x0+1,y0+4]=L0; p[x0+6,y0+4]=L0
                for xx in range(1,w-1): p[x0+xx,y0+2]=S3
            if name=='head' and fn=='top':
                for yy in range(h): p[x0+w//2,y0+yy]=L2; p[x0+w//2-1,y0+yy]=S0
            if name=='body' and fn=='front':
                for yy in range(1,h-1): p[x0+3,y0+yy]=S0; p[x0+4,y0+yy]=S0
                for yy in (2,5,8): p[x0+3,y0+yy]=L2; p[x0+4,y0+yy]=L1
            if name=='arm' and fn in('front','back','west','east'):
                for yy in range(0,3):
                    for xx in range(w): p[x0+xx,y0+yy]=S4 if yy==0 else S3
                for xx in range(w): p[x0+xx,y0+3]=L2
            if name=='leg' and fn in('front','back','west','east'):
                for xx in range(w): p[x0+xx,y0+h-3]=S0; p[x0+xx,y0+h-2]=S3 if xx%2 else S2
    return im
layer(21).save('/home/claude/dg/src/main/resources/assets/minecraft/textures/models/armor/lumenite_layer_1.png')
layer(22).save('/home/claude/dg/src/main/resources/assets/minecraft/textures/models/armor/lumenite_layer_2.png')
print('layers ok')
