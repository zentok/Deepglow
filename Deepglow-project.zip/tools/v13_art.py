"""v1.7.0 art pass: blocks, crystal, glowcap, lamp/lantern, spawn eggs. Run from the project root."""
import random, math, json, shutil
from PIL import Image
R='src/main/resources/'
T=R+'assets/deepglow/textures/'
def hx(s): s=s.lstrip('#'); return tuple(int(s[i:i+2],16) for i in (0,2,4))
D0,D1,D2,M1,M2,L1,L2,L3=[hx(c) for c in ('#082a2d','#0d4547','#0f6f6a','#1a9a9a','#25b8ae','#3fd3c1','#7aeadb','#c9fff5')]
S0,S1,S2,S3,S4=[hx(c) for c in ('#0e1218','#151922','#222630','#2e3442','#48546a')]
def img(): return Image.new('RGBA',(16,16),(0,0,0,0))
def put(im,x,y,c):
    if 0<=x<16 and 0<=y<16: im.putpixel((x,y),c+(255,))
def save(im,path): im.save(path)

# ---------- lumenite block: tileable crystal facets (voronoi) ----------
def block():
    # four faceted pyramids (light from the top-left): lit top/left facets, shaded bottom/right facets
    im=img()
    for ty in (0,8):
        for tx in (0,8):
            for y in range(8):
                for x in range(8):
                    dx=x-3.5; dy=y-3.5
                    if y in (0,) or x in (0,): c=D1 if (x+y)%1==0 else D1
                    elif y==7 or x==7: c=D1
                    elif abs(dx)>abs(dy):
                        c=M2 if dx<0 else D2        # left facet lit, right facet shaded
                    else:
                        c=L1 if dy<0 else M1        # top facet brightest, bottom facet mid
                    if abs(dx)<1 and abs(dy)<1: c=L3 if (x,y)==(3,3) else L2
                    put(im,tx+x,ty+y,c)
    save(im,T+'block/lumenite_block.png')
def druse():
    # raw crystal rock used for geodes: speckled like vanilla amethyst, no frame
    rng=random.Random(21); im=img()
    for y in range(16):
        for x in range(16):
            r=rng.random()
            c=M1 if r<.42 else M2 if r<.72 else D2 if r<.86 else L1 if r<.95 else L2
            put(im,x,y,c)
    for _ in range(14):
        x=rng.randrange(16); y=rng.randrange(16); c=rng.choice([D1,L2,D2])
        put(im,x,y,c); put(im,(x+1)%16,(y+1)%16,c)
    save(im,T+'block/lumenite_druse.png')
def bricks():
    im=img(); rng=random.Random(8)
    rows=[(1,4,0),(6,9,4),(11,15,0)]       # y0,y1,x offset of the vertical mortar lines
    for y in range(16):
        for x in range(16): put(im,x,y,D1)
    for y0,y1,off in rows:
        xs=[(off,off+8),(off+8,off+16)] if off==0 else [(off-8,off),(off,off+8),(off+8,off+16)]
        for a,b in xs:
            a0=max(a,0)+1 if a>=0 else 0; b0=min(b,16)-1 if b<=16 else 15
            if a==0: a0=1
            if b==16: b0=15-0
            for y in range(y0,y1+1):
                for x in range(max(a,0),min(b,16)):
                    if x==(a%16 if a>=0 else 0) and a>=0 and a!=0: continue
                    if x==a and a==0: continue
                    c=M1 if rng.random()>.15 else M2
                    if y==y0: c=L1
                    elif x==max(a,0)+ (1 if a<=0 else 1): c=L1 if c==M1 else c
                    if y==y1: c=D2
                    elif x==min(b,16)-1: c=D2
                    put(im,x,y,c)
    save(im,T+'block/lumenite_bricks.png')
# ---------- polished: 2x2 smooth bevelled tiles ----------
def polished():
    im=img(); rng=random.Random(5)
    for ty in (0,8):
        for tx in (0,8):
            for y in range(8):
                for x in range(8):
                    c=M1 if rng.random()>.1 else M2
                    if y==0 or x==0: c=L1
                    if y==7 or x==7: c=D2
                    if (x,y)==(0,7) or (x,y)==(7,0): c=M2
                    put(im,tx+x,ty+y,c)
    save(im,T+'block/polished_lumenite.png')
# ---------- chiseled: framed panel with a glowing square-spiral rune ----------
def chiseled():
    im=img()
    for y in range(16):
        for x in range(16):
            c=D2
            if y==0 or x==0: c=M1
            if y==15 or x==15: c=D1
            if 2<=x<=13 and 2<=y<=13: c=D0
            if x==2 and 2<=y<=13 or y==2 and 2<=x<=13: c=D1
            put(im,x,y,c)
    spiral=["XXXXXXXX","X......X","X.XXXX.X","X.X..X.X","X.X.XX.X","X.X....X","X.XXXXXX","X......."]
    for j,row in enumerate(spiral):
        for i,ch in enumerate(row):
            if ch=='X': put(im,4+i,4+j,L2 if (i+j)%4 else L3)
    for j,row in enumerate(spiral):          # soft glow under the rune
        for i,ch in enumerate(row):
            if ch=='X' and im.getpixel((5+i,5+j))[:3]==D0: put(im,5+i,5+j,D1)
    save(im,T+'block/chiseled_lumenite.png')
# ---------- pillar: side tiles vertically (same rows top to bottom), top is a ring ----------
def pillar():
    # dark stone frame with two glowing vertical flutes; every row is identical so stacked blocks look like one tall column
    cols=[S1,S3,S2,D1,M2,L1,M2,D1,D1,M2,L1,M2,D1,S2,S3,S1]
    rng=random.Random(3); im=img()
    spec=[[rng.random() for _ in range(16)] for _ in range(8)]
    for y in range(16):
        for x in range(16):
            c=cols[x]
            if spec[y%8][x]<.12 and c in (S2,S3): c=S4 if spec[y%8][x]<.06 else S1
            if c==L1 and spec[(y+3)%8][x]<.2: c=L2
            put(im,x,y,c)
    save(im,T+'block/lumenite_pillar_side.png')
    im=img()
    for y in range(16):
        for x in range(16):
            c=S2
            if y in (0,15) or x in (0,15): c=S1
            elif y in (1,14) or x in (1,14): c=S3
            put(im,x,y,c)
    spin=["..XXXXXX..X...",]
    pin=[
     "XXXXXXXX.....X",
     "X..........X.X",
     "X.XXXXXXXX.X.X",
     "X.X......X.X.X",
     "X.X.XXXX.X.X.X",
     "X.X.X..X.X.X.X",
     "X.X.X.XX.X.X.X",
     "X.X.X....X.X.X",
     "X.X.XXXXXX.X.X",
     "X.X........X.X",
     "X.XXXXXXXXXX.X",
     "X............X",
     "XXXXXXXXXXXXXX"]
    for j,row in enumerate(pin):
        for i,ch in enumerate(row):
            if 2+i<14 and 2+j<14: put(im,2+i,2+j,D1)
    for j,row in enumerate(pin):
        for i,ch in enumerate(row):
            if ch=='X' and 2+i<14 and 2+j<14: put(im,2+i,2+j,L1 if (i+j)%3 else L2)
    save(im,T+'block/lumenite_pillar_top.png')
# ---------- amethyst-style crystal cluster ----------
def crystal():
    # vanilla-cluster silhouette: one tall pointed shard and angled flaps on both sides
    im=img()
    def shard(cx,base,w,h,lean=0.0):
        for k in range(h):
            y=base-k; top=h-1-k
            half=w/2 if top>=3 else max(0.4,(w/2)*(top+0.6)/3.2)
            ox=cx+lean*(k/h)
            for x in range(int(ox-half-1),int(ox+half+2)):
                fx=x+.5-ox
                if abs(fx)>half: continue
                if fx>=half-0.9 and half>1.2: c=D2
                elif fx<-half*.3: c=L1 if top>2 else L2
                else: c=M2 if top>1 else L2
                if top==0: c=L3
                put(im,x,y,c)
            ex=int(ox+half+0.5)
            if 0<=ex<16 and im.getpixel((ex,y))[3]==0: put(im,ex,y,D1)
    shard(1.8,15,2,5,-1.0); shard(14.2,15,2,5,1.0)
    shard(4.2,15,3,8,-3.0); shard(11.8,15,3,8,3.0)
    shard(8,15,4,14,0.0)
    put(im,7,4,L3); put(im,7,8,L2); put(im,3,12,L2); put(im,12,11,L2)
    save(im,T+'block/lumenite_crystal.png')
# ---------- single glowing mushroom like the vanilla one ----------
def glowcap():
    im=img()
    cap=[(5,5,10),(4,6,11),(3,7,12),(2,8,13),(2,9,13),(3,10,12)]   # y, x0, x1
    rows={4:(5,10),5:(4,11),6:(3,12),7:(2,13),8:(2,13),9:(3,12)}
    for y,(a,b) in rows.items():
        for x in range(a,b+1):
            c=M1
            if y<=5: c=M2
            if y==4: c=L1
            if y>=8: c=D2
            if x in (a,a+1) and y<8: c=L1 if y>4 else L2
            if x==b: c=D2
            put(im,x,y,c)
    for (x,y) in [(5,5),(9,5),(7,7),(11,7),(4,8),(8,8)]: put(im,x,y,L3)
    for (x,y) in [(6,6),(10,6)]: put(im,x,y,L2)
    # gills
    for x in range(4,12): put(im,x,10,D1 if x%2 else D2)
    # stem, slightly curved
    stem={11:(6,9),12:(6,9),13:(7,9),14:(7,9),15:(6,10)}
    for y,(a,b) in stem.items():
        for x in range(a,b+1):
            c=L2 if x==a else (L1 if x<b else M1)
            if y==15: c=D2
            put(im,x,y,c)
    save(im,T+'block/glowcap.png')
# ---------- lantern (new) : dark iron cage with glowing slits and corner rivets ----------
def lantern():
    im=img()
    for y in range(16):
        for x in range(16):
            c=S2
            if y in (0,15) or x in (0,15): c=S1
            if y in (1,14) or x in (1,14): c=S4 if (x+y)%2==0 else S3
            put(im,x,y,c)
    for (x,y) in [(1,1),(14,1),(1,14),(14,14)]: put(im,x,y,L2)
    for x0 in (3,7,11):                       # three tall glowing slits, hot centre
        for y in range(3,13):
            put(im,x0,y,M2); put(im,x0+1,y,L2 if 4<=y<=11 else M1)
            put(im,x0-1 if x0==3 else x0+2,y,S0) if False else None
        put(im,x0,3,L1); put(im,x0+1,3,L1)
        for y in (7,8): put(im,x0,y,L3); put(im,x0+1,y,L3)
    for y in (6,9): 
        for x in range(2,14): 
            if im.getpixel((x,y))[:3] in (S2,): put(im,x,y,S1)
    save(im,T+'block/deep_lantern.png')
def diag(im,p0,p1,w0,wmax,w1,pal=None,spikes=()):
    (x0,y0),(x1,y1)=p0,p1; L=math.hypot(x1-x0,y1-y0); ux,uy=(x1-x0)/L,(y1-y0)/L; nx,ny=uy,-ux   # n points to the lit upper-left side
    cells={}
    for yy in range(16):
        for xx in range(16):
            px,py=xx+.5-x0,yy+.5-y0; t=(px*ux+py*uy)/L; d=px*nx+py*ny
            if t<-0.02 or t>1.02: continue
            wd=(w0+(wmax-w0)*(t/0.2) if t<.2 else wmax if t<.7 else wmax+(w1-wmax)*((t-.7)/.3))/2
            if abs(d)<=wd: cells[(xx,yy)]=(t,d,wd)
    for (xx,yy),(t,d,wd) in cells.items():
        c=M2
        if d>wd*0.15: c=M1
        if d>wd*0.6: c=D2
        if d<-wd*0.35: c=L1
        if d<-wd*0.75: c=L2
        edge=any((xx+a,yy+b) not in cells for a,b in ((1,0),(-1,0),(0,1),(0,-1)))
        if edge: c=D1 if d>0 else (M1 if d>-wd*.5 else L2)
        put(im,xx,yy,c)
    return cells
def sword():
    im=img()
    cells=diag(im,(5.0,11.2),(14.9,1.3),3.2,5.4,2.4)
    # jagged crystal spikes growing out of the lit (upper-left) edge
    for (x,y,h) in [(10,3,2),(8,5,2),(6,7,2),(11,5,1)]:
        for k in range(h):
            put(im,x-1-k,y-k if False else y-1,L1 if k==0 else L2)
        put(im,x-1,y-2,L2) if h>1 else None
    for (x,y) in [(11,3),(9,5),(7,7),(8,8),(10,6)]: put(im,x,y,L3)
    put(im,14,1,L3); put(im,13,2,L2)
    # cross-guard (dark metal with a teal gem), grip, pommel
    for (x,y,c) in [(2,9,S3),(3,10,S4),(4,11,S3),(5,12,S2),(6,13,S1),(3,9,S2),(4,10,S2),(5,11,S1),(4,12,S1),(2,10,S1),(3,11,S1)]: put(im,x,y,c)
    put(im,4,11,L1)
    for (x,y,c) in [(3,12,S2),(2,13,S3),(2,12,S1),(1,14,S2),(1,13,S1),(0,15,L1),(1,15,M1),(0,14,D2)]: put(im,x,y,c)
    save(im,T+'item/lumenite_sword.png')
def shard():
    im=img()
    diag(im,(2.8,13.4),(13.6,2.4),2.6,5.0,2.6)
    for (x,y) in [(8,6),(6,9),(10,4)]: put(im,x,y,L3)
    put(im,4,11,L2); put(im,12,3,L3)
    save(im,T+'item/lumenite_shard.png')
# ---------- spawn eggs ----------
def egg_mask():
    m={}
    for y in range(1,16):
        t=(y-8.8)/7.3
        if abs(t)>1: continue
        hw=5.6*math.sqrt(max(0,1-t*t))*(0.8+0.2*(y-1)/14)
        for x in range(16):
            d=abs(x+.5-8)
            if d<=hw: m[(x,y)]=d/max(hw,.1)
    return m
def egg(name,base,shade,hi,outline,spots,paint):
    im=img(); m=egg_mask(); rng=random.Random(sum(map(ord,name)))
    for (x,y),d in m.items():
        edge=any((x+dx,y+dy) not in m for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)))
        c=base
        if x+.5>8.2 and d>.45: c=shade
        if (x+.5<7 and y<8 and d>.3) and (x,y) in ((5,6),(5,7),(6,4),(5,5),(6,5)): c=hi
        if edge: c=outline
        put(im,x,y,c)
    paint(im,m,rng,spots)
    save(im,T+'item/%s_spawn_egg.png'%name)
def spots_in(im,m,rng,col,n,ok=lambda x,y:True):
    k=0; tries=0
    while k<n and tries<200:
        tries+=1; x=rng.randint(3,12); y=rng.randint(3,14)
        if (x,y) in m and (x+1,y) in m and (x,y+1) in m and (x+1,y+1) in m and ok(x,y):
            if all(im.getpixel((x+i,y+j))[:3]!=col for i in (-1,0,1,2) for j in (-1,0,1,2) if 0<=x+i<16 and 0<=y+j<16):
                for i,j in ((0,0),(1,0),(0,1),(1,1)) if rng.random()<.5 else ((0,0),(1,0),(0,1)): put(im,x+i,y+j,col)
                k+=1
def beetle_paint(im,m,rng,s):      # shell seam + teal pits
    for y in range(3,15):
        if (8,y) in m and im.getpixel((8,y))[:3]!=hx('#06191c'): put(im,8,y,hx('#06191c'))
        if (7,y) in m and y%2: put(im,7,y,hx('#1d3d44'))
    for (x,y) in [(5,6),(10,6),(5,10),(10,10),(6,13),(9,13),(4,8),(11,8)]:
        if (x,y) in m: put(im,x,y,L1)
    for (x,y) in [(6,3),(9,3)]:
        if (x,y) in m: put(im,x,y,L2)
def slug_paint(im,m,rng,s):        # soft body with wavy light bands
    for y in (5,8,11):
        for x in range(16):
            if (x,y) in m and im.getpixel((x,y))[:3]!=hx('#073b3a'):
                put(im,x,y+(1 if (x//2)%2 else 0),hx('#a8fff0') if (x//2)%2 else hx('#5fe6d2'))
    for (x,y) in [(6,3),(9,3)]: put(im,x,y,L3)
def shardling_paint(im,m,rng,s):   # angular cyan crystal chips
    for pts in [[(5,5),(6,4),(6,5),(6,6)],[(9,7),(10,6),(10,7),(10,8),(10,9)],[(5,10),(6,10),(6,11),(7,11),(6,12)],[(9,12),(10,12),(10,13)]]:
        for (x,y) in pts:
            if (x,y) in m: put(im,x,y,L1)
        if pts[0] in m: put(im,*pts[1],L3) if pts[1] in m else None
def guardian_paint(im,m,rng,s):    # big crystal with a ring of small ones
    big=[(8,3),(8,4),(7,5),(8,5),(9,5),(7,6),(8,6),(9,6),(7,7),(8,7),(9,7),(7,8),(8,8),(9,8),(8,9),(8,10)]
    for (x,y) in big:
        if (x,y) in m: put(im,x,y,M2 if x==9 else (L1 if x==8 else L2))
    put(im,8,3,L3); put(im,7,6,L3)
    for (x,y) in [(4,7),(11,7),(5,11),(10,11),(6,13),(9,13),(4,9),(11,10)]:
        if (x,y) in m: put(im,x,y,M1)
    for (x,y) in [(5,12),(11,12)]:
        pass
def eggs():
    egg('glow_beetle',hx('#1b2e35'),hx('#0f1f26'),hx('#34525b'),hx('#06191c'),L1,beetle_paint)
    egg('glow_slug',hx('#1f9a8e'),hx('#157a73'),hx('#7ff0de'),hx('#073b3a'),L3,slug_paint)
    egg('shardling',hx('#4a5468'),hx('#2e3442'),hx('#7c88a0'),hx('#10131a'),L1,shardling_paint)
    egg('deep_guardian',hx('#2b3340'),hx('#171c25'),hx('#56627a'),hx('#080b10'),L1,guardian_paint)

if __name__=='__main__':
    shutil.copy('tools/old_lantern.png',T+'block/lumenite_lamp.png')   # old lantern art becomes the lamp
    block(); druse(); bricks(); polished(); chiseled(); pillar(); crystal(); glowcap(); lantern(); eggs(); shard()  # sword() removed: tool textures reverted to the old dark look (tools/gen_art2.py)
    # guardian loot: 2 shards + 3 ingots, nothing else
    def pool(item,n): return {"rolls":1,"bonus_rolls":0,"entries":[{"type":"minecraft:item","name":item,"functions":[{"function":"minecraft:set_count","count":n}]}]}
    json.dump({"type":"minecraft:entity","pools":[pool("deepglow:lumenite_shard",2),pool("deepglow:lumenite_ingot",3)]},open(R+'data/deepglow/loot_tables/entities/deep_guardian.json','w'),indent=2)
    json.dump({"type":"minecraft:crafting_shaped","pattern":[" G ","GDG"," G "],"key":{"G":{"item":"minecraft:glass"},"D":{"item":"deepglow:lumenite_dust"}},"result":{"item":"deepglow:lumenite_glass","count":4}},open(R+'data/deepglow/recipes/lumenite_glass.json','w'),indent=2)
    print('v13 art ok')
