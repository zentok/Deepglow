# Beetle armor: ONE spec -> textures (+glow), Java layer code, and a json for the 3D preview/viewer.
import random, json, os
from PIL import Image
ROOT='/home/claude/dg/'
TEXDIR=ROOT+'src/main/resources/assets/deepglow/textures/models/armor/'
os.makedirs(TEXDIR,exist_ok=True)
def hx(s): return tuple(int(s[i:i+2],16) for i in (1,3,5))
S0,S1,S2,S3=hx('#151922'),hx('#222630'),hx('#2e3442'),hx('#48546a')
T1,T2,T3=hx('#0f6f6a'),hx('#1a9a9a'),hx('#3fd3c1')
W0,W1=hx('#eafffb'),hx('#9ff7e8')

def faces(u,v,w,h,d):
    return {'top':(u+d,v,w,d),'bottom':(u+d+w,v,w,d),'right':(u,v+d,d,h),'front':(u+d,v+d,w,h),
            'left':(u+d+w,v+d,d,h),'back':(u+2*d+w,v+d,w,h)}

# painters: (face,i,j,w,h,rng) -> (rgb, glow_rgb|None)  (None rgb => leave transparent)
def scales(i,j,r):
    row=j//3; ci=(i+(2 if row%2 else 0))%4; cj=j%3
    if cj==0 or ci==0: return S1,ci,cj
    if ci==1 and cj==1: return S3,ci,cj
    return (S2 if r.random()<0.85 else S1),ci,cj
def shell(f,i,j,w,h,r):
    c,ci,cj=scales(i,j,r); g=None
    if ci==2 and cj==2 and r.random()<0.14: c=T2; g=T1                       # teal inlay
    if j==0 or i==0: c=S3
    if f in('front','back') and w>=4 and abs(i-(w-1)/2)<0.6: c=S0          # seam
    if h>=6 and j==h-1 and f in('front','back','left','right'): c=T2; g=T1  # glowing rim
    if h>=6 and j==h-2 and f in('front','back','left','right'): c=S0
    return c,g
def plate(f,i,j,w,h,r):
    c=r.choice([S1,S2,S2,S3]);g=None
    if j==0: c=S3
    if j==h-1 and h>=2: c=S0
    if w>=6 and h>=2 and j==h//2 and i in (1,w-2): c=W1; g=W1            # rivets
    if w>=6 and h>=3 and j==h//2 and i%2==0 and i not in (1,w-2): c=T2; g=T1  # glowing line
    return c,g
def spike(f,i,j,w,h,r):
    t=j/max(1,h-1); c=S2 if t<0.35 else (T2 if t<0.7 else T3); g=None
    if t>=0.7: g=T3
    if j==h-1 and t>0.7: c=W1; g=W1
    return c,g
def glowy(f,i,j,w,h,r): return W1,W1
def tip(f,i,j,w,h,r):
    c=T3 if (i+j)%3 else T2
    return c,T3
def eye(f,i,j,w,h,r):
    if f=='front':
        edge=i in(0,w-1) or j in(0,h-1)
        if edge: return T2,T2
        return (W1,W1) if (i,j) in ((1,1),(2,1)) else (T3,T3)
    return S2,None
def crest(f,i,j,w,h,r):
    c=S3 if f=='top' else r.choice([S1,S2]); g=None
    if f in('left','right') and j==h-1: c=T2; g=T1
    return c,g
def helm_base(f,i,j,w,h,r):
    # full head shell, glowing eye slits on the front
    c,g=shell(f,i,j,w,h,r)
    if f=='front':
        if j in (3,4) and (i in (1,2,5,6)): return W1,W1
        if j==7: c=T2; g=T1
    return c,g
def boot_base(f,i,j,w,h,r):
    if f in('top',): return None,None
    if f in('front','back','left','right') and j<8: return None,None
    return plate(f,i,j,w,h,r)
def belt_base(f,i,j,w,h,r):
    if f in('top','bottom'): return None,None
    if j<9: return None,None            # inner body: only the belt rows
    c,g=plate(f,i,j,w,h,r)
    if j==9: c=T2; g=T1
    return c,g
def leg_inner(f,i,j,w,h,r):
    if f=='top': return None,None
    c,g=shell(f,i,j,w,h,r)
    if j in (4,5) and f=='front': c=S3; g=None
    return c,g
def arm_base(f,i,j,w,h,r):
    c,g=shell(f,i,j,w,h,r)
    if j>=9 : c=r.choice([S1,S2]); g=None; 
    if j in (4,8): c=T2; g=T1
    return c,g
def body_base(f,i,j,w,h,r):
    c,g=shell(f,i,j,w,h,r)
    if f=='front' and j%3==2: c=S0
    if f=='front' and i in(3,4) and j in(5,6): return W1,W1   # glowing core on the chest
    return c,g
def _xi(face,i,w): return i if face=='front' else w-1-i
def wing_shape(side):
    # elytra-like membrane: wide at the shoulder end, tapering to a rounded tip; only the two big faces are painted
    def fn(f,i,j,w,h,r):
        if f not in('front','back'): return None,None
        x=_xi(f,i,w)                       # x position in model terms (0 = left edge as seen from the front)
        k=(j/max(1,h-1))                   # 0 top .. 1 tip
        cut=int(round((w-2)*(k**1.6)))     # how many columns are removed on the far side
        if side=='l':                      # left wing: far side is x=0 (i small)
            keep=x>=cut
        else:
            keep=x<=w-1-cut
        if j==h-1: keep=False
        if j==h-2 and (x<2 or x>w-3): keep=False
        if not keep: return None,None
        c=r.choice([T1,T1,T2]); g=c            # lit membrane: self-glowing teal so it reads in the dark
        if x%3==0: c=T3; g=T3                  # glowing veins
        edge = (side=='l' and x==cut) or (side=='r' and x==w-1-cut)
        if edge: c=S3; g=None
        return c,g
    return fn
def shell_shape(f,i,j,w,h,r):
    # elytra-like shell: rounded bottom corners, bottom/side edge strips transparent near the tip
    if f=='bottom': return None,None
    if f in('left','right') and j>=h-4: return None,None
    if f in('front','back'):
        x=_xi(f,i,w); k=j-(h-5)
        if k>0 and (x<k or x>w-1-k): return None,None
    return shell(f,i,j,w,h,r)
PAINT=dict(wing_l=wing_shape('l'),wing_r=wing_shape('r'),shell_shape=shell_shape,shell=shell,plate=plate,spike=spike,glowy=glowy,tip=tip,eye=eye,crest=crest,helm_base=helm_base,boot_base=boot_base,
           belt_base=belt_base,leg_inner=leg_inner,arm_base=arm_base,body_base=body_base)

def X(name,parent,box,pose,mat,uvkey=None): return dict(name=name,parent=parent,box=box,pose=pose,mat=mat,uvkey=uvkey or name,extra=True)

BASE_UV={'head':(0,0,8,8,8),'body':(16,16,8,12,4),'right_arm':(40,16,4,12,4),'left_arm':(40,16,4,12,4),'right_leg':(0,16,4,12,4),'left_leg':(0,16,4,12,4)}

OUTER=dict(file='beetle_armor_1',deform=1.0,base={'head':'helm_base','body':'body_base','right_arm':'arm_base','left_arm':'arm_base','right_leg':'boot_base','left_leg':'boot_base'},extras=[
 # ---- helmet
 X('crest','head',(-1,-1,-5,2,1,10),(0,-9,0,0,0,0),'crest'),
 X('antenna_r','head',(-0.5,-0.5,-4,1,1,4),(-2.5,-9,-4,-0.9,0.35,0),'plate','antenna'),
 X('antenna_l','head',(-0.5,-0.5,-4,1,1,4),(2.5,-9,-4,-0.9,-0.35,0),'plate','antenna'),
 X('tip_r','antenna_r',(-1,-1,-2,2,2,2),(0,0,-4,-0.45,0,0),'tip','tip'),
 X('tip_l','antenna_l',(-1,-1,-2,2,2,2),(0,0,-4,-0.45,0,0),'tip','tip'),
 X('mand_r','head',(-0.5,-0.5,-3,1,1,3),(-1.9,-1.5,-5,0,0.5,0),'spike','mand'),
 X('mand_l','head',(-0.5,-0.5,-3,1,1,3),(1.9,-1.5,-5,0,-0.5,0),'spike','mand'),
 X('eye_r','head',(-1.5,-1.5,-1,3,3,1),(-2.8,-5,-5,0,0,0),'eye','eye'),
 X('eye_l','head',(-1.5,-1.5,-1,3,3,1),(2.8,-5,-5,0,0,0),'eye','eye'),
 X('cheek_r','head',(-1,0,0,1,4,5),(-5,-7,-2,0,0,0.15),'plate','cheek'),
 X('cheek_l','head',(0,0,0,1,4,5),(5,-7,-2,0,0,-0.15),'plate','cheek'),
 X('brow','head',(-4,-1,-1,8,1,1),(0,-6.8,-5.2,0,0,0),'plate','brow'),
 X('gem','head',(-1,-1,-1,2,2,1),(0,-8.2,-5.2,0,0,0),'glowy','gem'),
 # ---- chestplate
 X('collar','body',(-6,-1,-4,12,1,8),(0,-1,0,0,0,0),'plate','collar'),
 X('sternum','body',(-2,0,-1,4,6,1),(0,2,-3,0,0,0),'plate','sternum'),
 X('bracer_r','right_arm',(-4.5,0,-3.5,7,2,7),(-1,7,0,0,0,0),'plate','bracer'),
 X('bracer_l','left_arm',(-2.5,0,-3.5,7,2,7),(1,7,0,0,0,0),'plate','bracer'),
 X('shell_r','body',(0,0,0,10,20,2),(-5,0,3.4,0.26,0,0.26),'shell_shape','shellwing'),
 X('shell_l','body',(-10,0,0,10,20,2),(5,0,3.4,0.26,0,-0.26),'shell_shape','shellwing'),
 X('abdomen','body',(-4,0,0,8,4,4),(0,12,3,0.5,0,0),'plate'),
 X('ridge1','body',(-4,0,-1,8,2,1),(0,1.5,-3,0,0,0),'plate','ridge'),
 X('ridge2','body',(-4,0,-1,8,2,1),(0,5,-3,0,0,0),'plate','ridge'),
 X('ridge3','body',(-4,0,-1,8,2,1),(0,8.5,-3,0,0,0),'plate','ridge'),
 X('pad_r','right_arm',(-3,-4,-3,7,2,7),(-1,0,0,0,0,0),'shell','pad'),
 X('pad_l','left_arm',(-4,-4,-3,7,2,7),(1,0,0,0,0,0),'shell','pad'),
 X('shspike_r','right_arm',(-1,-3,-1,2,3,2),(-3.5,-3.5,0,0,0,-0.6),'spike','shspike'),
 X('shspike_l','left_arm',(-1,-3,-1,2,3,2),(3.5,-3.5,0,0,0,0.6),'spike','shspike'),
 X('thorn_r1','right_arm',(-3,-0.5,-0.5,3,1,1),(-3.5,4,0,0,0,0.3),'spike','thorn'),
 X('thorn_r2','right_arm',(-3,-0.5,-0.5,3,1,1),(-3.5,8,0,0,0,0.3),'spike','thorn'),
 X('thorn_l1','left_arm',(0,-0.5,-0.5,3,1,1),(3.5,4,0,0,0,-0.3),'spike','thorn'),
 X('thorn_l2','left_arm',(0,-0.5,-0.5,3,1,1),(3.5,8,0,0,0,-0.3),'spike','thorn'),
 X('wing_r','shell_r',(0,20,0.5,10,10,1),(0,0,0,0,0,0),'wing_r','wing_r'),
 X('wing_l','shell_l',(-10,20,0.5,10,10,1),(0,0,0,0,0,0),'wing_l','wing_l'),
 # ---- boots
 X('greave_r','right_leg',(-3.5,7,-3.5,7,2,7),(0,0,0,0,0,0),'plate','greave'),
 X('greave_l','left_leg',(-3.5,7,-3.5,7,2,7),(0,0,0,0,0,0),'plate','greave'),
 X('claw_r1','right_leg',(-0.5,-0.5,-3,1,1,3),(-1.6,11.5,-3,0.3,0,0),'spike','claw'),
 X('claw_r2','right_leg',(-0.5,-0.5,-3,1,1,3),(0.2,11.5,-3,0.3,0,0),'spike','claw'),
 X('claw_l1','left_leg',(-0.5,-0.5,-3,1,1,3),(-0.2,11.5,-3,0.3,0,0),'spike','claw'),
 X('claw_l2','left_leg',(-0.5,-0.5,-3,1,1,3),(1.6,11.5,-3,0.3,0,0),'spike','claw'),
 X('anklespike_r','right_leg',(-2,-0.5,-0.5,2,1,1),(-3,9,0,0,0,0.3),'spike','ankle'),
 X('anklespike_l','left_leg',(0,-0.5,-0.5,2,1,1),(3,9,0,0,0,-0.3),'spike','ankle'),
 X('spur_r','right_leg',(-0.5,-0.5,0,1,1,2),(0,10.5,3,-0.5,0,0),'spike','spur'),
 X('spur_l','left_leg',(-0.5,-0.5,0,1,1,2),(0,10.5,3,-0.5,0,0),'spike','spur'),
])
INNER=dict(file='beetle_armor_2',deform=0.5,base={'body':'belt_base','right_leg':'leg_inner','left_leg':'leg_inner'},extras=[
 X('seg1','body',(-4,0,-1,8,2,1),(0,8.5,-2.5,0,0,0),'plate','seg'),
 X('seg2','body',(-4,0,-1,8,2,1),(0,10.2,-2.5,0.1,0,0),'plate','seg'),
 X('thband_r','right_leg',(-3,2,-3,6,1,6),(0,0,0,0,0,0),'plate','thband'),
 X('thband_l','left_leg',(-3,2,-3,6,1,6),(0,0,0,0,0,0),'plate','thband'),
 X('plate_r','right_leg',(-1,0,-3,1,5,6),(-2.5,1,0,0,0,0),'shell','thigh'),
 X('plate_l','left_leg',(0,0,-3,1,5,6),(2.5,1,0,0,0,0),'shell','thigh'),
 X('knee_r','right_leg',(-0.5,-0.5,-2,1,1,2),(0,6,-2.5,0.4,0,0),'spike','knee'),
 X('knee_l','left_leg',(-0.5,-0.5,-2,1,1,2),(0,6,-2.5,0.4,0,0),'spike','knee'),
 X('shin_r','right_leg',(-1,0,-1,2,4,1),(0,7,-2.5,0,0,0),'plate','shin'),
 X('shin_l','left_leg',(-1,0,-1,2,4,1),(0,7,-2.5,0,0,0),'plate','shin'),
])

def pack(model):
    # tallest first; free areas: the lower half, the unused hat area (hat is hidden) and a strip next to the arms
    items={}
    for e in model['extras']:
        b=e['box']; w,h,d=int(b[3]),int(b[4]),int(b[5]); items[e['uvkey']]=(2*(w+d),d+h)
    regions=[[0,32,64,128],[32,0,64,16],[56,16,64,32]]  # x0,y0,x1,y1
    cur=[[r[0],r[1],0] for r in regions]  # cursor x,y,rowh
    alloc={}
    for k,(W,H) in sorted(items.items(),key=lambda kv:(-kv[1][1],-kv[1][0])):
        for ri,r in enumerate(regions):
            c=cur[ri]
            if c[0]+W>r[2]: c[0]=r[0]; c[1]+=c[2]; c[2]=0
            if c[1]+H<=r[3] and c[0]+W<=r[2]:
                alloc[k]=(c[0],c[1]); c[0]+=W; c[2]=max(c[2],H); break
        else: raise AssertionError((model['file'],k))
    return alloc

def build(model):
    alloc=pack(model); rng=random.Random(sum(map(ord,model['file'])))
    body=Image.new('RGBA',(64,128),(0,0,0,0)); glow=Image.new('RGBA',(64,128),(0,0,0,0))
    def paint(u,v,w,h,d,fn):
        for f,(fx,fy,fw,fh) in faces(u,v,w,h,d).items():
            for j in range(fh):
                for i in range(fw):
                    c,g=fn(f,i,j,fw,fh,rng)
                    if c is None: continue
                    body.putpixel((fx+i,fy+j),c+(255,))
                    if g is not None: glow.putpixel((fx+i,fy+j),g+(255,))
    for part,fn in model['base'].items():
        u,v,w,h,d=BASE_UV[part]; paint(u,v,w,h,d,PAINT[fn])
    done=set()
    for e in model['extras']:
        if e['uvkey'] in done: continue
        done.add(e['uvkey']); b=e['box']; u,v=alloc[e['uvkey']]
        paint(u,v,int(b[3]),int(b[4]),int(b[5]),PAINT[e['mat']])
    body.save(TEXDIR+model['file']+'.png'); glow.save(TEXDIR+model['file']+'_glow.png')
    for e in model['extras']: e['uv']=alloc[e['uvkey']]
    return alloc

def f(v): return repr(float(v))+'F'
def java_layer(model):
    out=['        MeshDefinition mesh = HumanoidModel.createMesh(new CubeDeformation(%s), 0.0F);'%f(model['deform']),
         '        PartDefinition root = mesh.getRoot();']
    names={'head','body','right_arm','left_arm','right_leg','left_leg'}
    declared=set(names)
    for n in ['head','body','right_arm','left_arm','right_leg','left_leg']:
        out.append('        PartDefinition pd_%s = root.getChild("%s");'%(n,n))
    for e in model['extras']:
        b=e['box']; p=e['pose']; u,v=e['uv']
        out.append('        PartDefinition pd_%s = pd_%s.addOrReplaceChild("%s", CubeListBuilder.create().texOffs(%d, %d).addBox(%s, %s, %s, %s, %s, %s),\n                PartPose.offsetAndRotation(%s, %s, %s, %s, %s, %s));'%(
            (e['name'],e['parent'],e['name'],u,v)+tuple(f(t) for t in b)+tuple(f(t) for t in p)))
    out.append('        return LayerDefinition.create(mesh, 64, 128);')
    return '\n'.join(out)

for m in (OUTER,INNER): build(m)
JAVA=ROOT+'src/main/java/dev/deepglow/client/BeetleArmorModel.java'
tmpl=open(ROOT+'tools/beetle_model_template.java').read()
open(JAVA,'w').write(tmpl.replace('/*OUTER*/',java_layer(OUTER)).replace('/*INNER*/',java_layer(INNER)))
json.dump({'outer':OUTER,'inner':INNER},open('/tmp/beetle_spec.json','w'))
print('beetle armor ok')
