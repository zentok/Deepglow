# Generates entity textures (+glow layers) and the Java model classes for the 1.2.0 mobs from ONE spec.
import random, os
from PIL import Image
ROOT='/home/claude/dg/'
TEX=ROOT+'src/main/resources/assets/deepglow/textures/entity/'
JAVA=ROOT+'src/main/java/dev/deepglow/client/'
def hx(s): return tuple(int(s[i:i+2],16) for i in (1,3,5))
L0=hx('#eafffb');L1=hx('#9ff7e8');L2=hx('#3fd3c1');L3=hx('#1a9a9a');L4=hx('#0e6670');L5=hx('#093a44')
D=[hx('#222630'),hx('#2e3442'),hx('#3a4254'),hx('#4a566c')]
ST=[hx('#2b3340'),hx('#394456'),hx('#48566c'),hx('#5d6d86')]
SL=[hx('#0f6f6a'),hx('#18948a'),hx('#25b8a4'),hx('#5fe3c8')]

def faces(u,v,w,h,d):
    return {'top':(u+d,v,w,d),'bottom':(u+d+w,v,w,d),'right':(u,v+d,d,h),'front':(u+d,v+d,w,h),
            'left':(u+d+w,v+d,d,h),'back':(u+2*d+w,v+d,w,h)}

# material painters: (face,i,j,w,h,rng) -> (body_rgb, glow_rgb|None)
def m_shell(f,i,j,w,h,r):
    c=r.choice(D[:3]); 
    if j==0 and f!='bottom': c=D[3]
    return c,None
def m_stone(f,i,j,w,h,r):
    c=r.choice(ST[:3])
    if r.random()<0.07: c=ST[0]
    if j==0 and f not in('bottom',): c=ST[3] if r.random()<0.6 else c
    g=None
    if f in('front','back','left','right') and i%5==2 and r.random()<0.55:
        c=L4; g=L2
    return c,g
def m_crystal(f,i,j,w,h,r):
    t=(i+j)/max(1,(w+h-2)); 
    c=L1 if t<0.25 else L2 if t<0.6 else L3
    if r.random()<0.12: c=L0
    return c,c
def m_slime(f,i,j,w,h,r):
    c=r.choice(SL[:3]); g=None
    if j==0: c=SL[3]
    if r.random()<0.15: g=SL[3]; c=SL[3]
    elif r.random()<0.45: g=SL[1]
    return c,g
def m_eye(f,i,j,w,h,r): return L0,L0
def m_core(f,i,j,w,h,r):
    c=L1 if (i+j)%2 else L0; return c,c
MAT={'shell':m_shell,'stone':m_stone,'crystal':m_crystal,'slime':m_slime,'eye':m_eye,'core':m_core}

def P(name,parent,uv,box,pose,mat): return dict(name=name,parent=parent,uv=uv,box=box,pose=pose,mat=mat)

SPECS={}
# ---------------- Glow Slug ----------------
SPECS['GlowSlug']=dict(tex='glow_slug',size=(64,32),layer='glow_slug',parts=[
 P('head',None,(0,0),(-2,-3,-2,4,3,4),(0,24,-6,0,0,0),'slime'),
 P('stalk_l','head',(16,0),(-0.5,-3,-0.5,1,3,1),(1.2,-3,-1,-0.3,0,0.3),'slime'),
 P('stalk_r','head',(16,4),(-0.5,-3,-0.5,1,3,1),(-1.2,-3,-1,-0.3,0,-0.3),'slime'),
 P('tip_l','stalk_l',(20,0),(-1,-2,-1,2,2,2),(0,-3,0,0,0,0),'eye'),
 P('tip_r','stalk_r',(20,4),(-1,-2,-1,2,2,2),(0,-3,0,0,0,0),'eye'),
 P('seg1',None,(0,8),(-3,-4,-3,6,4,6),(0,24,-1,0,0,0),'slime'),
 P('seg2',None,(28,8),(-2,-3,-2,4,3,4),(0,24,4,0,0,0),'slime'),
 P('seg3',None,(0,20),(-1,-2,-1,2,2,2),(0,24,7,0,0,0),'slime'),
])
# ---------------- Shardling ----------------
SPECS['Shardling']=dict(tex='shardling',size=(64,32),parts=[
 P('head',None,(0,0),(-3,-5,-3,6,5,6),(0,11,0,0,0,0),'shell'),
 P('crystal_top','head',(24,0),(-1,-4,-1,2,4,2),(0,-5,0,0,0,0),'crystal'),
 P('crystal_l','head',(32,0),(-1,-3,-1,2,3,2),(-2,-4,1,0,0,-0.45),'crystal'),
 P('crystal_r','head',(40,0),(-1,-3,-1,2,3,2),(2,-4,1,0,0,0.45),'crystal'),
 P('body',None,(0,11),(-3,0,-2,6,7,4),(0,11,0,0,0,0),'shell'),
 P('back1','body',(24,11),(-1,-5,-1,2,5,2),(-1.5,3,2.5,0.5,0,0),'crystal'),
 P('back2','body',(32,11),(-1,-5,-1,2,5,2),(1.5,5,2.5,0.5,0,0),'crystal'),
 P('arm_r',None,(48,0),(-1,-1,-1,2,6,2),(-4,12,0,0,0,0),'shell'),
 P('arm_l',None,(56,0),(-1,-1,-1,2,6,2),(4,12,0,0,0,0),'shell'),
 P('leg_r',None,(48,8),(-1.5,0,-1.5,3,6,3),(-1.5,18,0,0,0,0),'shell'),
 P('leg_l',None,(48,17),(-1.5,0,-1.5,3,6,3),(1.5,18,0,0,0,0),'shell'),
])
# ---------------- Deep Guardian ----------------
SPECS['DeepGuardian']=dict(tex='deep_guardian',size=(128,128),parts=[
 P('head',None,(0,0),(-4,-8,-4,8,8,8),(0,8,-4,0.2,0,0),'stone'),
 P('body',None,(0,16),(-9,0,-5,18,12,10),(0,6,0,0.3,0,0),'stone'),
 P('heart','body',(56,40),(-3,-3,0,6,5,3),(0,9.5,5,0,0,0),'core'),
 P('spine1','body',(0,64),(-1.5,-6,-1.5,3,6,3),(0,-0.5,3.5,-0.9,0,0),'crystal'),
 P('spine2','body',(12,64),(-1.5,-8,-1.5,3,8,3),(0,2,5,-0.75,0,0),'crystal'),
 P('spine3','body',(24,64),(-1.5,-9,-1.5,3,9,3),(0,5,5,-0.6,0,0),'crystal'),
 P('spine4','body',(36,64),(-1.5,-6,-1.5,3,6,3),(-4.5,7.5,5,-0.5,0,-0.3),'crystal'),
 P('spine5','body',(48,64),(-1.5,-6,-1.5,3,6,3),(4.5,7.5,5,-0.5,0,0.3),'crystal'),
 P('shoulder_l','body',(0,80),(-2,-9,-2,4,9,4),(-9,1,0,0,0,-0.5),'crystal'),
 P('shoulder_r','body',(16,80),(-2,-9,-2,4,9,4),(9,1,0,0,0,0.5),'crystal'),
 P('shoulder2_l','body',(32,80),(-1.5,-6,-1.5,3,6,3),(-7,0,3,-0.5,0,-0.7),'crystal'),
 P('shoulder2_r','body',(44,80),(-1.5,-6,-1.5,3,6,3),(7,0,3,-0.5,0,0.7),'crystal'),
 P('arm_r',None,(64,0),(-3.5,-2,-3.5,7,17,7),(-12.5,9,0,0,0,0.1),'stone'),
 P('arm_l',None,(92,0),(-3.5,-2,-3.5,7,17,7),(12.5,9,0,0,0,-0.1),'stone'),
 P('leg_r',None,(0,40),(-3.5,0,-3.5,7,8,7),(-4.5,16,0,0,0,0),'stone'),
 P('leg_l',None,(28,40),(-3.5,0,-3.5,7,8,7),(4.5,16,0,0,0,0),'stone'),
])
EYES={'Shardling':[('head',[(1,2),(4,2)])],'DeepGuardian':[('head',[(1,3),(2,3),(5,3),(6,3)])]}

def paint(cls,spec):
    W,H=spec['size']; body=Image.new('RGBA',(W,H),(0,0,0,0)); glow=Image.new('RGBA',(W,H),(0,0,0,0))
    rng=random.Random(hash(cls)&0xffff)
    rng=random.Random(sum(map(ord,cls)))
    for p in spec['parts']:
        u,v=p['uv']; x,y,z,w,h,d=p['box']; w,h,d=int(w),int(h),int(d)
        for f,(fx,fy,fw,fh) in faces(u,v,w,h,d).items():
            for j in range(fh):
                for i in range(fw):
                    c,g=MAT[p['mat']](f,i,j,fw,fh,rng)
                    body.putpixel((fx+i,fy+j),c+(255,))
                    if g is not None: glow.putpixel((fx+i,fy+j),g+(255,))
    for part,pts in EYES.get(cls,[]):
        p=[q for q in spec['parts'] if q['name']==part][0]
        u,v=p['uv']; x,y,z,w,h,d=p['box']; fx,fy,fw,fh=faces(u,v,int(w),int(h),int(d))['front']
        for (i,j) in pts:
            body.putpixel((fx+i,fy+j),L0+(255,)); glow.putpixel((fx+i,fy+j),L0+(255,))
    body.save(TEX+spec['tex']+'.png'); glow.save(TEX+spec['tex']+'_glow.png')

def fl(v):
    s=repr(float(v)); return s+'F'
def gen_layer(cls,spec):
    out=[];names=[p['name'] for p in spec['parts']]
    out.append('        MeshDefinition mesh = new MeshDefinition();\n        PartDefinition root = mesh.getRoot();')
    for p in spec['parts']:
        parent='root' if p['parent'] is None else 'pd_'+p['parent']
        u,v=p['uv']; b=p['box']; q=p['pose']
        out.append('        PartDefinition pd_%s = %s.addOrReplaceChild("%s", CubeListBuilder.create().texOffs(%d, %d).addBox(%s, %s, %s, %s, %s, %s),\n                PartPose.offsetAndRotation(%s, %s, %s, %s, %s, %s));'%(
            p['name'],parent,p['name'],u,v,*[fl(t) for t in b],*[fl(t) for t in q]))
    W,H=spec['size']
    out.append('        return LayerDefinition.create(mesh, %d, %d);'%(W,H))
    return '\n'.join(out)

for cls,spec in SPECS.items(): paint(cls,spec)
# write fragments for Java templates
os.makedirs(ROOT+'tools/gen',exist_ok=True)
for cls,spec in SPECS.items():
    open(ROOT+'tools/gen/%s_layer.txt'%cls,'w').write(gen_layer(cls,spec))
    open(ROOT+'tools/gen/%s_parts.txt'%cls,'w').write(repr([(p['name'],p['parent']) for p in spec['parts']]))
print('ok')
