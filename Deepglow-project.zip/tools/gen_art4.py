# Art pass 4: framed blocks (teal), outlined ores, ingot redrawn from the netherite ingot shape. Run last.
import random, math
from PIL import Image
OUT='/home/claude/dg/src/main/resources/assets/deepglow/textures/'
RP='/home/claude/rp1/assets/minecraft/textures/block/'
def hx(s): return tuple(int(s[i:i+2],16) for i in (1,3,5))+(255,)
L0=hx('#eafffb');L1=hx('#9ff7e8');L2=hx('#3fd3c1');L3=hx('#1a9a9a');L4=hx('#0e6670');L5=hx('#093a44')
PALE=hx('#bfe9e6'); K=hx('#05191e')
S0=hx('#1b1f29');S1=hx('#2a303d');S2=hx('#3a4254');S3=hx('#4e5870')
def new(): return Image.new('RGBA',(16,16),(0,0,0,0))
# ---- framed blocks: border, gradient field, pale square ring with corner diagonals, inner square with X ----
def framed(base_light,base_dark,inner_cross):
    im=new(); p=im.load()
    for y in range(16):
        for x in range(16):
            e=min(x,y,15-x,15-y)
            t=(x+y)/30.0
            field=base_light if t<0.33 else (L2 if t<0.66 else base_dark)
            c=field
            if e==0: c=L5
            elif e==1: c=L4 if (x+y)>15 else L3
            ring=(2<=x<=13 and 2<=y<=13) and (min(x-2,y-2,13-x,13-y)==2 if False else False)
            p[x,y]=c
    # pale ring square at 3..12
    for i in range(3,13):
        for (x,y) in ((i,3),(i,12),(3,i),(12,i)): p[x,y]=PALE if (x+y)<15 or True else PALE
    # corner diagonals from ring corners to border
    for k in range(3): 
        for (x,y) in ((2-k,2-k),(13+k,2-k),(2-k,13+k),(13+k,13+k)): 
            if 1<=x<=14 and 1<=y<=14: p[x,y]=PALE
    # inner square 6..9 ring + X
    for i in range(6,10):
        for (x,y) in ((i,6),(i,9),(6,i),(9,i)): p[x,y]=L1 if inner_cross else L0
    for (x,y) in ((7,7),(8,8),(7,8),(8,7)): p[x,y]=L0 if (x+y)%2==0 else L1
    # diagonals inside ring toward centre
    for k in range(3): 
        for (x,y) in ((4+k,4+k),(11-k,4+k),(4+k,11-k),(11-k,11-k)):
            if not (6<=x<=9 and 6<=y<=9): p[x,y]=L3 if (x+y)<15 else L4
    return im
framed(L1,L3,True).save(OUT+'block/lumenite_block.png')
# polished: same family but recessed field and bright inner ring only
pl=framed(L2,L4,False); pp=pl.load()
for y in range(4,12):
    for x in range(4,12):
        if not (6<=x<=9 and 6<=y<=9) and pp[x,y] not in (L3,L4,PALE): pp[x,y]=L3
pl.save(OUT+'block/polished_lumenite.png')
# ---- ores with dark outline around every crystal ----
def ore(base_name,seed):
    im=Image.open(RP+base_name).convert('RGBA'); p=im.load()
    gem=set()
    big=[(2,2),(9,3),(5,9),(11,10)]
    G=["efe.","futd","ftwd",".ddk"]
    cmap={'e':L3,'f':L4,'u':L1,'t':L2,'w':L0,'d':L3,'k':L5}
    cols={}
    for (bx,by) in big:
        for j,r in enumerate(G):
            for i,ch in enumerate(r):
                if ch in cmap and 0<=bx+i<16 and 0<=by+j<16: cols[(bx+i,by+j)]=cmap[ch]
    for (sx,sy) in [(1,9),(13,5),(7,13),(7,1)]:
        for pt,c in (((sx,sy),L1),((sx+1,sy),L2),((sx,sy+1),L4)): cols[pt]=c
    for (sx,sy) in [(5,5),(13,13),(3,13),(14,1)]:
        cols[(sx,sy)]=L1; cols[(sx+1,sy)]=L1
    for (x,y),c in cols.items():
        if 0<=x<16 and 0<=y<16: p[x,y]=c
    for (x,y) in list(cols):
        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
            if True:
                X,Y=x+dx,y+dy
                if 0<=X<16 and 0<=Y<16 and (X,Y) not in cols: p[X,Y]=K
    # dark frame around the whole block face
    for i in range(16):
        for (x,y) in ((i,0),(i,15),(0,i),(15,i)): p[x,y]=hx('#0f1318')
    for i in range(1,15):
        for (x,y) in ((i,1),(i,14),(1,i),(14,i)):
            if (x,y) not in cols and p[x,y]!=K:
                r,g,b,a=p[x,y]; p[x,y]=(int(r*0.8),int(g*0.8),int(b*0.8),255)
    return im
ore('stone.png',1).save(OUT+'block/lumenite_ore.png'); ore('deepslate.png',2).save(OUT+'block/deepslate_lumenite_ore.png')
# ---- ingot from the netherite ingot sprite ----
src=Image.open('/home/claude/rp1/assets/minecraft/textures/item/netherite_ingot.png').convert('RGBA').resize((16,16),Image.NEAREST)
sp=src.load(); lums=sorted(set(sp[x,y][:3] for y in range(16) for x in range(16) if sp[x,y][3]>0),key=lambda c:sum(c))
im=new(); p=im.load()
ramp=[K,S0,S1,S2,S3,L3,L2,L1]
n=len(lums)
for y in range(16):
    for x in range(16):
        if sp[x,y][3]>0:
            idx=lums.index(sp[x,y][:3]); t=idx/max(1,n-1)
            p[x,y]=K if t==0 else S0 if t<0.25 else S1 if t<0.5 else S2 if t<0.75 else S3
# beetle glow: teal highlights along the lit top edge and a glowing seam
pts=[(x,y) for y in range(16) for x in range(16) if p[x,y][3]>0 and p[x,y]!=K]
ys=[q[1] for q in pts]; ymin=min(ys); ymax=max(ys)
for (x,y) in pts:
    if p[x,y] in (S3,): p[x,y]=L2 if (x+y)%4 else L1       # glowing lit top face (like the abdomen)
    elif p[x,y]==S2 and y>=ymax-2: p[x,y]=L3                # glowing seam on the front face
for (x,y) in pts:
    if y==ymin and p[x,y]!=K: p[x,y]=L0
im.save('/tmp/ingot_raw.png')
im.save(OUT+'item/lumenite_ingot.png')
print('art4 ok',n)
