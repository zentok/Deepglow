# Tiny software renderer: a player in the beetle armor (checks UV/pose/looks without the game).
import json, math, sys
import numpy as np
from PIL import Image
SPEC=json.load(open('/tmp/beetle_spec.json'))
TD='/home/claude/dg/src/main/resources/assets/deepglow/textures/models/armor/'
def rotzyx(rx,ry,rz):
    cx,sx=math.cos(rx),math.sin(rx); cy,sy=math.cos(ry),math.sin(ry); cz,sz=math.cos(rz),math.sin(rz)
    Rx=np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]]);Ry=np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]]);Rz=np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])
    return Rz@Ry@Rx
def quads(box,uv,grow,tex=(64,128)):
    x0,y0,z0,w,h,d=box; u,v=uv
    X0,Y0,Z0,X1,Y1,Z1=x0-grow,y0-grow,z0-grow,x0+w+grow,y0+h+grow,z0+d+grow
    R={'top':(u+d,v,w,d),'bottom':(u+d+w,v,w,d),'right':(u,v+d,d,h),'front':(u+d,v+d,w,h),'left':(u+d+w,v+d,d,h),'back':(u+2*d+w,v+d,w,h)}
    P={'front':lambda s,t:(X0+s*(X1-X0),Y0+t*(Y1-Y0),Z0),'back':lambda s,t:(X1-s*(X1-X0),Y0+t*(Y1-Y0),Z1),
       'right':lambda s,t:(X0,Y0+t*(Y1-Y0),Z1-s*(Z1-Z0)),'left':lambda s,t:(X1,Y0+t*(Y1-Y0),Z0+s*(Z1-Z0)),
       'top':lambda s,t:(X0+s*(X1-X0),Y0,Z1-t*(Z1-Z0)),'bottom':lambda s,t:(X0+s*(X1-X0),Y1,Z0+t*(Z1-Z0))}
    out=[]
    for f in R:
        r=R[f]; q=[]
        for (s,t) in ((0,0),(1,0),(1,1),(0,1)):
            q.append((P[f](s,t),((r[0]+s*r[2])/tex[0],(r[1]+t*r[3])/tex[1])))
        out.append((f,q))
    return out
BASEBOX={'head':((-4,-8,-4,8,8,8),(0,0,0)),'body':((-4,0,-2,8,12,4),(0,0,0)),'right_arm':((-3,-2,-2,4,12,4),(-5,2,0)),'left_arm':((-1,-2,-2,4,12,4),(5,2,0)),
         'right_leg':((-2,0,-2,4,12,4),(-1.9,12,0)),'left_leg':((-2,0,-2,4,12,4),(1.9,12,0))}
XP={}
def build_scene(models,pose):
    """models: list of (spec,visible_parts). returns list of (verts3d(4), uv(4), tex_id, color|None)"""
    tris=[]
    # skin
    skin={'head':(200,155,120),'body':(60,110,180),'right_arm':(200,155,120),'left_arm':(200,155,120),'right_leg':(50,60,120),'left_leg':(50,60,120)}
    def pose_of(name):
        return pose.get(name,(0,0,0))
    def chain(name,parent_of,off_of):
        pass
    def part_matrix(model,name):
        # returns function mapping local->model space for base part or extra
        base=BASEBOX.get(name)
        if base: 
            org=np.array(base[1],float); R=rotzyx(*pose_of(name)); return lambda p: R@np.array(p)+org
        e=[x for x in model['extras'] if x['name']==name][0]
        pf=part_matrix(model,e['parent']); p=e['pose']; rr=XP.get(e['name'],p[3:]); R=rotzyx(*rr); org=np.array(p[:3],float)
        return lambda q: pf(R@np.array(q)+org)
    out=[]
    for part,(box,org) in BASEBOX.items():
        m=part_matrix({'extras':[]},part)
        for f,q in quads(box,(0,0),0.0):
            out.append(([m(v) for v,_ in q],[uv for _,uv in q],-1,skin[part]))
    for ti,(model,vis) in enumerate(models):
        sp=model
        for part in vis:
            if part in sp['base']:
                box,_=BASEBOX[part]; m=part_matrix(sp,part)
                for f,q in quads(box,{'head':(0,0),'body':(16,16),'right_arm':(40,16),'left_arm':(40,16),'right_leg':(0,16),'left_leg':(0,16)}[part],sp['deform']):
                    out.append(([m(v) for v,_ in q],[uv for _,uv in q],ti,None))
        for e in sp['extras']:
            root=e['parent']
            while root not in BASEBOX: root=[x for x in sp['extras'] if x['name']==root][0]['parent']
            if root not in vis: continue
            if e['name'].startswith('wing_') and not XP: continue
            m=part_matrix(sp,e['name'])
            for f,q in quads(e['box'],tuple(e['uv']),0.0):
                out.append(([m(v) for v,_ in q],[uv for _,uv in q],ti,None))
    return out
def render(models,pose,yaw,pitch=0.25,W=420,H=620,scale=14.0):
    tex=[(np.array(Image.open(TD+m[0]['file']+'.png').convert('RGBA')),np.array(Image.open(TD+m[0]['file']+'_glow.png').convert('RGBA'))) for m in models]
    quads_=build_scene(models,pose)
    img=np.zeros((H,W,3),float); img[:]=(11,18,23); zb=np.full((H,W),1e9)
    cy,sy=math.cos(yaw),math.sin(yaw); cp,sp_=math.cos(pitch),math.sin(pitch)
    def proj(p):
        x,y,z=p[0],-(p[1]-24),-p[2]    # y up, front toward +z... model front is -z => world +z after flip
        x2=cy*x+sy*z; z2=-sy*x+cy*z
        y2=cp*y-sp_*z2; z3=sp_*y+cp*z2
        return (W/2+x2*scale, H*0.93-y2*scale, z3)
    for verts,uvs,ti,color in quads_:
        P=[proj(v) for v in verts]
        # face normal for shading (in view space)
        a=np.array(P[1])-np.array(P[0]); b=np.array(P[3])-np.array(P[0]); n=np.cross(a,b)
        shade=0.55+0.45*min(1,max(0,abs(n[2])/(np.linalg.norm(n)+1e-9)))
        for tri in ((0,1,2),(0,2,3)):
            p0,p1,p2=P[tri[0]],P[tri[1]],P[tri[2]]
            minx=int(max(0,min(p0[0],p1[0],p2[0]))); maxx=int(min(W-1,max(p0[0],p1[0],p2[0])+1))
            miny=int(max(0,min(p0[1],p1[1],p2[1]))); maxy=int(min(H-1,max(p0[1],p1[1],p2[1])+1))
            den=(p1[1]-p2[1])*(p0[0]-p2[0])+(p2[0]-p1[0])*(p0[1]-p2[1])
            if abs(den)<1e-9: continue
            xs=np.arange(minx,maxx+1)+0.5; ys=np.arange(miny,maxy+1)+0.5
            gx,gy=np.meshgrid(xs,ys)
            l0=((p1[1]-p2[1])*(gx-p2[0])+(p2[0]-p1[0])*(gy-p2[1]))/den
            l1=((p2[1]-p0[1])*(gx-p2[0])+(p0[0]-p2[0])*(gy-p2[1]))/den
            l2=1-l0-l1
            m=(l0>=-1e-4)&(l1>=-1e-4)&(l2>=-1e-4)
            if not m.any(): continue
            z=l0*p0[2]+l1*p1[2]+l2*p2[2]
            if color is not None:
                col=np.zeros(gx.shape+(3,)); col[:]=np.array(color)*shade; alpha=np.ones(gx.shape,bool)
            else:
                uu=l0*uvs[tri[0]][0]+l1*uvs[tri[1]][0]+l2*uvs[tri[2]][0]; vv=l0*uvs[tri[0]][1]+l1*uvs[tri[1]][1]+l2*uvs[tri[2]][1]
                tx=np.clip((uu*64).astype(int),0,63); ty=np.clip((vv*128).astype(int),0,127)
                body,glow=tex[ti]; px=body[ty,tx]; gl=glow[ty,tx]
                alpha=px[...,3]>128
                col=px[...,:3].astype(float)*shade
                gm=gl[...,3]>128
                col=np.where(gm[...,None],np.minimum(255,col*0.5+gl[...,:3].astype(float)*0.9),col)
            ok=m&alpha&(z<zb[miny:maxy+1,minx:maxx+1]-(0 if color is None else -0.01))
            sub=img[miny:maxy+1,minx:maxx+1]; zs=zb[miny:maxy+1,minx:maxx+1]
            sub[ok]=col[ok]; zs[ok]=z[ok]
    return Image.fromarray(np.clip(img,0,255).astype('uint8'))
def open_preview():
    O,I=SPEC['outer'],SPEC['inner']
    XP.update({'shell_l':(0.26,0,-0.61),'shell_r':(0.26,0,0.61),'wing_l':(0,0,-0.15),'wing_r':(0,0,0.15)})
    models=[(O,['head','body','right_arm','left_arm','right_leg','left_leg']),(I,['body','right_leg','left_leg'])]
    pose={'right_arm':(0.1,0,0.3),'left_arm':(0.1,0,-0.3)}
    ims=[render(models,pose,yaw,pitch=0.2) for yaw in (0.0,math.pi,math.pi/2)]
    sheet=Image.new('RGB',(420*3,620)); [sheet.paste(im,(i*420,0)) for i,im in enumerate(ims)]
    sheet.save('/tmp/beetle_wings.png')
if __name__=='__main__':
    O,I=SPEC['outer'],SPEC['inner']
    models=[(O,['head','body','right_arm','left_arm','right_leg','left_leg']),(I,['body','right_leg','left_leg'])]
    pose={'right_arm':(0.1,0,0.08),'left_arm':(-0.1,0,-0.08),'right_leg':(-0.2,0,0),'left_leg':(0.2,0,0)}
    ims=[render(models,pose,yaw) for yaw in (math.pi+0.55,math.pi-0.55,math.pi/2*1.0+0.1,0.55)]
    sheet=Image.new('RGB',(420*4,620)); [sheet.paste(im,(i*420,0)) for i,im in enumerate(ims)]
    sheet.save('/tmp/beetle_preview.png'); open_preview(); print('rendered')
