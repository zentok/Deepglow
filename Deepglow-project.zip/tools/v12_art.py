# 1.2.0 block + item textures (pixel art). Run after v12_mobs.py
import math, random
from PIL import Image
OUT='/home/claude/dg/src/main/resources/assets/deepglow/textures/'
def hx(s): return tuple(int(s[i:i+2],16) for i in (1,3,5))+(255,)
L0=hx('#eafffb');L1=hx('#9ff7e8');L2=hx('#3fd3c1');L3=hx('#1a9a9a');L4=hx('#0e6670');L5=hx('#093a44')
S0=hx('#14171f');S1=hx('#242a36');S2=hx('#3a4254');S3=hx('#566179');K=hx('#05191e')
def new(): return Image.new('RGBA',(16,16),(0,0,0,0))
def A(c,a): return c[:3]+(a,)
rnd=random.Random(12)

# ---- lumenite glass
def glass():
    im=new(); p=im.load()
    for y in range(16):
        for x in range(16):
            e=min(x,y,15-x,15-y)
            if e==0: p[x,y]=L3
            elif e==1: p[x,y]=A(L1,120) if (x+y)<15 else A(L2,110)
            else: p[x,y]=A(L1,46)
    for (x,y) in ((3,3),(4,4),(5,5),(3,4),(4,3)): p[x,y]=A(L0,230)
    for (x,y) in ((10,2),(11,3),(12,4)): p[x,y]=A(L0,200)
    for (x,y) in ((9,11),(10,12),(11,13)): p[x,y]=A(L1,170)
    for (x,y) in ((0,0),(15,0),(0,15),(15,15)): p[x,y]=L2
    return im
glass().save(OUT+'block/lumenite_glass.png')

# ---- chiseled lumenite
def chiseled():
    im=new(); p=im.load()
    for y in range(16):
        for x in range(16):
            e=min(x,y,15-x,15-y)
            c=L3 if (x*7+y*3)%11 else L4
            if e==0: c=L5
            elif e==1: c=L2 if (x+y)<15 else L4
            m=abs(x-7.5)+abs(y-7.5)
            if 5<=m<=6.5: c=L1
            elif m<5:
                c=L5
                if m<=3.5: c=L4
                if m<=2.5: c=L2
                if m<=1.5: c=L0
            p[x,y]=c
    return im
chiseled().save(OUT+'block/chiseled_lumenite.png')

# ---- pillar
def pillar_side():
    im=new(); p=im.load()
    for y in range(16):
        for x in range(16):
            if x in(0,15): c=L5
            elif x in(1,14): c=L3
            else:
                f=[L4,L3,L2,L2,L3,L4,L4,L4,L3,L2,L2,L3,L4,L4][x-1] if False else None
                col=(x-2)%6
                c=[L4,L3,L2,L1,L2,L3][col]
            if y in(0,15): c=L5
            elif y in(1,14): c=L1 if y==1 else L4
            elif y in(2,13): c=L3 if y==2 else L5
            p[x,y]=c
    return im
pillar_side().save(OUT+'block/lumenite_pillar_side.png')
def pillar_top():
    im=new(); p=im.load()
    for y in range(16):
        for x in range(16):
            e=min(x,y,15-x,15-y)
            c=L3 if (x*5+y*3)%7 else L4
            if e==0: c=L5
            elif e==1: c=L2
            elif e==3: c=L1
            elif e>=5: c=L4 if e==5 else L5
            if 6<=x<=9 and 6<=y<=9: c=L0 if (x in(7,8) and y in(7,8)) else L1
            p[x,y]=c
    return im
pillar_top().save(OUT+'block/lumenite_pillar_top.png')

# ---- deep lantern
def lantern():
    im=new(); p=im.load()
    for y in range(16):
        for x in range(16):
            e=min(x,y,15-x,15-y)
            d=math.hypot(x-7.5,y-7.5)
            if e==0: c=S0
            elif e==1: c=S3 if (x+y)<15 else S1
            elif e==2: c=S2 if (x+y)<15 else S1
            else:
                c=L0 if d<2 else L1 if d<3.5 else L2 if d<5 else L3 if d<6.5 else L4
            p[x,y]=c
    # cage bars
    for i in range(3,13):
        for x in (5,10): 
            if p[x,i][:3]!=S0[:3]: p[x,i]=S1 if i%2 else S2
    for i in range(3,13):
        for y in (5,10): p[i,y]=S1 if i%2 else S2
    for (x,y) in ((2,2),(13,2),(2,13),(13,13)): p[x,y]=L2
    return im
lantern().save(OUT+'block/deep_lantern.png')

# ---- crystal cluster (cross model, transparent)
def crystal(im,cx,top,base,hw):
    p=im.load()
    for y in range(top,base+1):
        w=min(hw,y-top)
        for x in range(cx-w,cx+w+1):
            rel=(x-(cx-w))/max(1,2*w)
            c=L1 if (x==cx-w and w>0) else L2 if rel<0.5 else L3 if rel<0.85 else L4
            if y>=base-1: c=L4 if c in(L1,L2) else L5
            if 0<=x<16 and 0<=y<16: p[x,y]=c
def outline_alpha(im,col=L5):
    pm=im.copy().load(); p=im.load()
    for y in range(16):
        for x in range(16):
            if pm[x,y][3]==0:
                for a,b in ((1,0),(-1,0),(0,1),(0,-1)):
                    X,Y=x+a,y+b
                    if 0<=X<16 and 0<=Y<16 and pm[X,Y][3]>0 and pm[X,Y][:3]!=col[:3]: p[x,y]=col; break
cl=new()
crystal(cl,10,10,15,1); crystal(cl,2,8,15,1); crystal(cl,12,5,15,2); crystal(cl,7,1,15,2)
q=cl.load()
for (x,y) in ((6,4),(6,5),(6,6)): q[x,y]=L0
q[11,8]=L0
outline_alpha(cl); cl.save(OUT+'block/lumenite_crystal.png')

# ---- glowcap mushrooms
def cap(im,cx,base,cr,stem_h):
    p=im.load()
    STEM=hx('#c9e8e2'); STEM2=hx('#8fb8b4')
    top=base-stem_h
    for y in range(top,base+1):
        for x in (cx,cx+1):
            if 0<=x<16 and 0<=y<16: p[x,y]=STEM if x==cx else STEM2
    for dy in range(-cr,1):
        w=int(round(cr*math.sqrt(max(0,1-(dy/(cr+0.4))**2))))
        for dx in range(-w,w+2):
            x=cx+dx; y=top+dy
            if 0<=x<16 and 0<=y<16:
                c=L2
                if dy==-cr or (dy==-cr+1 and dx<=0): c=L1
                if dx>=w: c=L3
                if dy==0: c=L4
                p[x,y]=c
    x=cx-1;y=top-cr+1
    if 0<=x<16 and 0<=y<16 and cr>=2: p[x,y]=L0
gc=new()
cap(gc,2,15,2,3); cap(gc,9,15,3,6); cap(gc,13,15,1,3)
outline_alpha(gc); gc.save(OUT+'block/glowcap.png')

# ================= items =================
def outline(im,col=L5):
    pm=im.copy().load(); p=im.load()
    for y in range(16):
        for x in range(16):
            if pm[x,y][3]==0:
                for a,b in ((1,0),(-1,0),(0,1),(0,-1)):
                    X,Y=x+a,y+b
                    if 0<=X<16 and 0<=Y<16 and pm[X,Y][3]>0: p[x,y]=col; break
# shard
sh=new(); p=sh.load()
for x in range(3,14):
    cy=16-x; w=min(2.2,(x-3)/2+0.6,(13-x)/1.6+0.5)
    for y in range(16):
        dd=y-cy
        if abs(dd)<=w:
            c=L1 if dd<-0.8 else L2 if dd<0.7 else L4
            if (x==5 or x==6) and dd<-0.5: c=L0
            p[x,y]=c
outline(sh); sh.save(OUT+'item/lumenite_shard.png')
# gel
ge=new(); p=ge.load()
for y in range(16):
    for x in range(16):
        e1=((x-7.5)/6.0)**2+((y-9.5)/4.6)**2
        e2=((x-7.5)/3.2)**2+((y-5.6)/2.8)**2
        if e1<=1 or e2<=1:
            dy=y-9.5
            c=L2 if dy<1.5 else L3
            if dy>3: c=L4
            p[x,y]=c
for (x,y) in ((5,8),(6,8),(5,9),(7,5),(8,5)): p[x,y]=L0
for (x,y) in ((6,7),(9,6),(10,10)): p[x,y]=L1
for (x,y) in ((12,10),(12,11),(12,12)): p[x,y]=L2
outline(ge); ge.save(OUT+'item/glow_gel.png')
# deep heart
he=new(); p=he.load()
for y in range(16):
    for x in range(16):
        X=(x-7.5)/6.2; Y=-(y-7.0)/6.2
        v=(X*X+Y*Y-1)**3 - X*X*Y**3
        if v<=0:
            c=L2
            if X<-0.05: c=L1 if Y>0 else L2
            else: c=L3 if Y>-0.3 else L4
            if abs(Y-(-0.9*abs(X)+0.15))<0.12 and Y<0.45: c=L0
            p[x,y]=c
for (x,y) in ((7,7),(8,7),(7,8),(8,8)): p[x,y]=L0
for (x,y) in ((4,4),(5,3)): p[x,y]=L0
outline(he); he.save(OUT+'item/deep_heart.png')
# scanner
sc=new(); p=sc.load()
for y in range(16):
    for x in range(16):
        d=math.hypot(x-7.5,y-8.5)
        if d<=6.6:
            c=S3 if d>5.4 else S1
            if d>5.4 and (x+y)>14: c=S2
            if d<=5.4:
                c=L5 if d>3.4 else L4 if d>1.4 else L3
            p[x,y]=c
for k in range(-3,4):
    x=8+k; y=9-k
    if 0<=x<16 and 0<=y<16 and math.hypot(x-7.5,y-8.5)<5: p[x,y]=L0
for (x,y) in ((7,1),(8,1),(6,2),(9,2)): p[x,y]=S3
for (x,y) in ((7,0),(8,0)): p[x,y]=S2
for (x,y) in ((3,8),(12,8),(8,3),(8,13)): p[x,y]=L2
outline(sc,S0); sc.save(OUT+'item/lumenite_scanner.png')
# eggs
def egg(base,alt,spot):
    e=new(); p=e.load()
    for y in range(16):
        for x in range(16):
            dx=(x-7.5)/5.2; dy=(y-8.5)/6.6
            if dx*dx+dy*dy<=1:
                c=base if (x*3+y*5)%7 else alt
                if ((x-7)**2+(y-9)**2)<14 or (y in(6,7) and x>3): c=spot
                p[x,y]=c+(255,)
    return e
egg(hx('#0f6f6a')[:3],hx('#18948a')[:3],hx('#9ff7e8')[:3]).save(OUT+'item/glow_slug_spawn_egg.png')
egg(hx('#2e3442')[:3],hx('#3a4254')[:3],hx('#3fd3c1')[:3]).save(OUT+'item/shardling_spawn_egg.png')
egg(hx('#2b3340')[:3],hx('#48566c')[:3],hx('#9ff7e8')[:3]).save(OUT+'item/deep_guardian_spawn_egg.png')
print('art ok')
