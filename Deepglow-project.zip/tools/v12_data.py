# 1.2.0 data/resources: merges into the existing files. Run after gen_data.py.
import json, os
R='/home/claude/dg/src/main/resources/'
A=R+'assets/deepglow/'; D=R+'data/deepglow/'
def jd(p,o):
    os.makedirs(os.path.dirname(p),exist_ok=True); json.dump(o,open(p,'w',encoding='utf-8'),indent=2,ensure_ascii=False)
def ld(p): return json.load(open(p,encoding='utf-8'))
# ----- blocks
for b in ('lumenite_glass','chiseled_lumenite','deep_lantern'):
    jd(A+'models/block/%s.json'%b,{'parent':'minecraft:block/cube_all','textures':{'all':'deepglow:block/%s'%b}})
    jd(A+'blockstates/%s.json'%b,{'variants':{'':{'model':'deepglow:block/%s'%b}}})
    jd(A+'models/item/%s.json'%b,{'parent':'deepglow:block/%s'%b})
for b in ('lumenite_crystal','glowcap'):
    jd(A+'models/block/%s.json'%b,{'parent':'minecraft:block/cross','textures':{'cross':'deepglow:block/%s'%b}})
    jd(A+'models/item/%s.json'%b,{'parent':'minecraft:item/generated','textures':{'layer0':'deepglow:block/%s'%b}})
jd(A+'blockstates/glowcap.json',{'variants':{'':{'model':'deepglow:block/glowcap'}}})
m='deepglow:block/lumenite_crystal'
jd(A+'blockstates/lumenite_crystal.json',{'variants':{'facing=up':{'model':m},'facing=down':{'model':m,'x':180},'facing=north':{'model':m,'x':90},
    'facing=east':{'model':m,'x':90,'y':90},'facing=south':{'model':m,'x':90,'y':180},'facing=west':{'model':m,'x':90,'y':270}}})
jd(A+'models/block/lumenite_pillar.json',{'parent':'minecraft:block/cube_column','textures':{'end':'deepglow:block/lumenite_pillar_top','side':'deepglow:block/lumenite_pillar_side'}})
jd(A+'blockstates/lumenite_pillar.json',{'variants':{'axis=y':{'model':'deepglow:block/lumenite_pillar'},'axis=z':{'model':'deepglow:block/lumenite_pillar','x':90},'axis=x':{'model':'deepglow:block/lumenite_pillar','x':90,'y':90}}})
jd(A+'models/item/lumenite_pillar.json',{'parent':'deepglow:block/lumenite_pillar'})
# ----- items
for i in ('lumenite_shard','glow_gel','deep_heart','lumenite_scanner','glow_slug_spawn_egg','shardling_spawn_egg','deep_guardian_spawn_egg'):
    jd(A+'models/item/%s.json'%i,{'parent':'minecraft:item/generated','textures':{'layer0':'deepglow:item/%s'%i}})
# ----- loot
def drop_self(n): return {'type':'minecraft:block','pools':[{'rolls':1,'bonus_rolls':0,'entries':[{'type':'minecraft:item','name':'deepglow:%s'%n}],'conditions':[{'condition':'minecraft:survives_explosion'}]}]}
for b in ('chiseled_lumenite','lumenite_pillar','glowcap','deep_lantern'): jd(D+'loot_tables/blocks/%s.json'%b,drop_self(b))
SILK=[{'condition':'minecraft:match_tool','predicate':{'enchantments':[{'enchantment':'minecraft:silk_touch','levels':{'min':1}}]}}]
jd(D+'loot_tables/blocks/lumenite_glass.json',{'type':'minecraft:block','pools':[{'rolls':1,'bonus_rolls':0,'entries':[{'type':'minecraft:item','name':'deepglow:lumenite_glass','conditions':SILK}]}]})
jd(D+'loot_tables/blocks/lumenite_crystal.json',{'type':'minecraft:block','pools':[{'rolls':1,'bonus_rolls':0,'entries':[{'type':'minecraft:alternatives','children':[
    {'type':'minecraft:item','name':'deepglow:lumenite_crystal','conditions':SILK},
    {'type':'minecraft:item','name':'deepglow:lumenite_shard','functions':[{'function':'minecraft:set_count','count':{'type':'minecraft:uniform','min':1,'max':3}},{'function':'minecraft:explosion_decay'}]}]}]}]})
def mob_pool(item,lo,hi,loot=True):
    f=[{'function':'minecraft:set_count','count':{'type':'minecraft:uniform','min':lo,'max':hi}}]
    if loot: f.append({'function':'minecraft:looting_enchant','count':{'min':0,'max':1}})
    return {'rolls':1,'bonus_rolls':0,'entries':[{'type':'minecraft:item','name':item,'functions':f}]}
jd(D+'loot_tables/entities/glow_slug.json',{'type':'minecraft:entity','pools':[mob_pool('deepglow:glow_gel',0,2)]})
jd(D+'loot_tables/entities/shardling.json',{'type':'minecraft:entity','pools':[mob_pool('deepglow:lumenite_shard',0,2),mob_pool('deepglow:lumenite_dust',0,1)]})
jd(D+'loot_tables/entities/deep_guardian.json',{'type':'minecraft:entity','pools':[
    mob_pool('deepglow:lumenite_ingot',4,8,False),mob_pool('deepglow:lumenite_block',1,2,False),mob_pool('deepglow:lumenite_shard',4,9)]})
# ----- recipes
def shaped(n,pattern,key,count=1):
    jd(D+'recipes/%s.json'%n,{'type':'minecraft:crafting_shaped','pattern':pattern,'key':{k:{'item':v} for k,v in key.items()},'result':{'item':'deepglow:%s'%n,'count':count}})
def shapeless(n,items,count=1,out=None):
    jd(D+'recipes/%s.json'%n,{'type':'minecraft:crafting_shapeless','ingredients':[{'item':i} for i in items],'result':{'item':'deepglow:%s'%(out or n),'count':count}})
I='deepglow:lumenite_ingot'
shaped('lumenite_scanner',[' D ','ICI',' R '],{'D':'deepglow:lumenite_dust','I':I,'C':'minecraft:compass','R':'minecraft:redstone'})
shapeless('lumenite_glass',['minecraft:glass']*4+['deepglow:lumenite_dust'],4)
shaped('chiseled_lumenite',['B','B'],{'B':'deepglow:lumenite_bricks_slab'})
shaped('lumenite_pillar',['B','B'],{'B':'deepglow:lumenite_bricks'},2)
shaped('deep_lantern',['III','IHI','III'],{'I':I,'H':'deepglow:deep_heart'})
shaped('lumenite_crystal',['SS','SS'],{'S':'deepglow:lumenite_shard'})
shapeless('lumenite_dust_from_shard',['deepglow:lumenite_shard'],2,'lumenite_dust')
# ----- worldgen
def st(n,props=None):
    d={'Name':n}
    if props: d['Properties']=props
    return d
prov=lambda n:{'type':'minecraft:simple_state_provider','state':st(n)}
jd(D+'worldgen/configured_feature/lumenite_geode.json',{'type':'minecraft:geode','config':{
 'blocks':{'filling_provider':prov('minecraft:air'),'inner_layer_provider':prov('deepglow:lumenite_block'),'alternate_inner_layer_provider':prov('deepglow:lumenite_lamp'),
   'middle_layer_provider':prov('deepglow:polished_lumenite'),'outer_layer_provider':prov('minecraft:smooth_basalt'),
   'inner_placements':[st('deepglow:lumenite_crystal',{'facing':'up','waterlogged':'false'})],
   'cannot_replace':'#minecraft:features_cannot_replace','invalid_blocks':'#minecraft:geode_invalid_blocks'},
 'layers':{'filling':1.7,'inner_layer':2.2,'middle_layer':3.2,'outer_layer':4.2},
 'crack':{'generate_crack_chance':0.95,'base_crack_size':2.0,'crack_point_offset':2},
 'use_potential_placements_chance':0.45,'use_alternate_layer0_chance':0.083,'placements_require_layer0_alternate':False,
 'outer_wall_distance':{'type':'minecraft:uniform','min_inclusive':4,'max_inclusive':6},
 'distribution_points':{'type':'minecraft:uniform','min_inclusive':3,'max_inclusive':4},
 'point_offset':{'type':'minecraft:uniform','min_inclusive':1,'max_inclusive':2},
 'min_gen_offset':-16,'max_gen_offset':16,'noise_multiplier':0.05,'invalid_blocks_threshold':1}})
jd(D+'worldgen/placed_feature/lumenite_geode.json',{'feature':'deepglow:lumenite_geode','placement':[
 {'type':'minecraft:rarity_filter','chance':32},{'type':'minecraft:in_square'},
 {'type':'minecraft:height_range','height':{'type':'minecraft:uniform','min_inclusive':{'absolute':-58},'max_inclusive':{'absolute':30}}},{'type':'minecraft:biome'}]})
AIR={'type':'minecraft:matching_blocks','blocks':['minecraft:air','minecraft:cave_air']}
jd(D+'worldgen/configured_feature/glowcap_patch.json',{'type':'minecraft:random_patch','config':{'tries':28,'xz_spread':6,'y_spread':2,
 'feature':{'feature':{'type':'minecraft:simple_block','config':{'to_place':prov('deepglow:glowcap')}},
            'placement':[{'type':'minecraft:block_predicate_filter','predicate':AIR}]}}})
jd(D+'worldgen/placed_feature/glowcap_patch.json',{'feature':'deepglow:glowcap_patch','placement':[
 {'type':'minecraft:count','count':24},{'type':'minecraft:in_square'},
 {'type':'minecraft:height_range','height':{'type':'minecraft:uniform','min_inclusive':{'absolute':-56},'max_inclusive':{'absolute':42}}},
 {'type':'minecraft:environment_scan','direction_of_search':'down','max_steps':12,'target_condition':{'type':'minecraft:solid'},'allowed_search_condition':AIR},
 {'type':'minecraft:random_offset','xz_spread':0,'y_spread':1},{'type':'minecraft:biome'}]})
# ----- tags
p=R+'data/minecraft/tags/blocks/mineable/pickaxe.json'; t=ld(p)
for b in ('chiseled_lumenite','lumenite_pillar','deep_lantern','lumenite_crystal'):
    if 'deepglow:'+b not in t['values']: t['values'].append('deepglow:'+b)
jd(p,t)
# ----- lang
EN={'block.deepglow.lumenite_crystal':'Lumenite Crystal','block.deepglow.lumenite_glass':'Lumenite Glass','block.deepglow.chiseled_lumenite':'Chiseled Lumenite','block.deepglow.lumenite_pillar':'Lumenite Pillar','block.deepglow.glowcap':'Glowcap','block.deepglow.deep_lantern':'Deep Lantern',
'item.deepglow.lumenite_shard':'Lumenite Shard','item.deepglow.glow_gel':'Glow Gel','item.deepglow.deep_heart':'Heart of the Deep','item.deepglow.lumenite_scanner':'Lumenite Scanner',
'item.deepglow.glow_slug_spawn_egg':'Glow Slug Spawn Egg','item.deepglow.shardling_spawn_egg':'Shardling Spawn Egg','item.deepglow.deep_guardian_spawn_egg':'Deep Guardian Spawn Egg',
'entity.deepglow.glow_slug':'Glow Slug','entity.deepglow.shardling':'Shardling','entity.deepglow.deep_guardian':'Deep Guardian',
'effect.deepglow.carapace':'Deep Carapace','deepglow.wings_hint':'Double jump in the air: unfold the wings and glide. Landing folds them.','deepglow.wings.left':'Wings: %s / %s','deepglow.set_bonus':'Beetle set (4 pieces): Deep Carapace, absorption hearts','deepglow.guardian.take_heart':'Press Right Click to take the Heart of the Deep','deepglow.sword_hint':'Hit: Lumenite Decay (like Wither); a player\'s hearts turn teal','deepglow.scanner_hint':'Right click: highlights the most valuable ore within %s blocks',
'deepglow.scanner.none':'No ore within %s blocks','deepglow.scanner.found':'Highlighted: %s x%s',
'deepglow.dir.here':'right here','deepglow.dir.north':'to the north','deepglow.dir.south':'to the south','deepglow.dir.east':'to the east','deepglow.dir.west':'to the west',
'deepglow.dir.up':'%s above','deepglow.dir.down':'%s below','deepglow.dir.level':'same level'}
RU={'block.deepglow.lumenite_crystal':'Люменитовый кристалл','block.deepglow.lumenite_glass':'Люменитовое стекло','block.deepglow.chiseled_lumenite':'Резной люменит','block.deepglow.lumenite_pillar':'Люменитовая колонна','block.deepglow.glowcap':'Светошляпка','block.deepglow.deep_lantern':'Глубинный фонарь',
'item.deepglow.lumenite_shard':'Люменитовый осколок','item.deepglow.glow_gel':'Светящийся гель','item.deepglow.deep_heart':'Сердце глубин','item.deepglow.lumenite_scanner':'Люменитовый сканер',
'item.deepglow.glow_slug_spawn_egg':'Яйцо призыва: светящийся слизень','item.deepglow.shardling_spawn_egg':'Яйцо призыва: осколочник','item.deepglow.deep_guardian_spawn_egg':'Яйцо призыва: страж глубин',
'entity.deepglow.glow_slug':'Светящийся слизень','entity.deepglow.shardling':'Осколочник','entity.deepglow.deep_guardian':'Страж глубин',
'effect.deepglow.carapace':'Панцирь глубин','deepglow.wings_hint':'Двойной прыжок в воздухе: раскрыть крылья и лететь. При посадке складываются.','deepglow.wings.left':'Крылья: %s / %s','deepglow.set_bonus':'Комплект жука (4 предмета): Панцирь глубин, поглощение','deepglow.guardian.take_heart':'Нажмите ПКМ, чтобы забрать сердце глубин','deepglow.sword_hint':'Удар: люменитовое иссушение (как Иссушение); у игрока сердца становятся бирюзовыми','deepglow.scanner_hint':'ПКМ: подсвечивает самую ценную руду в радиусе %s блоков',
'deepglow.scanner.none':'В радиусе %s блоков нет руды','deepglow.scanner.found':'Подсвечено: %s ×%s',
'deepglow.dir.here':'прямо здесь','deepglow.dir.north':'на севере','deepglow.dir.south':'на юге','deepglow.dir.east':'на востоке','deepglow.dir.west':'на западе',
'deepglow.dir.up':'на %s выше','deepglow.dir.down':'на %s ниже','deepglow.dir.level':'на этом же уровне'}
for f,add in (('en_us',EN),('ru_ru',RU)):
    p=A+'lang/%s.json'%f; d=ld(p); d.update(add); jd(p,d)
# ----- mod meta
p=R+'fabric.mod.json'; d=ld(p); d['description']='Glowing lumenite ore, tools and armor, glow beetle, glow slug, shardlings and the Deep Guardian boss, crystal geodes and glowcaps in the caves.'; jd(p,d)
print('v12 data ok')

# ----- beetle armor recipes (S=shard, I=ingot, H=deep heart, G=glow gel)
def armor_recipe(n,pattern,key):
    jd(D+'recipes/%s.json'%n,{'type':'minecraft:crafting_shaped','pattern':pattern,'key':{k:{'item':v} for k,v in key.items()},'result':{'item':'deepglow:%s'%n,'count':1}})
_I='deepglow:lumenite_ingot'; _S='deepglow:lumenite_shard'; _H='deepglow:deep_heart'; _G='deepglow:glow_gel'
armor_recipe('lumenite_helmet',['SIS','I I'],{'S':_S,'I':_I})
armor_recipe('lumenite_chestplate',['I I','IHI','III'],{'I':_I,'H':_H})
armor_recipe('lumenite_leggings',['SIS','I I','I I'],{'S':_S,'I':_I})
armor_recipe('lumenite_boots',['I I','G G'],{'I':_I,'G':_G})
