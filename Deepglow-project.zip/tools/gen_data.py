import json, os
R='/home/claude/dg/src/main/resources/'
A=R+'assets/deepglow/'; D=R+'data/deepglow/'
def jd(p,o):
    os.makedirs(os.path.dirname(p),exist_ok=True); json.dump(o,open(p,'w'),indent=2,ensure_ascii=False)
CUBES=['lumenite_ore','deepslate_lumenite_ore','raw_lumenite_block','lumenite_block','polished_lumenite','lumenite_bricks','lumenite_lamp']
for b in CUBES:
    jd(A+'models/block/%s.json'%b,{'parent':'minecraft:block/cube_all','textures':{'all':'deepglow:block/%s'%b}})
    jd(A+'blockstates/%s.json'%b,{'variants':{'':{'model':'deepglow:block/%s'%b}}})
    jd(A+'models/item/%s.json'%b,{'parent':'deepglow:block/%s'%b})
# slab + stairs of bricks
T={'bottom':'deepglow:block/lumenite_bricks','top':'deepglow:block/lumenite_bricks','side':'deepglow:block/lumenite_bricks'}
jd(A+'models/block/lumenite_bricks_slab.json',{'parent':'minecraft:block/slab','textures':T})
jd(A+'models/block/lumenite_bricks_slab_top.json',{'parent':'minecraft:block/slab_top','textures':T})
jd(A+'blockstates/lumenite_bricks_slab.json',{'variants':{'type=bottom':{'model':'deepglow:block/lumenite_bricks_slab'},'type=top':{'model':'deepglow:block/lumenite_bricks_slab_top'},'type=double':{'model':'deepglow:block/lumenite_bricks'}}})
jd(A+'models/item/lumenite_bricks_slab.json',{'parent':'deepglow:block/lumenite_bricks_slab'})
for n,par in (('lumenite_bricks_stairs','minecraft:block/stairs'),('lumenite_bricks_stairs_inner','minecraft:block/inner_stairs'),('lumenite_bricks_stairs_outer','minecraft:block/outer_stairs')):
    jd(A+'models/block/%s.json'%n,{'parent':par,'textures':T})
jd(A+'models/item/lumenite_bricks_stairs.json',{'parent':'deepglow:block/lumenite_bricks_stairs'})
bot={'east':{'straight':0,'outer_right':0,'outer_left':270,'inner_right':0,'inner_left':270},
     'south':{'straight':90,'outer_right':90,'outer_left':0,'inner_right':90,'inner_left':0},
     'west':{'straight':180,'outer_right':180,'outer_left':90,'inner_right':180,'inner_left':90},
     'north':{'straight':270,'outer_right':270,'outer_left':180,'inner_right':270,'inner_left':180}}
top={'east':{'straight':0,'outer_right':90,'outer_left':0,'inner_right':90,'inner_left':0},
     'south':{'straight':90,'outer_right':180,'outer_left':90,'inner_right':180,'inner_left':90},
     'west':{'straight':180,'outer_right':270,'outer_left':180,'inner_right':270,'inner_left':180},
     'north':{'straight':270,'outer_right':0,'outer_left':270,'inner_right':0,'inner_left':270}}
var={}
for half,tbl in (('bottom',bot),('top',top)):
    for facing,shapes in tbl.items():
        for shape,y in shapes.items():
            m='deepglow:block/lumenite_bricks_stairs' + ('' if shape=='straight' else '_inner' if shape.startswith('inner') else '_outer')
            e={'model':m,'uvlock':True}
            if half=='top': e['x']=180
            if y: e['y']=y
            var['facing=%s,half=%s,shape=%s'%(facing,half,shape)]=e
jd(A+'blockstates/lumenite_bricks_stairs.json',{'variants':var})
# item models
GEN=['raw_lumenite','lumenite_ingot','lumenite_dust','lumenite_helmet','lumenite_chestplate','lumenite_leggings','lumenite_boots','glow_beetle_spawn_egg']
HAND=['lumenite_sword','lumenite_pickaxe','lumenite_axe','lumenite_shovel','lumenite_hoe']
for i in GEN: jd(A+'models/item/%s.json'%i,{'parent':'minecraft:item/generated','textures':{'layer0':'deepglow:item/%s'%i}})
for i in HAND: jd(A+'models/item/%s.json'%i,{'parent':'minecraft:item/handheld','textures':{'layer0':'deepglow:item/%s'%i}})
# loot tables
def drop_self(n): return {'type':'minecraft:block','pools':[{'rolls':1,'bonus_rolls':0,'entries':[{'type':'minecraft:item','name':'deepglow:%s'%n}],'conditions':[{'condition':'minecraft:survives_explosion'}]}]}
for b in ['raw_lumenite_block','lumenite_block','polished_lumenite','lumenite_bricks','lumenite_lamp','lumenite_bricks_stairs']:
    jd(D+'loot_tables/blocks/%s.json'%b,drop_self(b))
jd(D+'loot_tables/blocks/lumenite_bricks_slab.json',{'type':'minecraft:block','pools':[{'rolls':1,'bonus_rolls':0,'entries':[{'type':'minecraft:item','name':'deepglow:lumenite_bricks_slab','functions':[{'function':'minecraft:set_count','count':2,'add':False,'conditions':[{'condition':'minecraft:block_state_property','block':'deepglow:lumenite_bricks_slab','properties':{'type':'double'}}]},{'function':'minecraft:explosion_decay'}]}]}]})
for ore in ('lumenite_ore','deepslate_lumenite_ore'):
    jd(D+'loot_tables/blocks/%s.json'%ore,{'type':'minecraft:block','pools':[{'rolls':1,'bonus_rolls':0,'entries':[{'type':'minecraft:alternatives','children':[
        {'type':'minecraft:item','name':'deepglow:%s'%ore,'conditions':[{'condition':'minecraft:match_tool','predicate':{'enchantments':[{'enchantment':'minecraft:silk_touch','levels':{'min':1}}]}}]},
        {'type':'minecraft:item','name':'deepglow:raw_lumenite','functions':[{'function':'minecraft:apply_bonus','enchantment':'minecraft:fortune','formula':'minecraft:ore_drops'},{'function':'minecraft:explosion_decay'}]}]}]}]})
jd(D+'loot_tables/entities/glow_beetle.json',{'type':'minecraft:entity','pools':[{'rolls':1,'bonus_rolls':0,'entries':[{'type':'minecraft:item','name':'deepglow:lumenite_dust','functions':[{'function':'minecraft:set_count','count':{'type':'minecraft:uniform','min':0,'max':2}},{'function':'minecraft:looting_enchant','count':{'min':0,'max':1}}]}]}]})
# recipes
def shaped(n,pattern,key,count=1,out=None):
    jd(D+'recipes/%s.json'%n,{'type':'minecraft:crafting_shaped','pattern':pattern,'key':{k:{'item':v} for k,v in key.items()},'result':{'item':'deepglow:%s'%(out or n),'count':count}})
def shapeless(n,items,count=1,out=None):
    jd(D+'recipes/%s.json'%n,{'type':'minecraft:crafting_shapeless','ingredients':[{'item':i} for i in items],'result':{'item':'deepglow:%s'%(out or n),'count':count}})
I='deepglow:lumenite_ingot'; S='minecraft:stick'
shaped('lumenite_block',['III','III','III'],{'I':I})
shapeless('lumenite_ingot_from_block',['deepglow:lumenite_block'],9,'lumenite_ingot')
shaped('raw_lumenite_block',['RRR','RRR','RRR'],{'R':'deepglow:raw_lumenite'})
shapeless('raw_lumenite_from_block',['deepglow:raw_lumenite_block'],9,'raw_lumenite')
shaped('polished_lumenite',['SS','SI'],{'S':'minecraft:stone','I':I},4)
shaped('lumenite_bricks',['PP','PP'],{'P':'deepglow:polished_lumenite'},4)
shaped('lumenite_bricks_slab',['BBB'],{'B':'deepglow:lumenite_bricks'},6)
shaped('lumenite_bricks_stairs',['B  ','BB ','BBB'],{'B':'deepglow:lumenite_bricks'},4)
shaped('lumenite_lamp',[' D ','DGD',' D '],{'D':'deepglow:lumenite_dust','G':'minecraft:glass'})
shaped('lumenite_sword',['I','I','S'],{'I':I,'S':S})
shaped('lumenite_pickaxe',['III',' S ',' S '],{'I':I,'S':S})
shaped('lumenite_axe',['II','IS',' S'],{'I':I,'S':S})
shaped('lumenite_shovel',['I','S','S'],{'I':I,'S':S})
shaped('lumenite_hoe',['II',' S',' S'],{'I':I,'S':S})
shaped('lumenite_helmet',['III','I I'],{'I':I})
shaped('lumenite_chestplate',['I I','III','III'],{'I':I})
shaped('lumenite_leggings',['III','I I','I I'],{'I':I})
shaped('lumenite_boots',['I I','I I'],{'I':I})
ING=[{'item':'deepglow:raw_lumenite'},{'item':'deepglow:lumenite_ore'},{'item':'deepglow:deepslate_lumenite_ore'}]
jd(D+'recipes/lumenite_ingot_from_smelting.json',{'type':'minecraft:smelting','ingredient':ING,'result':'deepglow:lumenite_ingot','experience':1.0,'cookingtime':200})
jd(D+'recipes/lumenite_ingot_from_blasting.json',{'type':'minecraft:blasting','ingredient':ING,'result':'deepglow:lumenite_ingot','experience':1.0,'cookingtime':100})
# worldgen
jd(D+'worldgen/configured_feature/lumenite_ore.json',{'type':'minecraft:ore','config':{'discard_chance_on_air_exposure':0.0,'size':6,'targets':[
    {'state':{'Name':'deepglow:lumenite_ore'},'target':{'predicate_type':'minecraft:tag_match','tag':'minecraft:stone_ore_replaceables'}},
    {'state':{'Name':'deepglow:deepslate_lumenite_ore'},'target':{'predicate_type':'minecraft:tag_match','tag':'minecraft:deepslate_ore_replaceables'}}]}})
jd(D+'worldgen/placed_feature/lumenite_ore.json',{'feature':'deepglow:lumenite_ore','placement':[{'type':'minecraft:count','count':6},{'type':'minecraft:in_square'},{'type':'minecraft:height_range','height':{'type':'minecraft:trapezoid','min_inclusive':{'absolute':-64},'max_inclusive':{'absolute':24}}},{'type':'minecraft:biome'}]})
# tags
pick=['lumenite_ore','deepslate_lumenite_ore','raw_lumenite_block','lumenite_block','polished_lumenite','lumenite_bricks','lumenite_lamp','lumenite_bricks_slab','lumenite_bricks_stairs']
jd(R+'data/minecraft/tags/blocks/mineable/pickaxe.json',{'replace':False,'values':['deepglow:%s'%b for b in pick]})
jd(R+'data/minecraft/tags/blocks/needs_iron_tool.json',{'replace':False,'values':['deepglow:lumenite_ore','deepglow:deepslate_lumenite_ore','deepglow:raw_lumenite_block','deepglow:lumenite_block']})
# lang
EN={'block.deepglow.lumenite_ore':'Lumenite Ore','block.deepglow.deepslate_lumenite_ore':'Deepslate Lumenite Ore','block.deepglow.raw_lumenite_block':'Block of Raw Lumenite','block.deepglow.lumenite_block':'Block of Lumenite','block.deepglow.polished_lumenite':'Polished Lumenite','block.deepglow.lumenite_bricks':'Lumenite Bricks','block.deepglow.lumenite_bricks_slab':'Lumenite Brick Slab','block.deepglow.lumenite_bricks_stairs':'Lumenite Brick Stairs','block.deepglow.lumenite_lamp':'Lumenite Lamp',
'item.deepglow.raw_lumenite':'Raw Lumenite','item.deepglow.lumenite_ingot':'Lumenite Ingot','item.deepglow.lumenite_dust':'Lumenite Dust','item.deepglow.lumenite_sword':'Lumenite Sword','item.deepglow.lumenite_pickaxe':'Lumenite Pickaxe','item.deepglow.lumenite_axe':'Lumenite Axe','item.deepglow.lumenite_shovel':'Lumenite Shovel','item.deepglow.lumenite_hoe':'Lumenite Hoe','item.deepglow.lumenite_helmet':'Lumenite Helmet','item.deepglow.lumenite_chestplate':'Lumenite Chestplate','item.deepglow.lumenite_leggings':'Lumenite Leggings','item.deepglow.lumenite_boots':'Lumenite Boots','item.deepglow.glow_beetle_spawn_egg':'Glow Beetle Spawn Egg','entity.deepglow.glow_beetle':'Glow Beetle','itemGroup.deepglow.main':'Deepglow',
'deepglow.set_bonus':'Lumenite set: night vision underground','deepglow.vein_hint':'Sneak while mining ore: the whole vein breaks'}
RU={'block.deepglow.lumenite_ore':'Люменитовая руда','block.deepglow.deepslate_lumenite_ore':'Глубинная люменитовая руда','block.deepglow.raw_lumenite_block':'Блок сырого люменита','block.deepglow.lumenite_block':'Блок люменита','block.deepglow.polished_lumenite':'Полированный люменит','block.deepglow.lumenite_bricks':'Люменитовые кирпичи','block.deepglow.lumenite_bricks_slab':'Люменитовая плита из кирпичей','block.deepglow.lumenite_bricks_stairs':'Люменитовые кирпичные ступени','block.deepglow.lumenite_lamp':'Люменитовая лампа',
'item.deepglow.raw_lumenite':'Сырой люменит','item.deepglow.lumenite_ingot':'Люменитовый слиток','item.deepglow.lumenite_dust':'Люменитовая пыль','item.deepglow.lumenite_sword':'Люменитовый меч','item.deepglow.lumenite_pickaxe':'Люменитовая кирка','item.deepglow.lumenite_axe':'Люменитовый топор','item.deepglow.lumenite_shovel':'Люменитовая лопата','item.deepglow.lumenite_hoe':'Люменитовая мотыга','item.deepglow.lumenite_helmet':'Люменитовый шлем','item.deepglow.lumenite_chestplate':'Люменитовый нагрудник','item.deepglow.lumenite_leggings':'Люменитовые поножи','item.deepglow.lumenite_boots':'Люменитовые ботинки','item.deepglow.glow_beetle_spawn_egg':'Яйцо призыва: светляк','entity.deepglow.glow_beetle':'Светляк','itemGroup.deepglow.main':'Deepglow',
'deepglow.set_bonus':'Люменитовый сет: ночное зрение под землёй','deepglow.vein_hint':'Присядь при добыче руды: вся жила выломается'}
jd(A+'lang/en_us.json',EN); jd(A+'lang/ru_ru.json',RU)
print('data ok')
