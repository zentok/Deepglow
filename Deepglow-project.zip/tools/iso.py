import math
import numpy as np
from PIL import Image
def render(elements,tex,yaw=0.8,pit=-0.55,Wd=260,Hd=240,SC=9,off=(8,8,8)):
    zb=np.full((Hd,Wd),1e9); out=np.zeros((Hd,Wd,4),np.uint8); out[:]=(236,238,244,255)
    cyw,syw,cp,sp=math.cos(yaw),math.sin(yaw),math.cos(pit),math.sin(pit)
    def proj(p):
        x,y,z=p[0]-off[0],p[1]-off[1],p[2]-off[2]
        x,z=x*cyw+z*syw,-x*syw+z*cyw
        y2=y*cp-z*sp; d=z*cp+y*sp
        return (x*SC+Wd/2,-y2*SC+Hd/2,d)
    for el in elements:
        x1,y1,z1=el['from']; x2,y2,z2=el['to']
        t=np.array(tex[el['tex']])
        C={'up':[(x1,y2,z1),(x2,y2,z1),(x2,y2,z2),(x1,y2,z2)],'down':[(x1,y1,z2),(x2,y1,z2),(x2,y1,z1),(x1,y1,z1)],
           'north':[(x2,y2,z1),(x1,y2,z1),(x1,y1,z1),(x2,y1,z1)],'south':[(x1,y2,z2),(x2,y2,z2),(x2,y1,z2),(x1,y1,z2)],
           'west':[(x1,y2,z1),(x1,y2,z2),(x1,y1,z2),(x1,y1,z1)],'east':[(x2,y2,z2),(x2,y2,z1),(x2,y1,z1),(x2,y1,z2)]}
        shade={'up':1.0,'down':0.5,'north':0.8,'south':0.8,'west':0.65,'east':0.65}
        for fn,cs in C.items():
            pts=[proj(c) for c in cs]
            p0,p1,p3=np.array(pts[0]),np.array(pts[1]),np.array(pts[3])
            e1=p1-p0; e2=p3-p0
            M=np.array([[e1[0],e2[0]],[e1[1],e2[1]]])
            if abs(np.linalg.det(M))<1e-6: continue
            Mi=np.linalg.inv(M)
            xs=[q[0] for q in pts]; ys=[q[1] for q in pts]
            for py in range(max(0,int(min(ys))),min(Hd,int(max(ys))+1)):
                for px in range(max(0,int(min(xs))),min(Wd,int(max(xs))+1)):
                    s,tt=Mi@np.array([px+.5-p0[0],py+.5-p0[1]])
                    if 0<=s<1 and 0<=tt<1:
                        d=p0[2]+s*e1[2]+tt*e2[2]
                        if d<zb[py,px]-1e-4:
                            X,Y,Z=[cs[0][i]+s*(cs[1][i]-cs[0][i])+tt*(cs[3][i]-cs[0][i]) for i in range(3)]
                            if fn in('up','down'): u,v=X,Z
                            elif fn=='north': u,v=16-X,16-Y
                            elif fn=='south': u,v=X,16-Y
                            elif fn=='west': u,v=Z,16-Y
                            else: u,v=16-Z,16-Y
                            col=t[min(15,max(0,int(v))),min(15,max(0,int(u)))]
                            if col[3]>0:
                                zb[py,px]=d; sh=shade[fn]
                                out[py,px]=(int(col[0]*sh),int(col[1]*sh),int(col[2]*sh),255)
    return Image.fromarray(out)
def cube(t,a=(0,0,0),b=(16,16,16)): return {'from':a,'to':b,'tex':t}
