# Deepglow textures: blocks, items, tool/armor icons, armor layers. All original pixel art.
import random, math
from PIL import Image
OUT='/home/claude/dg/src/main/resources/assets/deepglow/textures/'
RP='/home/claude/rp1/assets/minecraft/textures/block/'
def hx(s): return tuple(int(s[i:i+2],16) for i in (1,3,5))+(255,)
# lumenite ramp
L0=hx('#eafffb'); L1=hx('#9ff7e8'); L2=hx('#3fd3c1'); L3=hx('#1a9a9a'); L4=hx('#0e6670'); L5=hx('#093a44')
RAMP=[L5,L4,L3,L2,L1,L0]
def newimg(w=16,h=16): return Image.new('RGBA',(w,h),(0,0,0,0))
def noisy(pal,seed,w=16,h=16):
    random.seed(seed); im=newimg(w,h); p=im.load()
    for y in range(h):
        for x in range(w): p[x,y]=random.choice(pal)
    return im
def px(im,pts,c):
    p=im.load()
    for x,y in pts:
        if 0<=x<im.width and 0<=y<im.height: p[x,y]=c
# ---------- blocks ----------
def crystals(base,spots,seed):
    im=base.copy(); random.seed(seed)
    for (cx,cy,h) in spots:
        # a small upward crystal: column of width 2 with highlight on left, tip pixel
        for k in range(h):
            y=cy-k
            px(im,[(cx,y)],L1 if k>0 else L2); px(im,[(cx+1,y)],L3 if k>0 else L4)
        px(im,[(cx,cy-h)],L0)
        px(im,[(cx-1,cy+1),(cx+2,cy+1)],L4)
    return im
SPOTS=[(3,5,3),(10,4,3),(6,11,3),(12,12,2),(2,12,2),(8,7,2)]
def load(n): return Image.open(RP+n).convert('RGBA')
tex={}
tex['lumenite_ore']=crystals(load('stone.png'),SPOTS,1)
tex['deepslate_lumenite_ore']=crystals(load('deepslate.png'),SPOTS,2)
# raw block: lumpy teal rock
im=noisy([L4,L3,L3,L2,L4,L5],3)
for (x,y) in [(3,3),(4,3),(10,5),(11,5),(6,10),(7,10),(12,12),(2,13)]: px(im,[(x,y),(x+1,y)],L1)
tex['raw_lumenite_block']=im
# block: faceted crystal
im=newimg(); p=im.load(); random.seed(4)
for y in range(16):
    for x in range(16):
        t=(x+y)/30.0
        p[x,y]=RAMP[min(5,max(1,int(1+t*3.2+random.random()*0.8)))]
for i in range(16): px(im,[(i,0),(0,i)],L1); px(im,[(i,15),(15,i)],L4)
for k in range(4,12): px(im,[(k,k-3),(k-3,k)],L1)
px(im,[(4,3),(11,10),(8,6)],L0)
tex['lumenite_block']=im
# polished: smooth plate with bevel
im=noisy([L3,L3,L2,L3],5)
for i in range(16): px(im,[(i,0),(0,i)],L1); px(im,[(i,15),(15,i)],L5); px(im,[(i,1),(1,i)],L2); px(im,[(i,14),(14,i)],L4)
px(im,[(5,5),(6,5),(5,6)],L1)
tex['polished_lumenite']=im
# bricks: brick pattern on polished palette
im=noisy([L3,L3,L2,L3],6)
for y in (0,5,10,15): px(im,[(x,y) for x in range(16)],L5)
for x in (4,12): px(im,[(x,y) for y in range(1,5)],L5)
for x in (0,8): px(im,[(x,y) for y in range(6,10)],L5)
for x in (4,12): px(im,[(x,y) for y in range(11,15)],L5)
for (x0,y0) in [(1,1),(5,1),(9,1),(13,1),(1,6),(9,6),(5,6),(13,6),(1,11),(5,11),(9,11),(13,11)]:
    px(im,[(x0,y0),(x0+1,y0)],L1)
tex['lumenite_bricks']=im
# lamp: bright glowing glass-like with frame
im=newimg(); p=im.load(); random.seed(8)
for y in range(16):
    for x in range(16):
        d=max(abs(x-7.5),abs(y-7.5))
        p[x,y]=L0 if d<2.5 else L1 if d<4.5 else L2 if d<6.5 else L3
for i in range(16): px(im,[(i,0),(i,15),(0,i),(15,i)],L5); px(im,[(i,1),(i,14),(1,i),(14,i)],L4)
for k in (7,8): px(im,[(k,y) for y in range(2,14)],L1); px(im,[(x,k) for x in range(2,14)],L1)
px(im,[(7,7),(8,7),(7,8),(8,8)],L0)
tex['lumenite_lamp']=im
for n in ('lumenite_ore','deepslate_lumenite_ore','raw_lumenite_block','lumenite_block','polished_lumenite','lumenite_bricks','lumenite_lamp'):
    tex[n].save(OUT+'block/%s.png'%n)
# ---------- item helpers ----------
BR=[hx('#6b4a2a'),hx('#8a6238'),hx('#4a321c')]
def outline(im,c=L5):
    p=im.load(); w,h=im.size; add=[]
    for y in range(h):
        for x in range(w):
            if p[x,y][3]==0:
                for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                    X,Y=x+dx,y+dy
                    if 0<=X<w and 0<=Y<h and p[X,Y][3]>0 and p[X,Y]!=c: add.append((x,y)); break
    for x,y in add: p[x,y]=c
def line(im,a,b,c,th=1):
    (x0,y0),(x1,y1)=a,b; n=max(abs(x1-x0),abs(y1-y0),1)
    for i in range(n+1):
        x=round(x0+(x1-x0)*i/n); y=round(y0+(y1-y0)*i/n)
        px(im,[(x,y)],c)
        if th>1: px(im,[(x+1,y)],c)
def handle(im,a,b):
    line(im,a,b,BR[1]); 
    (x0,y0),(x1,y1)=a,b
    px(im,[(x0,y0)],BR[2])
def shade_head(im,pts):
    # light on top-left, dark bottom-right
    xs=[x for x,y in pts]; ys=[y for x,y in pts]
    for (x,y) in pts:
        t=((x-min(xs))/max(1,max(xs)-min(xs))+(y-min(ys))/max(1,max(ys)-min(ys)))/2
        px(im,[(x,y)],L1 if t<0.3 else L2 if t<0.62 else L3)
def icon_pickaxe():
    im=newimg(); handle(im,(3,13),(11,5))
    arc=[(4,6),(5,4),(7,3),(9,3),(11,4),(12,6),(12,8),(5,5),(6,4),(10,4),(11,5)]
    shade_head(im,arc+[(8,3),(4,7),(12,7)]); px(im,[(7,3),(5,4)],L0)
    outline(im); return im
def icon_axe():
    im=newimg(); handle(im,(3,13),(10,6))
    head=[(6,3),(7,2),(8,2),(9,2),(10,2),(11,2),(6,4),(7,3),(8,3),(9,3),(10,3),(11,3),(12,3),(7,4),(8,4),(9,4),(10,4),(11,4),(12,4),(8,5),(9,5),(10,5),(11,5),(12,5),(10,6)]
    shade_head(im,head); px(im,[(8,2),(7,3)],L0); outline(im); return im
def icon_shovel():
    im=newimg(); handle(im,(3,13),(10,6))
    blade=[(12,1),(13,1),(11,2),(12,2),(13,2),(14,2),(11,3),(12,3),(13,3),(14,3),(12,4),(13,4),(11,4),(14,4),(12,5),(13,5)]
    shade_head(im,blade); px(im,[(11,2),(10,3)],L0); outline(im); return im
def icon_hoe():
    im=newimg(); handle(im,(3,13),(11,5))
    head=[(8,3),(9,3),(10,3),(11,3),(12,3),(8,4),(12,4),(8,5),(12,5),(7,4),(7,5)]
    head=[(7,4),(8,3),(9,3),(10,3),(11,3),(12,4),(8,4),(7,5),(8,5)]
    shade_head(im,head+[(12,4)]); px(im,[(8,3)],L0); outline(im); return im
def icon_sword():
    im=newimg()
    blade=[(13,2),(12,3),(11,4),(10,5),(9,6),(8,7),(7,8),(6,9),(14,2),(13,3),(12,4),(11,5),(10,6),(9,7),(8,8),(7,9),(13,1)]
    for i,(x,y) in enumerate(blade): px(im,[(x,y)],L1 if i<8 else L3)
    px(im,[(13,1)],L0); px(im,[(12,2),(11,3),(10,4)],L2)
    line(im,(4,8),(8,12),L4); line(im,(5,8),(8,11),L2)
    handle(im,(5,10),(2,13)); px(im,[(1,14),(2,14)],L4)
    outline(im); return im
ICONS={'pickaxe':icon_pickaxe,'axe':icon_axe,'shovel':icon_shovel,'hoe':icon_hoe,'sword':icon_sword}
for k,f in ICONS.items(): f().save(OUT+'item/lumenite_%s.png'%k)
# materials
def blob(pts_rows):
    im=newimg()
    for y,(a,b) in pts_rows.items():
        for x in range(a,b+1):
            t=((x-a)/max(1,b-a)+(y-min(pts_rows))/max(1,max(pts_rows)-min(pts_rows)))/2
            px(im,[(x,y)],L1 if t<0.25 else L2 if t<0.55 else L3 if t<0.85 else L4)
    return im
im=blob({4:(6,9),5:(4,11),6:(3,12),7:(3,12),8:(3,12),9:(4,11),10:(5,10),11:(6,9)})
for (x,y) in [(5,6),(9,5),(7,9),(10,8)]: px(im,[(x,y)],L0)
px(im,[(4,9),(10,10),(8,11)],L5); outline(im); im.save(OUT+'item/raw_lumenite.png')
# ingot: bar
im=newimg()
for y,(a,b) in {5:(5,13),6:(4,13),7:(3,12),8:(2,11),9:(2,10),10:(2,9)}.items():
    for x in range(a,b+1): px(im,[(x,y)],L1 if y<7 else L2 if y<9 else L3)
px(im,[(5,5),(6,5),(7,5)],L0); px(im,[(9,10),(8,10)],L4); px(im,[(11,9),(12,8),(13,7)],L4)
outline(im); im.save(OUT+'item/lumenite_ingot.png')
# dust: sparkling pile
im=newimg(); random.seed(11)
for y,(a,b) in {8:(6,9),9:(4,11),10:(3,12),11:(3,12),12:(5,10)}.items():
    for x in range(a,b+1): px(im,[(x,y)],random.choice([L2,L2,L3,L1]))
px(im,[(7,8),(5,10),(10,10),(8,11)],L0); px(im,[(7,5),(6,4),(8,4),(7,3)],L1); px(im,[(7,4)],L0); px(im,[(11,6)],L1)
outline(im); im.save(OUT+'item/lumenite_dust.png')
# armor icons
def armor_icon(spans,extra):
    im=newimg()
    for y,spanlist in spans.items():
        for (a,b) in spanlist:
            for x in range(a,b+1):
                t=((x-3)/10.0)*0.6+((y-2)/12.0)*0.4
                px(im,[(x,y)],L1 if t<0.22 else L2 if t<0.5 else L3 if t<0.78 else L4)
    extra(im); outline(im); return im
def hx_helm(im): px(im,[(5,9),(6,9),(9,9),(10,9)],L5); px(im,[(7,5),(8,5),(7,6),(8,6)],L0); px(im,[(6,4)],L0)
def hx_chest(im): px(im,[(7,6),(8,6),(7,7),(8,7)],L0); px(im,[(7,5),(8,8)],L1); line(im,(5,10),(10,10),L4)
def hx_legs(im): line(im,(4,4),(11,4),L5); px(im,[(7,8),(8,8)],L4); px(im,[(5,6),(10,6)],L0)
def hx_boot(im): px(im,[(4,10),(11,10)],L4); px(im,[(5,8),(10,8)],L0)
armor_icon({2:[(5,10)],3:[(4,11)],4:[(3,12)],5:[(3,12)],6:[(3,12)],7:[(3,12)],8:[(3,12)],9:[(3,5),(10,12)],10:[(3,5),(10,12)]},hx_helm).save(OUT+'item/lumenite_helmet.png')
armor_icon({2:[(2,5),(10,13)],3:[(2,6),(9,13)],4:[(2,13)],5:[(3,12)],6:[(4,11)],7:[(4,11)],8:[(4,11)],9:[(4,11)],10:[(4,11)],11:[(4,11)],12:[(4,11)]},hx_chest).save(OUT+'item/lumenite_chestplate.png')
armor_icon({2:[(4,11)],3:[(4,11)],4:[(4,11)],5:[(4,11)],6:[(4,6),(9,11)],7:[(4,6),(9,11)],8:[(4,6),(9,11)],9:[(4,6),(9,11)],10:[(4,6),(9,11)],11:[(4,6),(9,11)],12:[(4,6),(9,11)]},hx_legs).save(OUT+'item/lumenite_leggings.png')
armor_icon({6:[(3,6),(9,12)],7:[(3,6),(9,12)],8:[(3,6),(9,12)],9:[(3,6),(9,12)],10:[(2,6),(9,13)],11:[(2,6),(9,13)],12:[(2,6),(9,13)]},hx_boot).save(OUT+'item/lumenite_boots.png')
# ---------- armor layers (vanilla UV layout, own pattern) ----------
def region(u,v,dx,dy,dz):
    return {'top':(u+dz,v,dx,dz),'bottom':(u+dz+dx,v,dx,dz),'west':(u,v+dz,dz,dy),'front':(u+dz,v+dz,dx,dy),'east':(u+dz+dx,v+dz,dz,dy),'back':(u+2*dz+dx,v+dz,dx,dy)}
def armor_layer(kind,seed):
    im=newimg(64,32); p=im.load(); random.seed(seed)
    parts=[('head',0,0,8,8,8),('body',16,16,8,12,4),('arm',40,16,4,12,4),('leg',0,16,4,12,4)]
    for name,u,v,dx,dy,dz in parts:
        for fn,(x0,y0,w,h) in region(u,v,dx,dy,dz).items():
            for y in range(h):
                for x in range(w):
                    base=random.choice([L3,L3,L2,L4])
                    if fn=='top': base=random.choice([L2,L1,L2])
                    if fn=='bottom': base=L4
                    p[x0+x,y0+y]=base
            # plate edges
            for x in range(w): p[x0+x,y0]=L1 if fn!='bottom' else L4; p[x0+x,y0+h-1]=L5
            for y in range(h): p[x0,y0+y]=L2 if fn in('front','back') else p[x0,y0+y]; p[x0+w-1,y0+y]=L5
            if name=='head' and fn=='front':
                for x in range(1,w-1): p[x0+x,y0+3]=L5; p[x0+x,y0+4]=L0 if 1<x<w-2 else L5
            if name=='body' and fn=='front':
                for yy in range(2,10): p[x0+3,y0+yy]=L5; p[x0+4,y0+yy]=L5
                for (xx,yy) in ((3,4),(4,4),(3,5),(4,5)): p[x0+xx,y0+yy]=L0
                for xx in range(0,w): p[x0+xx,y0+10]=L5
            if name=='leg' and fn in('front','back'):
                for yy in range(0,h,3): 
                    for xx in range(w): p[x0+xx,y0+yy]=L4
                for xx in range(w): p[x0+xx,y0+h-3]=L5
            if name=='arm' and fn in('front','back','west','east'):
                for yy in range(0,3):
                    for xx in range(w): p[x0+xx,y0+yy]=L1 if yy==0 else L2
    return im
armor_layer(1,21).save(OUT+'models/armor/lumenite_layer_1.png')
armor_layer(2,22).save(OUT+'models/armor/lumenite_layer_2.png')
print('textures ok')
