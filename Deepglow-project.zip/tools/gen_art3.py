# Art pass 3: vanilla-like gem block (diamond-block style), chiseled polished (copper-chiseled style),
# raw block (raw-gold-block style, lumpy), vanilla-shaped ingot.  Run after gen_art2.py
import random, math
from PIL import Image
OUT='/home/claude/dg/src/main/resources/assets/deepglow/textures/'
def hx(s): return tuple(int(s[i:i+2],16) for i in (1,3,5))+(255,)
L0=hx('#eafffb');L1=hx('#9ff7e8');L2=hx('#3fd3c1');L3=hx('#1a9a9a');L4=hx('#0e6670');L5=hx('#093a44')
PALE=hx('#bfe9e6'); MID=hx('#58c9bd'); DEEP=hx('#2aa8a8')
def new(): return Image.new('RGBA',(16,16),(0,0,0,0))
# ---- lumenite block (like diamond block) ----
im=new(); p=im.load()
for y in range(16):
    for x in range(16):
        e=min(x,y,15-x,15-y)
        if e==0: p[x,y]=DEEP if (x+y)<15 else L3
        elif e==1: p[x,y]=PALE if (x<=y and x+y<15 or y<=x and x+y<15) else L1
        elif e==2: p[x,y]=L2
        else:
            band=((x+y+(1 if x%4<2 else 0))//3)%4
            p[x,y]=[L2,L1,L2,MID][band]
for (x,y) in [(0,0),(15,0),(0,15),(15,15)]: p[x,y]=L4
im.save(OUT+'block/lumenite_block.png')
# ---- polished / chiseled ----
Q=["dddddddd","dllllllm","dldddddd","dlddoood","dldodood","dldodlod","dldoooo.","dldhhhhh"]
# build with mirror; 'o' base, 'd' dark, 'l' ring light, 'h' cross highlight
Q=["dddddddd",
   "dlllllll",
   "dldddddd",
   "dldooooh",
   "dldodddh",
   "dldodloh",
   "dldooooh",
   "dldhhhhh"]
im=new(); p=im.load()
for y in range(16):
    for x in range(16):
        qx=x if x<8 else 15-x; qy=y if y<8 else 15-y
        ch=Q[qy][qx]
        right_or_bottom=(x>=8 or y>=8)
        c={'d':L5,'o':L3,'h':L1}.get(ch)
        if ch=='l': c=L1 if not right_or_bottom else L3
        if ch=='d' and (qx==0 or qy==0): c=L4
        if ch=='d' and qx>=3 and qy>=3: c=L4
        if ch=='h' and right_or_bottom: c=L2
        p[x,y]=c
for (x,y) in [(5,5),(10,5),(5,10),(10,10)]: p[x,y]=L0 if (x<8 and y<8) else L2
im.save(OUT+'block/polished_lumenite.png')
# ---- raw lumenite: big rounded clumps, like the raw gold block ----
random.seed(4)
seeds=[]
for gy in range(3):
    for gx in range(3):
        seeds.append(((gx+0.5)*16/3+random.uniform(-1.6,1.6),(gy+0.5)*16/3+random.uniform(-1.6,1.6)))
tone=[random.choice([1,2,2,3]) for _ in seeds]
im=new(); p=im.load()
base=[L4,L3,L2,L1]
def dist(a,b):
    dx=abs(a[0]-b[0]); dy=abs(a[1]-b[1]); dx=min(dx,16-dx); dy=min(dy,16-dy); return math.hypot(dx,dy)
for y in range(16):
    for x in range(16):
        ds=sorted((dist((x+.5,y+.5),s),i) for i,s in enumerate(seeds))
        (d1,i1),(d2,i2)=ds[0],ds[1]
        if d2-d1<0.8: p[x,y]=L5 if (x+y)%2 else L4; continue
        sx,sy=seeds[i1]; t=(x+.5-sx)+(y+.5-sy); k=tone[i1]
        if t<-1.0: k=min(3,k+1)
        elif t>1.4: k=max(0,k-1)
        p[x,y]=base[k]
for (x,y) in [(3,3),(10,7),(6,12)]: p[x,y]=L0
im.save(OUT+'block/raw_lumenite_block.png')
# ---- ingot, vanilla bar shape: top face, front face, right side face ----
ing=new(); p=ing.load()
O=hx('#07242b')
top={4:(8,14),5:(7,13),6:(6,12),7:(5,11)}
for y,(a,b) in top.items():
    for x in range(a,b+1): p[x,y]=L0 if (y==4 or x==a) else L1
for y in (8,9,10):
    for x in range(5,11): p[x,y]=L2 if y==8 else L3 if y==9 else L4
for i in range(4):
    for y in range(5+i,8+i):
        p[14-i,y]=L3 if y<8 else L4
# facets / shine
for (x,y) in [(9,5),(10,5),(8,6)]: p[x,y]=L0
for (x,y) in [(6,8),(7,8)]: p[x,y]=L1
p[5,10]=L5
# outline
q=ing.copy(); qp=q.load()
for y in range(16):
    for x in range(16):
        if p[x,y][3]==0:
            for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                X,Y=x+dx,y+dy
                if 0<=X<16 and 0<=Y<16 and p[X,Y][3]>0: qp[x,y]=O; break
q.save(OUT+'item/lumenite_ingot.png')
print('art3 ok')
