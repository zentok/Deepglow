import sys,json,base64
sys.path.insert(0,'/home/claude/dg/tools')
import v12_mobs as M
spec=M.SPECS['DeepGuardian']
parts=[{'name':p['name'],'parent':p['parent'],'uv':list(p['uv']),'box':list(p['box']),'pose':list(p['pose'])} for p in spec['parts']]
T='/home/claude/dg/src/main/resources/assets/deepglow/textures/entity/'
b=lambda f:base64.b64encode(open(T+f,'rb').read()).decode()
h=open('/home/claude/dg/tools/viewer/guardian_template.html').read()
h=h.replace('__PARTS__',json.dumps(parts)).replace('__TEX__',b('deep_guardian.png')).replace('__GLOW__',b('deep_guardian_glow.png'))
open('/tmp/guardian3d.html','w').write(h); print(len(h))
