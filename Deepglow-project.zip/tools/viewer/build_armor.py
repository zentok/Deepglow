import json,base64
spec=json.load(open('/tmp/beetle_spec.json'))
for m in spec.values():
    for e in m['extras']: e['uv']=list(e['uv'])
T='/home/claude/dg/src/main/resources/assets/deepglow/textures/models/armor/'
b=lambda f:base64.b64encode(open(T+f,'rb').read()).decode()
h=open('/home/claude/dg/tools/viewer/armor_template.html').read()
h=h.replace('__SPEC__',json.dumps(spec)).replace('__OG__',b('beetle_armor_1_glow.png')).replace('__IG__',b('beetle_armor_2_glow.png')).replace('__O__',b('beetle_armor_1.png')).replace('__OWG__',b('beetle_armor_1_wings_glow.png')).replace('__OW__',b('beetle_armor_1_wings.png')).replace('__I__',b('beetle_armor_2.png'))
open('/tmp/beetle_armor3d.html','w').write(h); print(len(h))
