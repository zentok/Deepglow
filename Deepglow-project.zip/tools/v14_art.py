"""v1.8.0: tools in the beetle-armor style + the decorative block set. Run from the project root after v13_art.py."""
import sys, math, random
sys.path.insert(0,'tools')
from v13_art import *

def inside(pts,x,y):
    c=False; n=len(pts)
    for i in range(n):
        (x1,y1),(x2,y2)=pts[i],pts[(i+1)%n]
        if (y1>y)!=(y2>y) and x<(x2-x1)*(y-y1)/(y2-y1)+x1: c=not c
    return c
def crystal_poly(im,pts,glints=()):
    """crystal facets inside a polygon: lit upper-left, shaded lower-right, darker outline on the shaded side"""
    cells=[(x,y) for y in range(16) for x in range(16) if inside(pts,x+.5,y+.5)]
    if not cells: return
    s=[x+y for x,y in cells]; mn,mx=min(s),max(s); S=set(cells)
    for (x,y) in cells:
        t=(x+y-mn)/max(1,mx-mn)
        c=L2 if t<.18 else L1 if t<.42 else M2 if t<.66 else M1 if t<.86 else D2
        edge=any((x+a,y+b) not in S for a,b in ((1,0),(-1,0),(0,1),(0,-1)))
        if edge: c=D1 if t>.45 else M1
        put(im,x,y,c)
    for g in glints: put(im,g[0],g[1],L3)
def handle(im,p0,p1,gem=True):
    (x0,y0),(x1,y1)=p0,p1; n=int(max(abs(x1-x0),abs(y1-y0)))+1
    for i in range(n+1):
        t=i/n; x=x0+(x1-x0)*t; y=y0+(y1-y0)*t
        xi,yi=int(x),int(y)
        c=S4 if i%4 else L1                       # chitin with teal rings
        put(im,xi,yi,c); put(im,xi+1,yi,S2 if c==S4 else M1)
        if i%2==0: put(im,xi,yi+1,S1)
    if gem: put(im,int(x0)-0,int(y0)+0,L1); put(im,int(x0)+1,int(y0),M1)
def stroke(im,pts,r,light_side=1):
    """crystal stroke along a polyline: outer side lit, inner side shaded"""
    cells={}
    for a,b in zip(pts,pts[1:]):
        n=int(max(abs(b[0]-a[0]),abs(b[1]-a[1]))*3)+1
        for i in range(n+1):
            t=i/n; cx=a[0]+(b[0]-a[0])*t; cy=a[1]+(b[1]-a[1])*t
            for yy in range(16):
                for xx in range(16):
                    d=math.hypot(xx+.5-cx,yy+.5-cy)
                    if d<=r: cells[(xx,yy)]=min(cells.get((xx,yy),9),d)
    S=set(cells)
    for (x,y),d in cells.items():
        t=(x+y)
        c=L1 if t<10 else M2 if t<14 else M1 if t<18 else D2
        if d<r*0.45 and t<18: c=L2 if t<12 else c
        edge=any((x+a,y+b) not in S for a,b in ((1,0),(-1,0),(0,1),(0,-1)))
        if edge: c=D1 if t>12 else M1
        put(im,x,y,c)
def pickaxe():
    im=img(); handle(im,(1,14),(9,6))
    O=(5.2,11); R=7.6; u=(0.7071,-0.7071); p=(0.7071,0.7071); pts=[]
    for k in range(0,13):
        phi=math.radians(-62+k*10.3); pts.append((O[0]+R*(math.cos(phi)*u[0]+math.sin(phi)*p[0]),O[1]+R*(math.cos(phi)*u[1]+math.sin(phi)*p[1])))
    stroke(im,pts,1.7)
    for g in [(10,3),(4,3),(13,7)]: put(im,*g,L3)
    save(im,T+'item/lumenite_pickaxe.png')
def axe():
    im=img(); handle(im,(1,14),(9,6))
    crystal_poly(im,[(6,1),(11,0.3),(15.2,2.4),(15.6,8),(12,10.2),(10.4,8),(8.6,6.6),(7.4,3.6)],glints=[(11,3),(13,5)])
    for (x,y) in [(6,2),(5,4)]: put(im,x,y,L1)                       # chitin spikes on the back
    save(im,T+'item/lumenite_axe.png')
def shovel():
    im=img(); handle(im,(1,14),(9,6))
    crystal_poly(im,[(9.5,0),(13,0),(15.6,2.6),(15.9,6),(13,8.8),(10,8.4),(8,5.6),(8,2.6)],glints=[(11,3)])
    put(im,10,6,D1)
    save(im,T+'item/lumenite_shovel.png')
def hoe():
    im=img(); handle(im,(1,14),(9,6))
    crystal_poly(im,[(4,1.5),(11,0.8),(15,2.5),(15.2,5.5),(11.6,5),(10,7.2),(7.6,7.2),(7,5),(4,5.6),(3.2,3.5)],glints=[(10,2),(6,3)])
    pass                        # the downward tooth
    save(im,T+'item/lumenite_hoe.png')

# ---------- decorative blocks (ref: faceted, rounded bricks, tiles, concentric, meander, diamond inlay, banded bricks) ----------
def bevel(c_lit,c_mid,c_dark,x,y,x0,y0,x1,y1):
    c=c_mid
    if y==y0 or x==x0: c=c_lit
    if y==y1 or x==x1: c=c_dark
    return c
def faceted():
    im=img(); centers=[(0,0),(8,0),(4,4),(12,4),(0,8),(8,8),(4,12),(12,12)]
    for y in range(16):
        for x in range(16):
            best=None
            for (cx,cy) in centers:
                for ox in (-16,0,16):
                    for oy in (-16,0,16):
                        dx=x+.5-(cx+ox); dy=y+.5-(cy+oy); d=abs(dx)+abs(dy)
                        if best is None or d<best[0]: best=(d,dx,dy)
            d,dx,dy=best
            if d>=3.9: c=D1
            elif abs(dx)<.8 and abs(dy)<.8: c=L3
            elif abs(dy)>=abs(dx): c=L2 if dy<0 else D2
            else: c=L1 if dx<0 else M1
            put(im,x,y,c)
    save(im,T+'block/lumenite_faceted.png')
def cut_bricks():
    im=img(); rng=random.Random(2)
    for y in range(16):
        for x in range(16): put(im,x,y,D1)
    for r in range(4):
        y0=r*4; off=0 if r%2==0 else 4
        for k in range(-1,3):
            a=off+k*8; b=a+7
            for y in range(y0,y0+3):
                for x in range(a,b):
                    xx=x%16
                    if (x in (a,b-1)) and (y in (y0,y0+2)): continue          # rounded corners
                    c=M1 if rng.random()>.12 else M2
                    if y==y0: c=L1
                    elif x==a: c=L1
                    if y==y0+2: c=D2
                    elif x==b-1: c=D2
                    put(im,xx,y,c)
    save(im,T+'block/lumenite_cut_bricks.png')
def tiles(small=False):
    im=img(); rng=random.Random(4)
    for y in range(16):
        for x in range(16): put(im,x,y,D1)
    for r in range(4):
        y0=r*4; off=0 if r%2==0 else 2
        for k in range(-1,5):
            a=off+k*4
            for y in range(y0,y0+4):
                for x in range(a,a+4):
                    if not (0<=x<16 or True): continue
                    lx,ly=x-a,y-y0
                    if lx==3 or ly==3: c=D1
                    elif lx==0 or ly==0: c=L1
                    else: c=M2 if (not small or (k+r)%2==0) else D2
                    if small and (k+r)%2==0 and lx==1 and ly==1: c=L2
                    put(im,x%16,y,c)
    save(im,T+('block/lumenite_small_tiles.png' if small else 'block/lumenite_tiles.png'))
def concentric():
    im=img()
    for ty in (0,8):
        for tx in (0,8):
            for y in range(8):
                for x in range(8):
                    d=max(abs(x-3.5),abs(y-3.5))
                    c=L1 if d>3 else D2 if d>2 else M1 if d>1 else M2
                    if d<=3 and (x==0 or y==0): pass
                    if d>3 and (x>=4 and y>=4 or x==7 or y==7): c=M1
                    if (x,y)==(3,3): c=L2
                    if (x,y)==(4,4): c=D2
                    put(im,tx+x,ty+y,c)
    save(im,T+'block/lumenite_concentric.png')
def meander():
    im=img()
    for y in range(16):
        for x in range(16): put(im,x,y,M1)
    for y0 in (0,8):
        for x in range(16):
            put(im,x,y0,L1); put(im,x,y0+7,D2)
        for xx in (0,8):                              # a row of key loops
            for (x,y) in [(0,2),(1,2),(2,2),(3,2),(4,2),(5,2),(6,2),(0,3),(0,4),(0,5),(2,4),(3,4),(4,4),(6,3),(6,4),(6,5),(2,5),(4,5),(5,5),(1,5),(3,3)]:
                put(im,xx+x,y0+y if y<6 else y0+5,D2)
            for (x,y) in [(1,3),(2,3),(4,3),(5,3),(1,4),(5,4)]: put(im,xx+x,y0+y,L1)
    save(im,T+'block/lumenite_meander.png')
def diamond_tiles():
    im=img()
    for ty in (0,8):
        for tx in (0,8):
            for y in range(8):
                for x in range(8):
                    d=abs(x-3.5)+abs(y-3.5)
                    c=D2
                    if y==0 or x==0: c=L1
                    elif y==7 or x==7: c=D1
                    elif d<=1.6: c=M2
                    elif d<=2.6: c=L2
                    elif d<=3.6: c=D1
                    else: c=M1
                    put(im,tx+x,ty+y,c)
    save(im,T+'block/lumenite_diamond_tiles.png')
def banded_bricks():
    im=img(); rng=random.Random(6)
    for y in range(16):
        for x in range(16): put(im,x,y,D1)
    for y0,y1 in ((0,5),(8,13)):
        for k in range(4):
            a=k*4
            for y in range(y0,y1+1):
                for x in range(a,a+3):
                    c=M1 if rng.random()>.2 else M2
                    if y==y0 or x==a: c=L1
                    if y==y1 or x==a+2: c=D2
                    put(im,x,y,c)
    for y0 in (6,14):
        for x in range(16): put(im,x,y0,M2 if x%4 else L1); 
        for x in range(16): put(im,x,y0+1,D2) if y0+1<16 else None
    save(im,T+'block/lumenite_banded_bricks.png')

NEW_BLOCKS=[('lumenite_faceted','Faceted Lumenite','Граненый люменит'),('lumenite_cut_bricks','Lumenite Cut Bricks','Тёсаные люменитовые кирпичи'),
 ('lumenite_tiles','Lumenite Tiles','Люменитовая плитка'),('lumenite_small_tiles','Small Lumenite Tiles','Мелкая люменитовая плитка'),
 ('lumenite_concentric','Concentric Lumenite','Люменит с квадратами'),('lumenite_meander','Meander Lumenite','Люменит с меандром'),
 ('lumenite_diamond_tiles','Diamond Lumenite Tiles','Люменит с ромбами'),('lumenite_banded_bricks','Banded Lumenite Bricks','Полосатые люменитовые кирпичи')]
if __name__=='__main__':
    # tool textures reverted (kept in the file for reference, not generated)
    faceted(); cut_bricks(); tiles(False); tiles(True); concentric(); meander(); diamond_tiles(); banded_bricks()
    print('v14 art ok')
