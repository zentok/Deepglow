import sys, math
sys.path.insert(0,'/home/claude/dg/tools')
import v12_mobs as M
from PIL import Image, ImageDraw, ImageFont, ImageFilter
T='/home/claude/dg/src/main/resources/assets/deepglow/textures/'
FB=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',22)
F=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
def absparts(spec):
    pos={}
    for p in spec['parts']:
        px,py,pz=p['pose'][:3]
        if p['parent']: ox,oy,oz=pos[p['parent']]; px+=ox;py+=oy;pz+=oz
        pos[p['name']]=(px,py,pz)
    return pos
def render(spec,view,S):
    tex=Image.open(T+'entity/'+spec['tex']+'.png').convert('RGBA')
    glow=Image.open(T+'entity/'+spec['tex']+'_glow.png').convert('RGBA')
    pos=absparts(spec)
    rects=[]
    for p in spec['parts']:
        x,y,z,w,h,d=p['box']; ax,ay,az=pos[p['name']]
        if view=='front': x0=ax+x; wd=w
        else: x0=-(az+z+d); wd=d
        rects.append((p,x0,ay+y,wd,h,az+z+d/2 if view=='front' else ax+x+w/2))
    minx=min(r[1] for r in rects); maxx=max(r[1]+r[3] for r in rects)
    miny=min(r[2] for r in rects); maxy=max(r[2]+r[4] for r in rects)
    pad=3
    W=int((maxx-minx+2*pad)*S); H=int((maxy-miny+2*pad)*S)
    img=Image.new('RGBA',(W,H),(0,0,0,0)); gl=Image.new('RGBA',(W,H),(0,0,0,0))
    rects.sort(key=lambda r:-r[5] if view=='front' else r[5])
    for p,x0,y0,wd,h,_ in rects:
        u,v=p['uv']; x,y,z,w,hh,d=p['box']; fc=M.faces(u,v,int(w),int(hh),int(d))
        fx,fy,fw,fh=fc['front'] if view=='front' else fc['left']
        for src,dst in ((tex,img),(glow,gl)):
            c=src.crop((fx,fy,fx+fw,fy+fh)).resize((int(round(fw*S)),int(round(fh*S))),Image.NEAREST)
            dst.alpha_composite(c,(int((x0-minx+pad)*S),int((y0-miny+pad)*S)))
    return img,gl
def scene(spec,view,S):
    img,gl=render(spec,view,S)
    bl=gl.filter(ImageFilter.GaussianBlur(S*1.6))
    out=Image.new('RGBA',img.size,(14,20,26,255))
    r,g,b,a=bl.split(); a=a.point(lambda v:min(255,int(v*0.9))); out.alpha_composite(Image.merge('RGBA',(r,g,b,a)))
    out.alpha_composite(img); out.alpha_composite(gl)
    return out
W,H=1700,1180
sheet=Image.new('RGBA',(W,H),(22,28,36,255)); d=ImageDraw.Draw(sheet)
d.text((30,18),'Deepglow 1.2.0 — новое',font=FB,fill=(159,247,232,255))
names=[('GlowSlug','Светящийся слизень','мирный, даёт светящийся гель',7),('Shardling','Осколочник','враждебный, роняет осколки',7),('DeepGuardian','Страж глубин','босс с полоской здоровья, удар об землю',5)]
x0=30
for cls,ru,desc,S in names:
    spec=M.SPECS[cls]
    f=scene(spec,'front',S); s_=scene(spec,'left',S)
    th={"GlowSlug":200,"Shardling":330,"DeepGuardian":330}[cls]
    f=f.resize((int(f.width*th/f.height),th),Image.NEAREST); s_=s_.resize((int(s_.width*th/s_.height),th),Image.NEAREST)
    sheet.alpha_composite(f,(x0,70)); sheet.alpha_composite(s_,(x0+f.width+6,70))
    d.text((x0,70+th+12),ru,font=FB,fill=(234,255,251,255)); d.text((x0,70+th+42),desc,font=F,fill=(159,200,200,255))
    x0+=f.width+s_.width+50
# blocks/items row
y=700
d.text((30,y-34),'Блоки и предметы',font=FB,fill=(159,247,232,255))
row=[('block','lumenite_crystal','кристалл'),('block','lumenite_glass','стекло'),('block','chiseled_lumenite','резной'),('block','lumenite_pillar_side','колонна'),('block','glowcap','светошляпка'),('block','deep_lantern','фонарь'),
     ('item','lumenite_shard','осколок'),('item','glow_gel','гель'),('item','deep_heart','сердце глубин'),('item','lumenite_scanner','сканер')]
for i,(k,n,l) in enumerate(row):
    im=Image.open(T+f'{k}/{n}.png').convert('RGBA').resize((112,112),Image.NEAREST)
    bg=Image.new('RGBA',(130,130),(36,44,56,255)); bg.alpha_composite(im,(9,9))
    x=30+(i%5)*190; yy=y+(i//5)*190
    sheet.alpha_composite(bg,(x,yy)); d.text((x,yy+134),l,font=F,fill=(234,255,251,255))
# mechanics list
tx=1000;ty=y
d.text((tx,ty-34),'Механики и мир',font=FB,fill=(159,247,232,255))
for i,t in enumerate(['• меч: удар подсвечивает цель 10 с','• ботинки гасят падения до 4 урона','• сканер: ближайшая ценная руда (ПКМ)','• геоды из люменита в пещерах','• светошляпки растут в тёмных пещерах','• страж: удар по земле, на 50% зовёт осколочников','• гель: ночное зрение на 30 с']):
    d.text((tx,ty+i*34),t,font=F,fill=(210,235,235,255))
sheet.convert('RGB').save('/mnt/user-data/outputs/deepglow-1.2-preview.png'); print('ok')
