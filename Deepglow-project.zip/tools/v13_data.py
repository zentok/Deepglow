# data changes after v12: guardian loot, glass recipe (run automatically at the end of v12_data.py)
import json
R='src/main/resources/'
def pool(item,n): return {"rolls":1,"bonus_rolls":0,"entries":[{"type":"minecraft:item","name":item,"functions":[{"function":"minecraft:set_count","count":n}]}]}
json.dump({"type":"minecraft:entity","pools":[pool("deepglow:lumenite_shard",2),pool("deepglow:lumenite_ingot",3)]},open(R+'data/deepglow/loot_tables/entities/deep_guardian.json','w'),indent=2)
json.dump({"type":"minecraft:crafting_shaped","pattern":[" G ","GDG"," G "],"key":{"G":{"item":"minecraft:glass"},"D":{"item":"deepglow:lumenite_dust"}},"result":{"item":"deepglow:lumenite_glass","count":4}},open(R+'data/deepglow/recipes/lumenite_glass.json','w'),indent=2)
# NOTE: v1.8 block set data (models, loot, recipes, lang, tags) was written once by the v14 step and lives in the resources; v12_data.py merges and does not remove it.
