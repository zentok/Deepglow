from PIL import Image
import random
random.seed(7)
R='src/main/resources/assets/deepglow/textures/'
body=Image.new('RGBA',(64,32),(0,0,0,0)); glow=Image.new('RGBA',(64,32),(0,0,0,0))
D=[(34,38,48),(46,52,66),(58,66,82),(72,82,100)]
G=[(14,102,112),(26,154,154),(63,211,193),(159,247,232)]
def rect(im,x,y,w,h,f):
    for j in range(h):
        for i in range(w):
            im.putpixel((x+i,y+j),f(i,j))
def shell(i,j):
    c=random.choice(D[:3]); 
    if j==0: c=D[3]
    return c+(255,)
def box(u,v,w,h,d,f=shell,fg=None):
    for (x,y,ww,hh) in [(u+d,v,w,d),(u+d+w,v,w,d),(u,v+d,d,h),(u+d,v+d,w,h),(u+d+w,v+d,d,h),(u+2*d+w,v+d,w,h)]:
        rect(body,x,y,ww,hh,f)
box(0,0,6,3,6)
box(28,0,4,3,3)
box(44,0,1,1,4,lambda i,j:(70,80,98,255)); box(44,6,1,1,4,lambda i,j:(70,80,98,255))
box(0,22,1,3,1,lambda i,j:(28,32,42,255))
# abdomen: glowing teal with dark segment lines
def ab(i,j):
    return G[1]+(255,) if (j%3) else D[0]+(255,)
box(0,10,6,4,7,ab)
# glow layer = abdomen faces except dark lines
u,v,w,h,d=0,10,6,4,7
for (x,y,ww,hh) in [(u+d,v,w,d),(u+d+w,v,w,d),(u,v+d,d,h),(u+d,v+d,w,h),(u+d+w,v+d,d,h),(u+2*d+w,v+d,w,h)]:
    for j in range(hh):
        for i in range(ww):
            if j%3:
                c=G[3] if random.random()<0.18 else (G[2] if random.random()<0.6 else G[1])
                glow.putpixel((x+i,y+j),c+(255,)); body.putpixel((x+i,y+j),G[1]+(255,))
# eyes on head front (u28,v0,d3 -> front at x=31,y=3, 4x3)
for ex in (32,34): 
    glow.putpixel((ex,4),G[3]+(255,)); body.putpixel((ex,4),G[3]+(255,))
body.save(R+'entity/glow_beetle.png'); glow.save(R+'entity/glow_beetle_glow.png')
# egg icon 16x16
e=Image.open('/home/claude/dg/src/main/resources/assets/deepglow/textures/item/lumenite_dust.png').size
egg=Image.new('RGBA',(16,16),(0,0,0,0))
import math
for y in range(16):
    for x in range(16):
        dx=(x-7.5)/5.2; dy=(y-8.5)/6.6
        if dx*dx+dy*dy<=1:
            c=(16,38,43) if (x*3+y*5)%7 else (24,56,62)
            if ((x-7)**2+(y-9)**2)<14 or (y in (6,7) and x>3): c=G[2]
            egg.putpixel((x,y),c+(255,))
for x in range(16):
    for y in range(16):
        if egg.getpixel((x,y))[3]==0:
            for a,b in((1,0),(-1,0),(0,1),(0,-1)):
                if 0<=x+a<16 and 0<=y+b<16 and egg.getpixel((x+a,y+b))[3] and egg.getpixel((x+a,y+b))[:3]!=(0,0,0):
                    pass
egg.save(R+'item/glow_beetle_spawn_egg.png')
# mod icon 128
ic=Image.new('RGBA',(128,128),(14,22,28,255))
ing=Image.open(R+'item/lumenite_ingot.png').resize((96,96),Image.NEAREST); ic.alpha_composite(ing,(16,16)); ic.save('src/main/resources/assets/deepglow/icon.png')
