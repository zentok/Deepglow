package dev.deepglow;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public final class ModEvents {
    private static final int MAX_VEIN = 24;

    private ModEvents() {
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % 40 != 0) {
                return;
            }
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                tickSetBonus(player);
            }
        });
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, blockEntity) -> mineVein(level, player, pos, state));
    }

    /** Full lumenite set: night vision while underground. */
    private static void tickSetBonus(ServerPlayer player) {
        boolean underground = player.getY() < 50 && !player.level().canSeeSky(player.blockPosition());
        if (LumeniteArmorItem.hasFullSet(player) && underground) {
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 320, 0, true, false, true));
        } else {
            MobEffectInstance effect = player.getEffect(MobEffects.NIGHT_VISION);
            if (effect != null && effect.isAmbient() && !effect.isVisible() && effect.getDuration() <= 320) {
                player.removeEffect(MobEffects.NIGHT_VISION);
            }
        }
    }

    private static boolean isOre(BlockState state) {
        return state.is(BlockTags.COAL_ORES) || state.is(BlockTags.IRON_ORES) || state.is(BlockTags.GOLD_ORES)
                || state.is(BlockTags.COPPER_ORES) || state.is(BlockTags.DIAMOND_ORES) || state.is(BlockTags.LAPIS_ORES)
                || state.is(BlockTags.REDSTONE_ORES) || state.is(BlockTags.EMERALD_ORES)
                || state.is(ModBlocks.LUMENITE_ORE) || state.is(ModBlocks.DEEPSLATE_LUMENITE_ORE);
    }

    /** Sneak + lumenite pickaxe: the whole connected vein of the same ore breaks. */
    private static void mineVein(net.minecraft.world.level.Level level, Player player, BlockPos origin, BlockState state) {
        if (level.isClientSide || !(level instanceof ServerLevel serverLevel) || !player.isShiftKeyDown() || !isOre(state)) {
            return;
        }
        ItemStack tool = player.getMainHandItem();
        if (!(tool.getItem() instanceof LumenitePickaxe)) {
            return;
        }
        Block ore = state.getBlock();
        Set<BlockPos> seen = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        seen.add(origin);
        queue.add(origin);
        int broken = 0;
        while (!queue.isEmpty() && broken < MAX_VEIN && !tool.isEmpty()) {
            BlockPos current = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) {
                            continue;
                        }
                        BlockPos next = current.offset(dx, dy, dz);
                        if (!seen.add(next)) {
                            continue;
                        }
                        BlockState nextState = serverLevel.getBlockState(next);
                        if (nextState.getBlock() != ore || broken >= MAX_VEIN || tool.isEmpty()) {
                            continue;
                        }
                        BlockEntity entity = serverLevel.getBlockEntity(next);
                        Block.dropResources(nextState, serverLevel, next, entity, player, tool);
                        nextState.spawnAfterBreak(serverLevel, next, tool, true);
                        serverLevel.destroyBlock(next, false, player);
                        tool.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(InteractionHand.MAIN_HAND));
                        player.causeFoodExhaustion(0.005F);
                        broken++;
                        queue.add(next);
                    }
                }
            }
        }
    }
}
