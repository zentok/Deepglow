package dev.deepglow;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public final class ModEvents {
    private static final int MAX_VEIN = 24;
    private static final String HL_TAG = "deepglow_hl";
    private static final int HIGHLIGHT_TICKS = 200;
    private static final Map<UUID, Highlight> HIGHLIGHTS = new HashMap<>();
    private static int highlightCounter;

    private record Highlight(String tag, ServerLevel level, int expireTick) {
    }

    private ModEvents() {
    }

    public static void register() {
        net.fabricmc.fabric.api.event.player.UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> dev.deepglow.entity.DeepGuardian.tryTakeHeart(player, hand, entity));
        // Beetle chestplate wings work like elytra: the gliding check is handed to Fabric's custom-elytra event.
        net.fabricmc.fabric.api.entity.event.v1.EntityElytraEvents.CUSTOM.register(BeetleWings::tickGlide);
        // Double jump in the air (sent by the client) opens the wings.
        net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.registerGlobalReceiver(BeetleWings.OPEN_PACKET,
                (server, player, handler, buf, responseSender) -> server.execute(() -> {
                    if (!player.onGround() && !player.isFallFlying() && !player.isInWater() && !player.hasEffect(net.minecraft.world.effect.MobEffects.LEVITATION)
                            && BeetleWings.canGlide(player)) {
                        player.startFallFlying();
                    }
                }));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickHighlights(server);
            if (server.getTickCount() % 40 != 0) {
                return;
            }
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                tickSetBonus(player);
            }
        });
        // Highlight markers never survive a restart.
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            for (ServerLevel level : server.getAllLevels()) {
                runCommand(server, level, "kill @e[tag=" + HL_TAG + "]");
            }
            HIGHLIGHTS.clear();
        });
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity.getTags().contains(HL_TAG) && !isActiveTag(entity.getTags()) && world.getServer() != null) {
                world.getServer().execute(entity::discard);
            }
        });
        // Lumenite boots soften small falls.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof Player player && source.is(DamageTypeTags.IS_FALL) && amount <= 4.0F
                    && player.getItemBySlot(EquipmentSlot.FEET).is(ModItems.LUMENITE_BOOTS)) {
                return false;
            }
            return true;
        });
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, blockEntity) -> mineVein(level, player, pos, state));
    }

    /** Full beetle armor set: the "Deep carapace" effect (absorption hearts), refreshed before it runs out. */
    private static void tickSetBonus(ServerPlayer player) {
        if (LumeniteArmorItem.hasFullSet(player)) {
            MobEffectInstance current = player.getEffect(ModEffects.CARAPACE);
            if (current == null || current.getDuration() <= 40) {
                player.addEffect(new MobEffectInstance(ModEffects.CARAPACE, 600, 1, false, false, true));
            }
        } else if (player.hasEffect(ModEffects.CARAPACE)) {
            player.removeEffect(ModEffects.CARAPACE);
        }
    }

    /**
     * Scanner priority, higher = more valuable. The scanner highlights only the highest tier found around the player:
     * ancient debris > diamond > emerald > lumenite > gold > lapis > redstone > iron > copper > coal.
     */
    static int orePriority(BlockState state) {
        if (state.is(Blocks.ANCIENT_DEBRIS)) {
            return 100;
        }
        if (state.is(BlockTags.DIAMOND_ORES)) {
            return 90;
        }
        if (state.is(BlockTags.EMERALD_ORES)) {
            return 80;
        }
        if (state.is(ModBlocks.LUMENITE_ORE) || state.is(ModBlocks.DEEPSLATE_LUMENITE_ORE)) {
            return 70;
        }
        if (state.is(BlockTags.GOLD_ORES)) {
            return 60;
        }
        if (state.is(BlockTags.LAPIS_ORES)) {
            return 50;
        }
        if (state.is(BlockTags.REDSTONE_ORES)) {
            return 40;
        }
        if (state.is(BlockTags.IRON_ORES)) {
            return 30;
        }
        if (state.is(BlockTags.COPPER_ORES)) {
            return 20;
        }
        if (state.is(BlockTags.COAL_ORES)) {
            return 10;
        }
        return 0;
    }

    /** Outline colour (RGB) used for each tier. */
    static int oreColor(BlockState state) {
        int priority = orePriority(state);
        if (priority >= 100) {
            return 0xB5651D;
        } else if (priority >= 90) {
            return 0x4AEDD9;
        } else if (priority >= 80) {
            return 0x17DD62;
        } else if (priority >= 70) {
            return 0x9FF7E8;
        } else if (priority >= 60) {
            return 0xFCEE4B;
        } else if (priority >= 50) {
            return 0x345EC3;
        } else if (priority >= 40) {
            return 0xFF2020;
        } else if (priority >= 30) {
            return 0xD8AF93;
        } else if (priority >= 20) {
            return 0xE77C56;
        }
        return 0xAAAAAA;
    }

    // ---------- ore highlight: glowing block_display markers, visible through walls ----------

    private static void runCommand(MinecraftServer server, ServerLevel level, String command) {
        CommandSourceStack source = server.createCommandSourceStack().withLevel(level).withSuppressedOutput();
        server.getCommands().performPrefixedCommand(source, command);
    }

    private static boolean isActiveTag(Set<String> tags) {
        for (Highlight highlight : HIGHLIGHTS.values()) {
            if (tags.contains(highlight.tag())) {
                return true;
            }
        }
        return false;
    }

    /** Highlights the given ore blocks for 10 seconds. A new scan by the same player replaces the previous one. */
    static void highlight(ServerPlayer player, ServerLevel level, List<BlockPos> positions, Block block, int color) {
        MinecraftServer server = level.getServer();
        clearHighlight(server, player.getUUID());
        String tag = "dgl_" + (highlightCounter++);
        HIGHLIGHTS.put(player.getUUID(), new Highlight(tag, level, server.getTickCount() + HIGHLIGHT_TICKS));
        String name = BuiltInRegistries.BLOCK.getKey(block).toString();
        for (BlockPos pos : positions) {
            runCommand(server, level, "summon minecraft:block_display " + pos.getX() + ".0 " + pos.getY() + ".0 " + pos.getZ()
                    + ".0 {block_state:{Name:\"" + name + "\"},Glowing:1b,glow_color_override:" + color
                    + ",Tags:[\"" + HL_TAG + "\",\"" + tag + "\"]}");
        }
    }

    private static void clearHighlight(MinecraftServer server, UUID id) {
        Highlight old = HIGHLIGHTS.remove(id);
        if (old != null) {
            runCommand(server, old.level(), "kill @e[tag=" + old.tag() + "]");
        }
    }

    private static void tickHighlights(MinecraftServer server) {
        if (HIGHLIGHTS.isEmpty()) {
            return;
        }
        int now = server.getTickCount();
        for (UUID id : new java.util.ArrayList<>(HIGHLIGHTS.keySet())) {
            Highlight highlight = HIGHLIGHTS.get(id);
            if (highlight != null && now >= highlight.expireTick()) {
                clearHighlight(server, id);
            }
        }
    }

    static boolean isOre(BlockState state) {
        return state.is(BlockTags.COAL_ORES) || state.is(BlockTags.IRON_ORES) || state.is(BlockTags.GOLD_ORES)
                || state.is(BlockTags.COPPER_ORES) || state.is(BlockTags.DIAMOND_ORES) || state.is(BlockTags.LAPIS_ORES)
                || state.is(BlockTags.REDSTONE_ORES) || state.is(BlockTags.EMERALD_ORES)
                || state.is(ModBlocks.LUMENITE_ORE) || state.is(ModBlocks.DEEPSLATE_LUMENITE_ORE);
    }

    /** Sneak + lumenite pickaxe: the whole connected vein of the same ore breaks. */
    private static void mineVein(net.minecraft.world.level.Level level, Player player, BlockPos origin, BlockState state) {
        if (level.isClientSide || !(level instanceof ServerLevel serverLevel) || !player.isShiftKeyDown() || !isOre(state)) {
            return;
        }
        ItemStack tool = player.getMainHandItem();
        if (!(tool.getItem() instanceof LumenitePickaxe)) {
            return;
        }
        Block ore = state.getBlock();
        Set<BlockPos> seen = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        seen.add(origin);
        queue.add(origin);
        int broken = 0;
        while (!queue.isEmpty() && broken < MAX_VEIN && !tool.isEmpty()) {
            BlockPos current = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) {
                            continue;
                        }
                        BlockPos next = current.offset(dx, dy, dz);
                        if (!seen.add(next)) {
                            continue;
                        }
                        BlockState nextState = serverLevel.getBlockState(next);
                        if (nextState.getBlock() != ore || broken >= MAX_VEIN || tool.isEmpty()) {
                            continue;
                        }
                        BlockEntity entity = serverLevel.getBlockEntity(next);
                        Block.dropResources(nextState, serverLevel, next, entity, player, tool);
                        nextState.spawnAfterBreak(serverLevel, next, tool, true);
                        serverLevel.destroyBlock(next, false, player);
                        tool.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(InteractionHand.MAIN_HAND));
                        player.causeFoodExhaustion(0.005F);
                        broken++;
                        queue.add(next);
                    }
                }
            }
        }
    }
}
