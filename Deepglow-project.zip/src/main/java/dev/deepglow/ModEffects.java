package dev.deepglow;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;

public final class ModEffects {
    public static MobEffect LUMENITE_DECAY;
    public static MobEffect CARAPACE;

    private ModEffects() {
    }

    public static void init() {
        LUMENITE_DECAY = Registry.register(BuiltInRegistries.MOB_EFFECT, new ResourceLocation(DeepglowMod.MOD_ID, "lumenite_decay"),
                new DecayEffect());
        CARAPACE = Registry.register(BuiltInRegistries.MOB_EFFECT, new ResourceLocation(DeepglowMod.MOD_ID, "carapace"), new CarapaceEffect());
    }
}
