package dev.deepglow.entity;

import java.util.EnumSet;
import java.util.UUID;

import dev.deepglow.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;

/**
 * A slow, harmless cave slug. Its gel is edible and gives a short night vision.
 * Feed it an amethyst shard to tame it (1 in 3 tries): a tamed slug follows its owner and lays glow gel
 * every 2-3 minutes, like a chicken lays eggs.
 */
public class GlowSlug extends PathfinderMob {
    private UUID owner;
    private int gelTime;

    public GlowSlug(EntityType<? extends GlowSlug> type, Level level) {
        super(type, level);
        this.gelTime = nextGelTime();
    }

    private int nextGelTime() {
        return 2400 + this.random.nextInt(1201); // 2 to 3 minutes
    }

    public boolean isTame() {
        return owner != null;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return !isTame();
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (stack.is(Items.AMETHYST_SHARD) && !isTame()) {
            if (!this.level().isClientSide) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                if (this.random.nextInt(3) == 0) {
                    owner = player.getUUID();
                    this.setPersistenceRequired();
                    this.gelTime = nextGelTime();
                    ((ServerLevel) this.level()).sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 0.5D, this.getZ(), 7, 0.3D, 0.3D, 0.3D, 0.02D);
                    this.playSound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 1.2F);
                } else {
                    ((ServerLevel) this.level()).sendParticles(ParticleTypes.SMOKE, this.getX(), this.getY() + 0.5D, this.getZ(), 7, 0.3D, 0.3D, 0.3D, 0.02D);
                }
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!this.level().isClientSide && this.isAlive() && isTame() && --this.gelTime <= 0) {
            this.playSound(SoundEvents.SLIME_SQUISH_SMALL, 1.0F, (this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F);
            this.spawnAtLocation(ModItems.GLOW_GEL);
            this.gameEvent(GameEvent.ENTITY_PLACE);
            this.gelTime = nextGelTime();
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (owner != null) {
            tag.putUUID("Owner", owner);
        }
        tag.putInt("GelTime", gelTime);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
        if (tag.contains("GelTime")) {
            gelTime = tag.getInt("GelTime");
        }
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new PanicGoal(this, 1.5D));
        goalSelector.addGoal(2, new FollowOwnerGoal(this));
        goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 6.0F));
        goalSelector.addGoal(5, new RandomLookAroundGoal(this));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 6.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.12D);
    }

    public static boolean checkSpawn(EntityType<GlowSlug> type, ServerLevelAccessor level, MobSpawnType reason, BlockPos pos, RandomSource random) {
        BlockPos below = pos.below();
        BlockState floor = level.getBlockState(below);
        return pos.getY() < 45 && !level.canSeeSky(pos) && floor.isFaceSturdy(level, below, Direction.UP);
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.SLIME_HURT_SMALL;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.SLIME_DEATH_SMALL;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        playSound(SoundEvents.SLIME_SQUISH_SMALL, 0.1F, 1.0F);
    }

    /** A tamed slug trails its owner and hops after them when left far behind. */
    private static final class FollowOwnerGoal extends Goal {
        private final GlowSlug slug;
        private Player target;
        private int recalc;

        FollowOwnerGoal(GlowSlug slug) {
            this.slug = slug;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (!slug.isTame()) {
                return false;
            }
            Player owner = slug.level().getPlayerByUUID(slug.owner);
            if (owner == null || owner.isSpectator() || slug.distanceToSqr(owner) < 36.0D) {
                return false;
            }
            target = owner;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return target != null && target.isAlive() && slug.distanceToSqr(target) > 6.25D;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            target = null;
            slug.getNavigation().stop();
        }

        @Override
        public void tick() {
            slug.getLookControl().setLookAt(target, 10.0F, slug.getMaxHeadXRot());
            if (--recalc <= 0) {
                recalc = 10;
                if (slug.distanceToSqr(target) > 576.0D) {
                    slug.moveTo(target.getX() + 1.0D, target.getY(), target.getZ() + 1.0D, slug.getYRot(), slug.getXRot());
                    slug.getNavigation().stop();
                } else {
                    slug.getNavigation().moveTo(target, 1.4D);
                }
            }
        }
    }
}
