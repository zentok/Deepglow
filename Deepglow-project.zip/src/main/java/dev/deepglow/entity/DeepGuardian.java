package dev.deepglow.entity;

import java.util.EnumSet;
import java.util.UUID;

import org.joml.Vector3f;

import dev.deepglow.ModEffects;
import dev.deepglow.ModEntities;
import dev.deepglow.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * The guardian of the deep.
 * Attack: raises its arms (3 s) -> lumenite zone (r = 5) poisons players for 6 s -> slams the ground.
 * At half health it freezes for 4 s and then calls shardlings.
 * When killed it falls on its face; right click on the corpse pulls out the Heart of the Deep.
 */
public class DeepGuardian extends Monster {
    public static final int STATE_IDLE = 0;
    public static final int STATE_RAISE = 1;   // arms up + hold
    public static final int STATE_SLAM = 2;    // zone + strike
    public static final int STATE_FREEZE = 3;  // frozen before calling help
    public static final int STATE_DEAD = 10;

    public static final int RAISE_TICKS = 70;       // 10 raise + 60 hold = 3 s hanging
    public static final int SLAM_TICKS = 20;
    public static final int SLAM_HIT_TICK = 14;
    public static final int FREEZE_TICKS = 80;      // 4 s
    public static final int EXTRACT_TICKS = 50;
    public static final double ZONE_RADIUS = 5.0D;
    public static final int ZONE_EFFECT_TICKS = 120; // 6 s

    private static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(DeepGuardian.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> EXTRACT = SynchedEntityData.defineId(DeepGuardian.class, EntityDataSerializers.INT);

    private final ServerBossEvent bossEvent = new ServerBossEvent(this.getDisplayName(), BossEvent.BossBarColor.BLUE,
            BossEvent.BossBarOverlay.PROGRESS);
    private int slamCooldown = 80;
    private int stateStart;
    private boolean calledHelp;
    private boolean looted;
    private int lootedAge;
    private UUID extractor;

    public DeepGuardian(EntityType<? extends DeepGuardian> type, Level level) {
        super(type, level);
        this.xpReward = 60;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(STATE, STATE_IDLE);
        this.entityData.define(EXTRACT, 0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new RaiseGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, true));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 12.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 140.0D)
                .add(Attributes.ARMOR, 8.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.24D)
                .add(Attributes.ATTACK_DAMAGE, 9.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    public static boolean checkSpawn(EntityType<DeepGuardian> type, ServerLevelAccessor level, MobSpawnType reason, BlockPos pos, RandomSource random) {
        return pos.getY() < -10 && Monster.checkMonsterSpawnRules(type, level, reason, pos, random);
    }

    // ---------------------------------------------------------------- state (synced)

    public int getState() {
        return this.entityData.get(STATE);
    }

    private void setState(int state) {
        this.entityData.set(STATE, state);
        this.stateStart = this.tickCount;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (STATE.equals(key)) {
            this.stateStart = this.tickCount;
        }
    }

    /** Ticks since the current state began, smooth for rendering. */
    public float getStateTime(float ageInTicks) {
        return ageInTicks - this.stateStart;
    }

    public int getExtract() {
        return this.entityData.get(EXTRACT);
    }

    /** 0 -> 1 while the corpse is falling on its face. */
    public float getFallProgress(float partialTick) {
        if (getState() != STATE_DEAD) {
            return isDeadOrDying() ? 1.0F : 0.0F;
        }
        return Mth.clamp((getStateTime(this.tickCount + partialTick)) / 20.0F, 0.0F, 1.0F);
    }

    @Override
    protected boolean isImmobile() {
        int s = getState();
        return super.isImmobile() || s == STATE_RAISE || s == STATE_SLAM || s == STATE_FREEZE;
    }

    @Override
    public boolean isPushable() {
        return !isDeadOrDying() && super.isPushable();
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    // ---------------------------------------------------------------- tick

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.isAlive() && this.level() instanceof ServerLevel serverLevel) {
            if (slamCooldown > 0 && getState() == STATE_IDLE) {
                slamCooldown--;
            }
            bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
            stateTick(serverLevel);
        }
    }

    private void stateTick(ServerLevel level) {
        int state = getState();
        int t = this.tickCount - this.stateStart;
        LivingEntity target = this.getTarget();
        if (state == STATE_IDLE) {
            if (!calledHelp && this.getHealth() < this.getMaxHealth() * 0.5F) {
                calledHelp = true;
                this.getNavigation().stop();
                setState(STATE_FREEZE);
                level.playSound(null, this.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.HOSTILE, 3.0F, 0.4F);
            }
            return;
        }
        if (state == STATE_RAISE) {
            if (target != null) {
                this.lookAt(target, 30.0F, 30.0F);
            }
            if (t >= 10 && t % 10 == 0) {
                ring(level, 1.0D + (t - 10) * 0.06D, 10);
                level.playSound(null, this.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 2.0F, 0.5F + t * 0.01F);
            }
            if (t >= RAISE_TICKS) {
                setState(STATE_SLAM);
                level.playSound(null, this.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.HOSTILE, 2.5F, 0.6F);
            }
        } else if (state == STATE_SLAM) {
            // the lumenite zone: a glowing disc under the guardian that poisons players inside it
            zone(level);
            if (t % 4 == 0) {
                for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class, this.getBoundingBox().inflate(ZONE_RADIUS, 2.0D, ZONE_RADIUS),
                        p -> p.distanceToSqr(this.getX(), p.getY(), this.getZ()) <= ZONE_RADIUS * ZONE_RADIUS && !p.isSpectator() && !p.isCreative())) {
                    player.addEffect(new MobEffectInstance(ModEffects.LUMENITE_DECAY, ZONE_EFFECT_TICKS, 0), this);
                }
            }
            if (t == SLAM_HIT_TICK) {
                slam();
            }
            if (t >= SLAM_TICKS) {
                setState(STATE_IDLE);
                slamCooldown = 140;
            }
        } else if (state == STATE_FREEZE) {
            if (t % 5 == 0) {
                level.sendParticles(ParticleTypes.END_ROD, this.getX(), this.getY() + 1.5D, this.getZ(), 4, 0.9D, 1.2D, 0.9D, 0.02D);
            }
            if (t >= FREEZE_TICKS) {
                callHelp(level);
                setState(STATE_IDLE);
                slamCooldown = 60;
            }
        }
    }

    private void callHelp(ServerLevel level) {
        for (int i = 0; i < 3; i++) {
            Shardling shardling = ModEntities.SHARDLING.create(level);
            if (shardling != null) {
                double angle = i * (Math.PI * 2.0D / 3.0D) + this.random.nextDouble();
                shardling.moveTo(this.getX() + Math.cos(angle) * 3.0D, this.getY(), this.getZ() + Math.sin(angle) * 3.0D, this.getYRot(), 0.0F);
                level.addFreshEntity(shardling);
                level.sendParticles(ParticleTypes.END_ROD, shardling.getX(), shardling.getY() + 0.5D, shardling.getZ(), 12, 0.3D, 0.5D, 0.3D, 0.05D);
            }
        }
        level.playSound(null, this.blockPosition(), SoundEvents.AMETHYST_CLUSTER_BREAK, SoundSource.HOSTILE, 2.5F, 0.6F);
        level.playSound(null, this.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 1.0F, 0.6F);
    }

    private static final DustParticleOptions TEAL = new DustParticleOptions(new Vector3f(0.25F, 0.83F, 0.76F), 1.6F);

    private void ring(ServerLevel level, double radius, int points) {
        for (int i = 0; i < points; i++) {
            double a = i * (Math.PI * 2.0D / points);
            level.sendParticles(TEAL, this.getX() + Math.cos(a) * radius, this.getY() + 0.15D, this.getZ() + Math.sin(a) * radius, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
    }

    private void zone(ServerLevel level) {
        ring(level, ZONE_RADIUS, 40);
        for (int i = 0; i < 24; i++) {
            double a = this.random.nextDouble() * Math.PI * 2.0D;
            double r = Math.sqrt(this.random.nextDouble()) * ZONE_RADIUS;
            level.sendParticles(TEAL, this.getX() + Math.cos(a) * r, this.getY() + 0.1D, this.getZ() + Math.sin(a) * r, 1, 0.0D, 0.05D, 0.0D, 0.0D);
        }
    }

    /** Area damage around the guardian, called when the arms crash down. */
    private void slam() {
        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        for (LivingEntity entity : serverLevel.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(ZONE_RADIUS, 1.5D, ZONE_RADIUS),
                e -> e != this && !(e instanceof DeepGuardian) && !(e instanceof Shardling))) {
            entity.hurt(this.damageSources().mobAttack(this), 10.0F);
            Vec3 push = entity.position().subtract(this.position()).multiply(1.0D, 0.0D, 1.0D).normalize();
            entity.push(push.x * 0.9D, 0.7D, push.z * 0.9D);
            entity.hurtMarked = true;
        }
        serverLevel.sendParticles(ParticleTypes.END_ROD, this.getX(), this.getY() + 0.2D, this.getZ(), 60, 2.2D, 0.1D, 2.2D, 0.08D);
        serverLevel.playSound(null, this.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.0F, 0.7F);
        serverLevel.playSound(null, this.blockPosition(), SoundEvents.AMETHYST_BLOCK_BREAK, SoundSource.HOSTILE, 2.0F, 0.5F);
    }

    // ---------------------------------------------------------------- death: the corpse and the heart

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!this.level().isClientSide) {
            bossEvent.removeAllPlayers();
            setState(STATE_DEAD);
            this.level().playSound(null, this.blockPosition(), SoundEvents.IRON_GOLEM_DEATH, SoundSource.HOSTILE, 2.0F, 0.5F);
        }
    }

    /** The corpse stays until the heart is taken. */
    @Override
    protected void tickDeath() {
        if (this.level().isClientSide || !(this.level() instanceof ServerLevel level)) {
            return;
        }
        if (getState() != STATE_DEAD) {
            setState(STATE_DEAD);
        }
        int extract = getExtract();
        if (!looted && extract == 0) {
            if (this.tickCount % 10 == 0) {
                for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class, this.getBoundingBox().inflate(3.0D, 2.0D, 3.0D))) {
                    player.displayClientMessage(Component.translatable("deepglow.guardian.take_heart"), true);
                }
            }
        } else if (!looted) {
            extract++;
            this.entityData.set(EXTRACT, extract);
            level.sendParticles(TEAL, this.getX(), this.getY() + 1.0D, this.getZ(), 3, 0.4D, 0.2D, 0.4D, 0.0D);
            if (extract % 10 == 0) {
                level.playSound(null, this.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.HOSTILE, 2.0F, 0.5F + extract * 0.02F);
            }
            if (extract >= EXTRACT_TICKS) {
                giveHeart(level);
            }
        } else {
            lootedAge++;
            if (lootedAge >= 100) {
                level.broadcastEntityEvent(this, (byte) 60);
                this.remove(Entity.RemovalReason.KILLED);
            }
        }
    }

    private void giveHeart(ServerLevel level) {
        looted = true;
        this.entityData.set(EXTRACT, EXTRACT_TICKS);
        ItemStack heart = new ItemStack(ModItems.DEEP_HEART);
        Player player = extractor == null ? null : level.getPlayerByUUID(extractor);
        if (player == null || player.distanceToSqr(this) > 100.0D || !player.getInventory().add(heart)) {
            this.spawnAtLocation(heart, 1.5F);
        }
        level.sendParticles(ParticleTypes.END_ROD, this.getX(), this.getY() + 1.2D, this.getZ(), 40, 0.5D, 0.6D, 0.5D, 0.1D);
        level.playSound(null, this.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 2.0F, 0.8F);
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (this.isDeadOrDying()) {
            if (hand == InteractionHand.MAIN_HAND && !looted && getExtract() == 0) {
                if (!this.level().isClientSide) {
                    extractor = player.getUUID();
                    this.entityData.set(EXTRACT, 1);
                    this.level().playSound(null, this.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.HOSTILE, 2.0F, 0.6F);
                }
                return InteractionResult.sidedSuccess(this.level().isClientSide);
            }
            return InteractionResult.PASS;
        }
        return super.interact(player, hand);
    }

    // ---------------------------------------------------------------- misc

    @Override
    public void setCustomName(Component name) {
        super.setCustomName(name);
        bossEvent.setName(this.getDisplayName());
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        if (this.isAlive()) {
            bossEvent.addPlayer(player);
        }
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("CalledHelp", calledHelp);
        tag.putBoolean("HeartTaken", looted);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        calledHelp = tag.getBoolean("CalledHelp");
        looted = tag.getBoolean("HeartTaken");
        if (looted) {
            this.entityData.set(EXTRACT, EXTRACT_TICKS);
        }
        if (this.hasCustomName()) {
            bossEvent.setName(this.getDisplayName());
        }
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.IRON_GOLEM_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return null;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        playSound(SoundEvents.IRON_GOLEM_STEP, 1.0F, 0.7F);
    }

    /** Starts the "arms up, hang for 3 seconds, zone, slam" attack when a target is close. */
    private static final class RaiseGoal extends Goal {
        private final DeepGuardian guardian;

        RaiseGoal(DeepGuardian guardian) {
            this.guardian = guardian;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity target = guardian.getTarget();
            return target != null && guardian.getState() == STATE_IDLE && guardian.slamCooldown <= 0 && guardian.distanceToSqr(target) < 49.0D;
        }

        @Override
        public boolean canContinueToUse() {
            return false;
        }

        @Override
        public void start() {
            guardian.getNavigation().stop();
            guardian.setState(STATE_RAISE);
            guardian.playSound(SoundEvents.AMETHYST_BLOCK_RESONATE, 2.5F, 0.5F);
        }
    }
}
