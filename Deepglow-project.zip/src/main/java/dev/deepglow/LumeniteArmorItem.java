package dev.deepglow;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

public class LumeniteArmorItem extends ArmorItem {
    public LumeniteArmorItem(ArmorItem.Type type, Properties properties) {
        super(LumeniteArmorMaterial.INSTANCE, type, properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("deepglow.set_bonus").withStyle(ChatFormatting.AQUA));
    }

    /** True when the player wears all four lumenite pieces. */
    public static boolean hasFullSet(Player player) {
        for (ItemStack stack : player.getArmorSlots()) {
            if (!(stack.getItem() instanceof LumeniteArmorItem)) {
                return false;
            }
        }
        return true;
    }
}
