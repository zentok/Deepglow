package dev.deepglow;

import java.util.LinkedHashMap;
import java.util.Map;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.SwordItem;

public final class ModItems {
    public static final Map<String, Item> ALL = new LinkedHashMap<>();

    public static Item RAW_LUMENITE;
    public static Item LUMENITE_INGOT;
    public static Item LUMENITE_DUST;
    public static Item LUMENITE_SWORD;
    public static Item LUMENITE_PICKAXE;
    public static Item LUMENITE_AXE;
    public static Item LUMENITE_SHOVEL;
    public static Item LUMENITE_HOE;
    public static Item LUMENITE_HELMET;
    public static Item LUMENITE_CHESTPLATE;
    public static Item LUMENITE_LEGGINGS;
    public static Item LUMENITE_BOOTS;
    public static Item GLOW_BEETLE_SPAWN_EGG;

    private ModItems() {
    }

    private static Item reg(String name, Item item) {
        Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(DeepglowMod.MOD_ID, name), item);
        ALL.put(name, item);
        return item;
    }

    public static void init() {
        RAW_LUMENITE = reg("raw_lumenite", new Item(new Item.Properties()));
        LUMENITE_INGOT = reg("lumenite_ingot", new Item(new Item.Properties()));
        LUMENITE_DUST = reg("lumenite_dust", new Item(new Item.Properties()));
        LUMENITE_SWORD = reg("lumenite_sword", new SwordItem(LumeniteTier.INSTANCE, 3, -2.4F, new Item.Properties()));
        LUMENITE_PICKAXE = reg("lumenite_pickaxe", new LumenitePickaxe(new Item.Properties()));
        LUMENITE_AXE = reg("lumenite_axe", new AxeItem(LumeniteTier.INSTANCE, 5.0F, -3.0F, new Item.Properties()));
        LUMENITE_SHOVEL = reg("lumenite_shovel", new ShovelItem(LumeniteTier.INSTANCE, 1.5F, -3.0F, new Item.Properties()));
        LUMENITE_HOE = reg("lumenite_hoe", new HoeItem(LumeniteTier.INSTANCE, -3, 0.0F, new Item.Properties()));
        LUMENITE_HELMET = reg("lumenite_helmet", new LumeniteArmorItem(ArmorItem.Type.HELMET, new Item.Properties()));
        LUMENITE_CHESTPLATE = reg("lumenite_chestplate", new LumeniteArmorItem(ArmorItem.Type.CHESTPLATE, new Item.Properties()));
        LUMENITE_LEGGINGS = reg("lumenite_leggings", new LumeniteArmorItem(ArmorItem.Type.LEGGINGS, new Item.Properties()));
        LUMENITE_BOOTS = reg("lumenite_boots", new LumeniteArmorItem(ArmorItem.Type.BOOTS, new Item.Properties()));
    }

    /** Registered after the entity types exist. */
    public static void initEggs() {
        GLOW_BEETLE_SPAWN_EGG = reg("glow_beetle_spawn_egg",
                new SpawnEggItem(ModEntities.GLOW_BEETLE, 0x10262B, 0x3FD3C1, new Item.Properties()));
    }
}
