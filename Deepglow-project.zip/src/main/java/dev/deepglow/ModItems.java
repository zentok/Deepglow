package dev.deepglow;

import java.util.LinkedHashMap;
import java.util.Map;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SpawnEggItem;

public final class ModItems {
    public static final Map<String, Item> ALL = new LinkedHashMap<>();

    public static Item RAW_LUMENITE;
    public static Item LUMENITE_INGOT;
    public static Item LUMENITE_DUST;
    public static Item LUMENITE_SWORD;
    public static Item LUMENITE_PICKAXE;
    public static Item LUMENITE_AXE;
    public static Item LUMENITE_SHOVEL;
    public static Item LUMENITE_HOE;
    public static Item LUMENITE_HELMET;
    public static Item LUMENITE_CHESTPLATE;
    public static Item LUMENITE_LEGGINGS;
    public static Item LUMENITE_BOOTS;
    public static Item LUMENITE_SHARD;
    public static Item GLOW_GEL;
    public static Item DEEP_HEART;
    public static Item LUMENITE_SCANNER;
    public static Item GLOW_BEETLE_SPAWN_EGG;
    public static Item GLOW_SLUG_SPAWN_EGG;
    public static Item SHARDLING_SPAWN_EGG;
    public static Item DEEP_GUARDIAN_SPAWN_EGG;

    private ModItems() {
    }

    private static Item reg(String name, Item item) {
        Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(DeepglowMod.MOD_ID, name), item);
        ALL.put(name, item);
        return item;
    }

    public static void init() {
        RAW_LUMENITE = reg("raw_lumenite", new Item(new Item.Properties()));
        LUMENITE_INGOT = reg("lumenite_ingot", new Item(new Item.Properties()));
        LUMENITE_DUST = reg("lumenite_dust", new Item(new Item.Properties()));
        LUMENITE_SWORD = reg("lumenite_sword", new LumeniteSword(new Item.Properties()));
        LUMENITE_PICKAXE = reg("lumenite_pickaxe", new LumenitePickaxe(new Item.Properties()));
        LUMENITE_AXE = reg("lumenite_axe", new AxeItem(LumeniteTier.INSTANCE, 5.0F, -3.0F, new Item.Properties()));
        LUMENITE_SHOVEL = reg("lumenite_shovel", new ShovelItem(LumeniteTier.INSTANCE, 1.5F, -3.0F, new Item.Properties()));
        LUMENITE_HOE = reg("lumenite_hoe", new HoeItem(LumeniteTier.INSTANCE, -3, 0.0F, new Item.Properties()));
        LUMENITE_HELMET = reg("lumenite_helmet", new LumeniteArmorItem(ArmorItem.Type.HELMET, new Item.Properties()));
        LUMENITE_CHESTPLATE = reg("lumenite_chestplate", new LumeniteArmorItem(ArmorItem.Type.CHESTPLATE, new Item.Properties()));
        LUMENITE_LEGGINGS = reg("lumenite_leggings", new LumeniteArmorItem(ArmorItem.Type.LEGGINGS, new Item.Properties()));
        LUMENITE_BOOTS = reg("lumenite_boots", new LumeniteArmorItem(ArmorItem.Type.BOOTS, new Item.Properties()));
        LUMENITE_SHARD = reg("lumenite_shard", new Item(new Item.Properties()));
        GLOW_GEL = reg("glow_gel", new Item(new Item.Properties().food(new FoodProperties.Builder()
                .nutrition(2).saturationMod(0.3F).alwaysEat()
                .effect(new MobEffectInstance(MobEffects.NIGHT_VISION, 600, 0), 1.0F).build())));
        DEEP_HEART = reg("deep_heart", new Item(new Item.Properties().rarity(net.minecraft.world.item.Rarity.RARE).fireResistant()));
        LUMENITE_SCANNER = reg("lumenite_scanner", new LumeniteScanner(new Item.Properties().stacksTo(1).durability(120)));
    }

    /** Registered after the entity types exist. */
    public static void initEggs() {
        GLOW_BEETLE_SPAWN_EGG = reg("glow_beetle_spawn_egg",
                new SpawnEggItem(ModEntities.GLOW_BEETLE, 0x10262B, 0x3FD3C1, new Item.Properties()));
        GLOW_SLUG_SPAWN_EGG = reg("glow_slug_spawn_egg",
                new SpawnEggItem(ModEntities.GLOW_SLUG, 0x0F6F6A, 0x9FF7E8, new Item.Properties()));
        SHARDLING_SPAWN_EGG = reg("shardling_spawn_egg",
                new SpawnEggItem(ModEntities.SHARDLING, 0x2E3442, 0x3FD3C1, new Item.Properties()));
        DEEP_GUARDIAN_SPAWN_EGG = reg("deep_guardian_spawn_egg",
                new SpawnEggItem(ModEntities.DEEP_GUARDIAN, 0x2B3340, 0x9FF7E8, new Item.Properties()));
    }
}
