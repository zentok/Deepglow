package dev.deepglow;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeMap;

/** "Deep carapace": gives absorption hearts (like the Absorption effect) while the full beetle armor set is worn. */
public class CarapaceEffect extends MobEffect {
    public CarapaceEffect() {
        super(MobEffectCategory.BENEFICIAL, 0x3FD3C1);
    }

    @Override
    public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributes, int amplifier) {
        entity.setAbsorptionAmount(entity.getAbsorptionAmount() - 4.0F * (amplifier + 1));
        super.removeAttributeModifiers(entity, attributes, amplifier);
    }

    @Override
    public void addAttributeModifiers(LivingEntity entity, AttributeMap attributes, int amplifier) {
        entity.setAbsorptionAmount(entity.getAbsorptionAmount() + 4.0F * (amplifier + 1));
        super.addAttributeModifiers(entity, attributes, amplifier);
    }
}
