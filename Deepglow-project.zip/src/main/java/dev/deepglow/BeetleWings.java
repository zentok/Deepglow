package dev.deepglow;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/**
 * Beetle chestplate wings. Gliding uses the chestplate's normal durability (1 point per second of flight),
 * exactly like an elytra, so Unbreaking, Mending and the durability HUD all work on it. Like an elytra, the
 * wings stop working when only 1 point of durability is left.
 */
public final class BeetleWings {
    public static final ResourceLocation OPEN_PACKET = new ResourceLocation(DeepglowMod.MOD_ID, "open_wings");

    private BeetleWings() {
    }

    public static boolean isWings(ItemStack stack) {
        return stack.is(ModItems.LUMENITE_CHESTPLATE);
    }

    public static boolean canGlide(LivingEntity entity) {
        ItemStack chest = entity.getItemBySlot(EquipmentSlot.CHEST);
        return isWings(chest) && chest.getDamageValue() < chest.getMaxDamage() - 1;
    }

    /** Called every tick while gliding (both sides). Returns whether the wings still carry the player. */
    public static boolean tickGlide(LivingEntity entity, boolean tickWings) {
        if (!canGlide(entity)) {
            return false;
        }
        if (tickWings && !entity.level().isClientSide && (entity.getFallFlyingTicks() + 1) % 20 == 0) {
            entity.getItemBySlot(EquipmentSlot.CHEST).hurtAndBreak(1, entity, e -> e.broadcastBreakEvent(EquipmentSlot.CHEST));
        }
        return true;
    }
}
