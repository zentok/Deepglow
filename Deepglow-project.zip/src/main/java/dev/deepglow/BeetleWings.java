package dev.deepglow;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/**
 * The second durability of the beetle chestplate: the wings.
 * Armor durability is the normal item damage; wing durability lives in the item's NBT ("DeepWings"),
 * drops by 1 for every second of gliding, slowly grows back on the ground and is repaired together with the armor.
 */
public final class BeetleWings {
    public static final int MAX = 432;
    public static final ResourceLocation OPEN_PACKET = new ResourceLocation(DeepglowMod.MOD_ID, "open_wings");
    private static final String KEY = "DeepWings";
    private static final String LAST_DAMAGE = "DeepWingsDmg";

    private BeetleWings() {
    }

    public static boolean isWings(ItemStack stack) {
        return stack.is(ModItems.LUMENITE_CHESTPLATE);
    }

    public static int get(ItemStack stack) {
        if (stack.getTag() == null || !stack.getTag().contains(KEY)) {
            return MAX;
        }
        return Math.max(0, Math.min(MAX, stack.getTag().getInt(KEY)));
    }

    public static void set(ItemStack stack, int value) {
        stack.getOrCreateTag().putInt(KEY, Math.max(0, Math.min(MAX, value)));
    }

    public static boolean canGlide(LivingEntity entity) {
        ItemStack chest = entity.getItemBySlot(EquipmentSlot.CHEST);
        return isWings(chest) && get(chest) > 0;
    }

    /** Called every tick while gliding (both sides). Returns whether the wings still carry the player. */
    public static boolean tickGlide(LivingEntity entity, boolean tickWings) {
        ItemStack chest = entity.getItemBySlot(EquipmentSlot.CHEST);
        if (!isWings(chest) || get(chest) <= 0) {
            return false;
        }
        if (tickWings && !entity.level().isClientSide && (entity.getFallFlyingTicks() + 1) % 20 == 0) {
            int left = get(chest) - 1;
            set(chest, left);
            if (entity instanceof ServerPlayer player) {
                player.displayClientMessage(Component.translatable("deepglow.wings.left", left, MAX), true);
            }
        }
        return true;
    }

    /**
     * Called every couple of seconds. The wings heal slowly on the ground, and every point of armor durability that gets
     * repaired (Mending, anvil, crafting) heals the wings by the same amount.
     */
    public static void regen(LivingEntity entity) {
        ItemStack chest = entity.getItemBySlot(EquipmentSlot.CHEST);
        if (!isWings(chest)) {
            return;
        }
        int damage = chest.getDamageValue();
        int last = chest.getTag() != null && chest.getTag().contains(LAST_DAMAGE) ? chest.getTag().getInt(LAST_DAMAGE) : damage;
        if (damage < last) {
            set(chest, get(chest) + (last - damage));
        } else if (get(chest) < MAX && !entity.isFallFlying()) {
            set(chest, get(chest) + 1);
        }
        chest.getOrCreateTag().putInt(LAST_DAMAGE, damage);
    }
}
