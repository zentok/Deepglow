package dev.deepglow;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Right click: looks for ore within 7 blocks of the player in every direction and highlights (through walls, for 10 s)
 * all ore blocks of the MOST VALUABLE kind it finds. See {@link ModEvents#orePriority(BlockState)} for the order.
 */
public class LumeniteScanner extends Item {
    public static final int RADIUS = 7;
    private static final int MAX_HIGHLIGHTS = 24;

    public LumeniteScanner(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }
        if (!level.isClientSide && level instanceof ServerLevel serverLevel && player instanceof ServerPlayer serverPlayer) {
            BlockPos origin = player.blockPosition();
            int bestPriority = 0;
            List<BlockPos> found = new ArrayList<>();
            BlockState sample = null;
            BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
            for (int dx = -RADIUS; dx <= RADIUS; dx++) {
                for (int dy = -RADIUS; dy <= RADIUS; dy++) {
                    for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                        if (dx * dx + dy * dy + dz * dz > RADIUS * RADIUS) {
                            continue;
                        }
                        cursor.set(origin.getX() + dx, origin.getY() + dy, origin.getZ() + dz);
                        BlockState state = level.getBlockState(cursor);
                        int priority = ModEvents.orePriority(state);
                        if (priority <= 0 || priority < bestPriority) {
                            continue;
                        }
                        if (priority > bestPriority) {
                            bestPriority = priority;
                            found.clear();
                            sample = state;
                        }
                        found.add(cursor.immutable());
                    }
                }
            }
            if (found.isEmpty()) {
                player.displayClientMessage(Component.translatable("deepglow.scanner.none", RADIUS).withStyle(ChatFormatting.GRAY), true);
                serverLevel.playSound(null, origin, SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0F, 0.6F);
            } else {
                found.sort(Comparator.comparingDouble(pos -> pos.distSqr(origin)));
                int total = found.size();
                List<BlockPos> shown = found.size() > MAX_HIGHLIGHTS ? found.subList(0, MAX_HIGHLIGHTS) : found;
                ModEvents.highlight(serverPlayer, serverLevel, shown, sample.getBlock(), ModEvents.oreColor(sample));
                player.displayClientMessage(Component.translatable("deepglow.scanner.found", sample.getBlock().getName(), total)
                        .withStyle(ChatFormatting.AQUA), true);
                serverLevel.playSound(null, origin, SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0F, 1.4F);
            }
            serverLevel.sendParticles(ParticleTypes.GLOW, player.getX(), player.getY() + 1.0D, player.getZ(), 14, 0.6D, 0.6D, 0.6D, 0.02D);
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            player.getCooldowns().addCooldown(this, 60);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("deepglow.scanner_hint", RADIUS).withStyle(ChatFormatting.AQUA));
    }
}
