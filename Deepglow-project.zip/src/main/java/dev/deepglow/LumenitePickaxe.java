package dev.deepglow;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

public class LumenitePickaxe extends PickaxeItem {
    public LumenitePickaxe(Properties properties) {
        super(LumeniteTier.INSTANCE, 1, -2.8F, properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("deepglow.vein_hint").withStyle(ChatFormatting.AQUA));
    }
}
