package dev.deepglow.client;

import dev.deepglow.DeepglowMod;
import dev.deepglow.entity.GlowBeetle;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class GlowBeetleModel extends EntityModel<GlowBeetle> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(DeepglowMod.MOD_ID, "glow_beetle"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart antennaL;
    private final ModelPart antennaR;
    private final ModelPart[] legs = new ModelPart[6];

    public GlowBeetleModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.antennaL = head.getChild("antenna_l");
        this.antennaR = head.getChild("antenna_r");
        for (int i = 0; i < 6; i++) {
            legs[i] = root.getChild("leg" + i);
        }
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = mesh.getRoot();
        p.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -3.0F, -3.0F, 6.0F, 3.0F, 6.0F),
                PartPose.offset(0.0F, 21.0F, 0.0F));
        p.addOrReplaceChild("abdomen", CubeListBuilder.create().texOffs(0, 10).addBox(-3.0F, -4.0F, 0.0F, 6.0F, 4.0F, 7.0F),
                PartPose.offset(0.0F, 21.0F, 3.0F));
        PartDefinition headPart = p.addOrReplaceChild("head", CubeListBuilder.create().texOffs(28, 0).addBox(-2.0F, -2.0F, -3.0F, 4.0F, 3.0F, 3.0F),
                PartPose.offset(0.0F, 20.0F, -3.0F));
        headPart.addOrReplaceChild("antenna_l", CubeListBuilder.create().texOffs(44, 0).addBox(-0.5F, -0.5F, -4.0F, 1.0F, 1.0F, 4.0F),
                PartPose.offsetAndRotation(1.2F, -1.2F, -2.6F, -0.5F, 0.35F, 0.0F));
        headPart.addOrReplaceChild("antenna_r", CubeListBuilder.create().texOffs(44, 6).addBox(-0.5F, -0.5F, -4.0F, 1.0F, 1.0F, 4.0F),
                PartPose.offsetAndRotation(-1.2F, -1.2F, -2.6F, -0.5F, -0.35F, 0.0F));
        float[] zs = {-2.0F, 0.0F, 2.0F};
        for (int i = 0; i < 6; i++) {
            boolean left = i % 2 == 0;
            float x = left ? 3.0F : -3.0F;
            p.addOrReplaceChild("leg" + i, CubeListBuilder.create().texOffs(0, 22).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F),
                    PartPose.offsetAndRotation(x, 21.0F, zs[i / 2], 0.0F, 0.0F, left ? -0.5F : 0.5F));
        }
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(GlowBeetle entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * ((float) Math.PI / 180F) * 0.6F;
        head.xRot = headPitch * ((float) Math.PI / 180F) * 0.5F;
        float wiggle = Mth.sin(ageInTicks * 0.15F) * 0.12F;
        antennaL.yRot = 0.35F + wiggle;
        antennaR.yRot = -0.35F - wiggle;
        for (int i = 0; i < 6; i++) {
            float phase = (i % 2 == 0 ? 0.0F : (float) Math.PI) + (i / 2) * 1.2F;
            float swing = Mth.cos(limbSwing * 2.0F + phase);
            float amp = Math.min(1.0F, limbSwingAmount * 2.5F);
            legs[i].xRot = swing * 0.9F * amp;
            legs[i].yRot = Mth.sin(limbSwing * 2.0F + phase) * 0.5F * amp;
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buffer, int light, int overlay, float r, float g, float b, float a) {
        root.render(pose, buffer, light, overlay, r, g, b, a);
    }
}
