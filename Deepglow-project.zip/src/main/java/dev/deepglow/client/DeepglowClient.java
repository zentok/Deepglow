package dev.deepglow.client;

import dev.deepglow.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class DeepglowClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(GlowBeetleModel.LAYER, GlowBeetleModel::createBodyLayer);
        EntityRendererRegistry.register(ModEntities.GLOW_BEETLE, GlowBeetleRenderer::new);
    }
}
