package dev.deepglow.client;

import dev.deepglow.ModEntities;
import dev.deepglow.ModItems;
import net.fabricmc.fabric.api.client.rendering.v1.ArmorRenderer;
import net.fabricmc.api.ClientModInitializer;
import dev.deepglow.ModBlocks;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.renderer.RenderType;

public class DeepglowClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(GlowBeetleModel.LAYER, GlowBeetleModel::createBodyLayer);
        EntityRendererRegistry.register(ModEntities.GLOW_BEETLE, GlowBeetleRenderer::new);
        EntityModelLayerRegistry.registerModelLayer(GlowSlugModel.LAYER, GlowSlugModel::createBodyLayer);
        EntityRendererRegistry.register(ModEntities.GLOW_SLUG, GlowSlugRenderer::new);
        EntityModelLayerRegistry.registerModelLayer(ShardlingModel.LAYER, ShardlingModel::createBodyLayer);
        EntityRendererRegistry.register(ModEntities.SHARDLING, ShardlingRenderer::new);
        EntityModelLayerRegistry.registerModelLayer(DeepGuardianModel.LAYER, DeepGuardianModel::createBodyLayer);
        EntityRendererRegistry.register(ModEntities.DEEP_GUARDIAN, DeepGuardianRenderer::new);
        EntityModelLayerRegistry.registerModelLayer(BeetleArmorModel.OUTER, BeetleArmorModel::createOuterLayer);
        EntityModelLayerRegistry.registerModelLayer(BeetleArmorModel.INNER, BeetleArmorModel::createInnerLayer);
        ArmorRenderer.register(new BeetleArmorRenderer(), ModItems.LUMENITE_HELMET, ModItems.LUMENITE_CHESTPLATE, ModItems.LUMENITE_LEGGINGS,
                ModItems.LUMENITE_BOOTS);
        // double jump in the air -> open the beetle wings
        final boolean[] wasJumping = {false};
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(client -> {
            net.minecraft.client.player.LocalPlayer player = client.player;
            if (player == null) {
                return;
            }
            boolean jumping = player.input.jumping;
            if (jumping && !wasJumping[0] && !player.onGround() && !player.isFallFlying() && !player.isInWater() && !player.getAbilities().flying
                    && !player.hasEffect(net.minecraft.world.effect.MobEffects.LEVITATION) && dev.deepglow.BeetleWings.canGlide(player)) {
                player.startFallFlying();
                net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.send(dev.deepglow.BeetleWings.OPEN_PACKET,
                        net.fabricmc.fabric.api.networking.v1.PacketByteBufs.create());
            }
            wasJumping[0] = jumping;
        });
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.LUMENITE_CRYSTAL, RenderType.cutout());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.GLOWCAP, RenderType.cutout());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.LUMENITE_GLASS, RenderType.translucent());
    }
}
