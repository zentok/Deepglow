package dev.deepglow.client;

import dev.deepglow.DeepglowMod;
import dev.deepglow.entity.Shardling;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

public class ShardlingRenderer extends MobRenderer<Shardling, ShardlingModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(DeepglowMod.MOD_ID, "textures/entity/shardling.png");
    private static final RenderType GLOW = RenderType.eyes(new ResourceLocation(DeepglowMod.MOD_ID, "textures/entity/shardling_glow.png"));

    public ShardlingRenderer(EntityRendererProvider.Context context) {
        super(context, new ShardlingModel(context.bakeLayer(ShardlingModel.LAYER)), 0.4F);
        addLayer(new EyesLayer<Shardling, ShardlingModel>(this) {
            @Override
            public RenderType renderType() {
                return GLOW;
            }
        });
    }

    @Override
    public ResourceLocation getTextureLocation(Shardling entity) {
        return TEXTURE;
    }
}
