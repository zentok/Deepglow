package dev.deepglow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import dev.deepglow.DeepglowMod;
import net.fabricmc.fabric.api.client.rendering.v1.ArmorRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/** Draws the lumenite armor as a glowing beetle carapace instead of the vanilla armor layer. */
public class BeetleArmorRenderer implements ArmorRenderer {
    private static final ResourceLocation OUTER = tex("beetle_armor_1");
    private static final ResourceLocation OUTER_GLOW = tex("beetle_armor_1_glow");
    private static final ResourceLocation OUTER_WINGS = tex("beetle_armor_1_wings");
    private static final ResourceLocation OUTER_WINGS_GLOW = tex("beetle_armor_1_wings_glow");
    private static final ResourceLocation INNER = tex("beetle_armor_2");
    private static final ResourceLocation INNER_GLOW = tex("beetle_armor_2_glow");

    private static BeetleArmorModel outerModel;
    private static BeetleArmorModel innerModel;

    private static ResourceLocation tex(String name) {
        return new ResourceLocation(DeepglowMod.MOD_ID, "textures/models/armor/" + name + ".png");
    }

    @Override
    public void render(PoseStack matrices, MultiBufferSource buffers, ItemStack stack, LivingEntity entity, EquipmentSlot slot, int light,
            HumanoidModel<LivingEntity> contextModel) {
        if (outerModel == null) {
            outerModel = new BeetleArmorModel(Minecraft.getInstance().getEntityModels().bakeLayer(BeetleArmorModel.OUTER));
            innerModel = new BeetleArmorModel(Minecraft.getInstance().getEntityModels().bakeLayer(BeetleArmorModel.INNER));
        }
        boolean legs = slot == EquipmentSlot.LEGS;
        BeetleArmorModel model = legs ? innerModel : outerModel;
        contextModel.copyPropertiesTo(model);
        model.setSlot(slot);
        float open = slot == EquipmentSlot.CHEST && entity.isFallFlying() ? Math.min(1.0F, (entity.getFallFlyingTicks() + 1) / 6.0F) : 0.0F;
        model.setWings(open);
        // open wings: the shells switch to the glowing membrane texture
        boolean membrane = open > 0.3F;
        ResourceLocation bodyTex = legs ? INNER : (membrane ? OUTER_WINGS : OUTER);
        ResourceLocation glowTex = legs ? INNER_GLOW : (membrane ? OUTER_WINGS_GLOW : OUTER_GLOW);
        VertexConsumer body = ItemRenderer.getArmorFoilBuffer(buffers, RenderType.armorCutoutNoCull(bodyTex), false, stack.hasFoil());
        model.renderToBuffer(matrices, body, light, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
        VertexConsumer glow = buffers.getBuffer(RenderType.eyes(glowTex));
        model.renderToBuffer(matrices, glow, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
    }
}
