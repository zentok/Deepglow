package dev.deepglow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.deepglow.DeepglowMod;
import dev.deepglow.entity.DeepGuardian;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Hunched crystal brute: huge torso, long arms, small head, crystal spine. Poses mirror tools/viewer (3D preview). */
public class DeepGuardianModel extends EntityModel<DeepGuardian> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(DeepglowMod.MOD_ID, "deep_guardian"), "main");
    private static final float HEART_Z = 5.0F;

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart body;
    private final ModelPart heart;
    private final ModelPart armR;
    private final ModelPart armL;
    private final ModelPart legR;
    private final ModelPart legL;

    public DeepGuardianModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.heart = body.getChild("heart");
        this.armR = root.getChild("arm_r");
        this.armL = root.getChild("arm_l");
        this.legR = root.getChild("leg_r");
        this.legL = root.getChild("leg_l");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition pd_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offsetAndRotation(0.0F, 8.0F, -4.0F, 0.2F, 0.0F, 0.0F));
        PartDefinition pd_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 16).addBox(-9.0F, 0.0F, -5.0F, 18.0F, 12.0F, 10.0F),
                PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.3F, 0.0F, 0.0F));
        PartDefinition pd_heart = pd_body.addOrReplaceChild("heart", CubeListBuilder.create().texOffs(56, 40).addBox(-3.0F, -3.0F, 0.0F, 6.0F, 5.0F, 3.0F),
                PartPose.offsetAndRotation(0.0F, 9.5F, 5.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition pd_spine1 = pd_body.addOrReplaceChild("spine1", CubeListBuilder.create().texOffs(0, 64).addBox(-1.5F, -6.0F, -1.5F, 3.0F, 6.0F, 3.0F),
                PartPose.offsetAndRotation(0.0F, -0.5F, 3.5F, -0.9F, 0.0F, 0.0F));
        PartDefinition pd_spine2 = pd_body.addOrReplaceChild("spine2", CubeListBuilder.create().texOffs(12, 64).addBox(-1.5F, -8.0F, -1.5F, 3.0F, 8.0F, 3.0F),
                PartPose.offsetAndRotation(0.0F, 2.0F, 5.0F, -0.75F, 0.0F, 0.0F));
        PartDefinition pd_spine3 = pd_body.addOrReplaceChild("spine3", CubeListBuilder.create().texOffs(24, 64).addBox(-1.5F, -9.0F, -1.5F, 3.0F, 9.0F, 3.0F),
                PartPose.offsetAndRotation(0.0F, 5.0F, 5.0F, -0.6F, 0.0F, 0.0F));
        PartDefinition pd_spine4 = pd_body.addOrReplaceChild("spine4", CubeListBuilder.create().texOffs(36, 64).addBox(-1.5F, -6.0F, -1.5F, 3.0F, 6.0F, 3.0F),
                PartPose.offsetAndRotation(-4.5F, 7.5F, 5.0F, -0.5F, 0.0F, -0.3F));
        PartDefinition pd_spine5 = pd_body.addOrReplaceChild("spine5", CubeListBuilder.create().texOffs(48, 64).addBox(-1.5F, -6.0F, -1.5F, 3.0F, 6.0F, 3.0F),
                PartPose.offsetAndRotation(4.5F, 7.5F, 5.0F, -0.5F, 0.0F, 0.3F));
        PartDefinition pd_shoulder_l = pd_body.addOrReplaceChild("shoulder_l", CubeListBuilder.create().texOffs(0, 80).addBox(-2.0F, -9.0F, -2.0F, 4.0F, 9.0F, 4.0F),
                PartPose.offsetAndRotation(-9.0F, 1.0F, 0.0F, 0.0F, 0.0F, -0.5F));
        PartDefinition pd_shoulder_r = pd_body.addOrReplaceChild("shoulder_r", CubeListBuilder.create().texOffs(16, 80).addBox(-2.0F, -9.0F, -2.0F, 4.0F, 9.0F, 4.0F),
                PartPose.offsetAndRotation(9.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.5F));
        PartDefinition pd_shoulder2_l = pd_body.addOrReplaceChild("shoulder2_l", CubeListBuilder.create().texOffs(32, 80).addBox(-1.5F, -6.0F, -1.5F, 3.0F, 6.0F, 3.0F),
                PartPose.offsetAndRotation(-7.0F, 0.0F, 3.0F, -0.5F, 0.0F, -0.7F));
        PartDefinition pd_shoulder2_r = pd_body.addOrReplaceChild("shoulder2_r", CubeListBuilder.create().texOffs(44, 80).addBox(-1.5F, -6.0F, -1.5F, 3.0F, 6.0F, 3.0F),
                PartPose.offsetAndRotation(7.0F, 0.0F, 3.0F, -0.5F, 0.0F, 0.7F));
        PartDefinition pd_arm_r = root.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(64, 0).addBox(-3.5F, -2.0F, -3.5F, 7.0F, 17.0F, 7.0F),
                PartPose.offsetAndRotation(-12.5F, 9.0F, 0.0F, 0.0F, 0.0F, 0.1F));
        PartDefinition pd_arm_l = root.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(92, 0).addBox(-3.5F, -2.0F, -3.5F, 7.0F, 17.0F, 7.0F),
                PartPose.offsetAndRotation(12.5F, 9.0F, 0.0F, 0.0F, 0.0F, -0.1F));
        PartDefinition pd_leg_r = root.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(0, 40).addBox(-3.5F, 0.0F, -3.5F, 7.0F, 8.0F, 7.0F),
                PartPose.offsetAndRotation(-4.5F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition pd_leg_l = root.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(28, 40).addBox(-3.5F, 0.0F, -3.5F, 7.0F, 8.0F, 7.0F),
                PartPose.offsetAndRotation(4.5F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 128, 128);
    }

    private static float ease(float v) {
        v = Mth.clamp(v, 0.0F, 1.0F);
        return v * v * (3.0F - 2.0F * v);
    }

    @Override
    public void setupAnim(DeepGuardian entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float deg = (float) Math.PI / 180F;
        float partial = ageInTicks - entity.tickCount;
        float t = entity.getStateTime(ageInTicks);
        int state = entity.getState();

        // rest pose
        body.y = 6.0F;
        body.xRot = 0.3F + Mth.sin(ageInTicks * 0.08F) * 0.02F;
        head.xRot = 0.2F + headPitch * deg * 0.5F;
        head.yRot = netHeadYaw * deg * 0.7F;
        head.zRot = 0.0F;
        float swing = limbSwing * 0.5F;
        legR.xRot = Mth.cos(swing) * 1.0F * limbSwingAmount;
        legL.xRot = Mth.cos(swing + (float) Math.PI) * 1.0F * limbSwingAmount;
        armR.xRot = Mth.cos(swing + (float) Math.PI) * 0.7F * limbSwingAmount - 0.1F;
        armL.xRot = Mth.cos(swing) * 0.7F * limbSwingAmount - 0.1F;
        armR.zRot = 0.1F;
        armL.zRot = -0.1F;
        if (entity.isAggressive() && state == DeepGuardian.STATE_IDLE) {
            armR.xRot -= 0.5F + Mth.sin(ageInTicks * 0.2F) * 0.06F;
            armL.xRot -= 0.5F - Mth.sin(ageInTicks * 0.2F) * 0.06F;
        }
        heart.z = HEART_Z;
        heart.x = 0.0F;
        heart.visible = true;

        if (entity.isDeadOrDying()) {
            float f = entity.getFallProgress(partial);
            body.xRot = 0.1F;
            head.xRot = 0.5F;
            armR.xRot = -3.0F * f;
            armL.xRot = -3.0F * f;
            armR.zRot = 0.55F * f;
            armL.zRot = -0.55F * f;
            legR.xRot = 0.0F;
            legL.xRot = 0.0F;
            int ex = entity.getExtract();
            if (ex >= DeepGuardian.EXTRACT_TICKS) {
                heart.visible = false;
            } else if (ex > 0) {
                float p = (ex + partial) / DeepGuardian.EXTRACT_TICKS;
                heart.x = Mth.sin(ageInTicks * 2.2F) * 0.6F * Math.min(1.0F, p * 3.0F);
                heart.z = HEART_Z + 7.0F * ease((p - 0.4F) / 0.6F);
            }
        } else if (state == DeepGuardian.STATE_RAISE || state == DeepGuardian.STATE_SLAM) {
            float up = state == DeepGuardian.STATE_RAISE ? ease(t / 10.0F) : 1.0F;
            float down = state == DeepGuardian.STATE_SLAM ? ease((t - 10.0F) / 4.0F) : 0.0F;
            float recover = state == DeepGuardian.STATE_SLAM ? ease((t - 14.0F) / 6.0F) : 0.0F;
            float arms = Mth.lerp(down, -3.1F * up, 0.2F);
            float shake = state == DeepGuardian.STATE_RAISE && t > 10.0F ? Mth.sin(ageInTicks * 1.7F) * 0.03F : 0.0F;
            armR.xRot = arms + shake;
            armL.xRot = arms - shake;
            armR.zRot = Mth.lerp(down, 0.4F * up, 0.1F);
            armL.zRot = -armR.zRot;
            body.xRot = Mth.lerp(down, 0.3F - 0.45F * up, 0.8F);
            body.xRot = Mth.lerp(recover, body.xRot, 0.3F);
            head.xRot = Mth.lerp(down, -0.35F * up, 0.5F);
            legR.xRot = -0.25F * up;
            legL.xRot = 0.25F * up;
        } else if (state == DeepGuardian.STATE_FREEZE) {
            float k = ease(t / 8.0F);
            body.xRot = 0.3F + 0.5F * k;
            body.y = 6.0F + 2.0F * k;
            head.xRot = 0.2F + 0.3F * k;
            head.zRot = Mth.sin(ageInTicks * 1.3F) * 0.05F * k;
            armR.xRot = -0.5F * k;
            armL.xRot = -0.5F * k;
            armR.zRot = 0.1F + 0.7F * k;
            armL.zRot = -0.1F - 0.7F * k;
            legR.xRot = -0.5F * k;
            legL.xRot = -0.5F * k;
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buffer, int light, int overlay, float r, float g, float b, float a) {
        root.render(pose, buffer, light, overlay, r, g, b, a);
    }
}
