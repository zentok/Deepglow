package dev.deepglow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.deepglow.DeepglowMod;
import dev.deepglow.entity.Shardling;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class ShardlingModel extends EntityModel<Shardling> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(DeepglowMod.MOD_ID, "shardling"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart armR;
    private final ModelPart armL;
    private final ModelPart legR;
    private final ModelPart legL;

    public ShardlingModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.armR = root.getChild("arm_r");
        this.armL = root.getChild("arm_l");
        this.legR = root.getChild("leg_r");
        this.legL = root.getChild("leg_l");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition pd_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -5.0F, -3.0F, 6.0F, 5.0F, 6.0F),
                PartPose.offsetAndRotation(0.0F, 11.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition pd_crystal_top = pd_head.addOrReplaceChild("crystal_top", CubeListBuilder.create().texOffs(24, 0).addBox(-1.0F, -4.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                PartPose.offsetAndRotation(0.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition pd_crystal_l = pd_head.addOrReplaceChild("crystal_l", CubeListBuilder.create().texOffs(32, 0).addBox(-1.0F, -3.0F, -1.0F, 2.0F, 3.0F, 2.0F),
                PartPose.offsetAndRotation(-2.0F, -4.0F, 1.0F, 0.0F, 0.0F, -0.45F));
        PartDefinition pd_crystal_r = pd_head.addOrReplaceChild("crystal_r", CubeListBuilder.create().texOffs(40, 0).addBox(-1.0F, -3.0F, -1.0F, 2.0F, 3.0F, 2.0F),
                PartPose.offsetAndRotation(2.0F, -4.0F, 1.0F, 0.0F, 0.0F, 0.45F));
        PartDefinition pd_body = root.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 11).addBox(-3.0F, 0.0F, -2.0F, 6.0F, 7.0F, 4.0F),
                PartPose.offsetAndRotation(0.0F, 11.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition pd_back1 = pd_body.addOrReplaceChild("back1", CubeListBuilder.create().texOffs(24, 11).addBox(-1.0F, -5.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offsetAndRotation(-1.5F, 3.0F, 2.5F, 0.5F, 0.0F, 0.0F));
        PartDefinition pd_back2 = pd_body.addOrReplaceChild("back2", CubeListBuilder.create().texOffs(32, 11).addBox(-1.0F, -5.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offsetAndRotation(1.5F, 5.0F, 2.5F, 0.5F, 0.0F, 0.0F));
        PartDefinition pd_arm_r = root.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(48, 0).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                PartPose.offsetAndRotation(-4.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition pd_arm_l = root.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(56, 0).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                PartPose.offsetAndRotation(4.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition pd_leg_r = root.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(48, 8).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F),
                PartPose.offsetAndRotation(-1.5F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition pd_leg_l = root.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(48, 17).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 6.0F, 3.0F),
                PartPose.offsetAndRotation(1.5F, 18.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(Shardling entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        head.xRot = headPitch * ((float) Math.PI / 180F);
        float swing = limbSwing * 0.6662F;
        legR.xRot = Mth.cos(swing) * 1.3F * limbSwingAmount;
        legL.xRot = Mth.cos(swing + (float) Math.PI) * 1.3F * limbSwingAmount;
        armR.xRot = Mth.cos(swing + (float) Math.PI) * 0.9F * limbSwingAmount;
        armL.xRot = Mth.cos(swing) * 0.9F * limbSwingAmount;
        armR.zRot = 0.0F;
        armL.zRot = 0.0F;
        if (entity.isAggressive()) {
            float bob = Mth.sin(ageInTicks * 0.3F) * 0.08F;
            armR.xRot = -1.45F + bob;
            armL.xRot = -1.45F - bob;
        } else {
            armR.zRot = 0.06F + Mth.cos(ageInTicks * 0.09F) * 0.04F;
            armL.zRot = -0.06F - Mth.cos(ageInTicks * 0.09F) * 0.04F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buffer, int light, int overlay, float r, float g, float b, float a) {
        root.render(pose, buffer, light, overlay, r, g, b, a);
    }
}
