package dev.deepglow.client;

import dev.deepglow.DeepglowMod;
import dev.deepglow.entity.GlowBeetle;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

public class GlowBeetleRenderer extends MobRenderer<GlowBeetle, GlowBeetleModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(DeepglowMod.MOD_ID, "textures/entity/glow_beetle.png");
    private static final RenderType GLOW = RenderType.eyes(new ResourceLocation(DeepglowMod.MOD_ID, "textures/entity/glow_beetle_glow.png"));

    public GlowBeetleRenderer(EntityRendererProvider.Context context) {
        super(context, new GlowBeetleModel(context.bakeLayer(GlowBeetleModel.LAYER)), 0.3F);
        addLayer(new EyesLayer<GlowBeetle, GlowBeetleModel>(this) {
            @Override
            public RenderType renderType() {
                return GLOW;
            }
        });
    }

    @Override
    public ResourceLocation getTextureLocation(GlowBeetle entity) {
        return TEXTURE;
    }
}
