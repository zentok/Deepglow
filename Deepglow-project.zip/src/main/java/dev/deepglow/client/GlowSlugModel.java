package dev.deepglow.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.deepglow.DeepglowMod;
import dev.deepglow.entity.GlowSlug;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class GlowSlugModel extends EntityModel<GlowSlug> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation(DeepglowMod.MOD_ID, "glow_slug"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart stalkL;
    private final ModelPart stalkR;
    private final ModelPart seg1;
    private final ModelPart seg2;
    private final ModelPart seg3;

    public GlowSlugModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.stalkL = head.getChild("stalk_l");
        this.stalkR = head.getChild("stalk_r");
        this.seg1 = root.getChild("seg1");
        this.seg2 = root.getChild("seg2");
        this.seg3 = root.getChild("seg3");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition pd_head = root.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -3.0F, -2.0F, 4.0F, 3.0F, 4.0F),
                PartPose.offsetAndRotation(0.0F, 24.0F, -6.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition pd_stalk_l = pd_head.addOrReplaceChild("stalk_l", CubeListBuilder.create().texOffs(16, 0).addBox(-0.5F, -3.0F, -0.5F, 1.0F, 3.0F, 1.0F),
                PartPose.offsetAndRotation(1.2F, -3.0F, -1.0F, -0.3F, 0.0F, 0.3F));
        PartDefinition pd_stalk_r = pd_head.addOrReplaceChild("stalk_r", CubeListBuilder.create().texOffs(16, 4).addBox(-0.5F, -3.0F, -0.5F, 1.0F, 3.0F, 1.0F),
                PartPose.offsetAndRotation(-1.2F, -3.0F, -1.0F, -0.3F, 0.0F, -0.3F));
        PartDefinition pd_tip_l = pd_stalk_l.addOrReplaceChild("tip_l", CubeListBuilder.create().texOffs(20, 0).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offsetAndRotation(0.0F, -3.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition pd_tip_r = pd_stalk_r.addOrReplaceChild("tip_r", CubeListBuilder.create().texOffs(20, 4).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offsetAndRotation(0.0F, -3.0F, 0.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition pd_seg1 = root.addOrReplaceChild("seg1", CubeListBuilder.create().texOffs(0, 8).addBox(-3.0F, -4.0F, -3.0F, 6.0F, 4.0F, 6.0F),
                PartPose.offsetAndRotation(0.0F, 24.0F, -1.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition pd_seg2 = root.addOrReplaceChild("seg2", CubeListBuilder.create().texOffs(28, 8).addBox(-2.0F, -3.0F, -2.0F, 4.0F, 3.0F, 4.0F),
                PartPose.offsetAndRotation(0.0F, 24.0F, 4.0F, 0.0F, 0.0F, 0.0F));
        PartDefinition pd_seg3 = root.addOrReplaceChild("seg3", CubeListBuilder.create().texOffs(0, 20).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offsetAndRotation(0.0F, 24.0F, 7.0F, 0.0F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(GlowSlug entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        float t = ageInTicks * 0.1F;
        float amp = 0.6F + Math.min(1.0F, limbSwingAmount * 3.0F) * 1.6F;
        head.yRot = netHeadYaw * ((float) Math.PI / 180F) * 0.5F;
        head.xRot = headPitch * ((float) Math.PI / 180F) * 0.3F;
        head.y = 24.0F - Math.max(0.0F, Mth.sin(limbSwing * 1.4F + t) * 0.5F * amp);
        seg1.y = 24.0F - Math.max(0.0F, Mth.sin(limbSwing * 1.4F - 0.9F + t) * 0.5F * amp);
        seg2.y = 24.0F - Math.max(0.0F, Mth.sin(limbSwing * 1.4F - 1.8F + t) * 0.5F * amp);
        seg3.y = 24.0F - Math.max(0.0F, Mth.sin(limbSwing * 1.4F - 2.7F + t) * 0.5F * amp);
        seg2.yRot = Mth.sin(limbSwing * 1.4F - 1.8F + t) * 0.08F * amp;
        seg3.yRot = Mth.sin(limbSwing * 1.4F - 2.7F + t) * 0.16F * amp;
        stalkL.xRot = -0.3F + Mth.sin(ageInTicks * 0.17F) * 0.15F;
        stalkR.xRot = -0.3F + Mth.sin(ageInTicks * 0.17F + 1.3F) * 0.15F;
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buffer, int light, int overlay, float r, float g, float b, float a) {
        root.render(pose, buffer, light, overlay, r, g, b, a);
    }
}
