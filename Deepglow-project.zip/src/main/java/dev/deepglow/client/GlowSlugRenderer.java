package dev.deepglow.client;

import dev.deepglow.DeepglowMod;
import dev.deepglow.entity.GlowSlug;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

public class GlowSlugRenderer extends MobRenderer<GlowSlug, GlowSlugModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(DeepglowMod.MOD_ID, "textures/entity/glow_slug.png");
    private static final RenderType GLOW = RenderType.eyes(new ResourceLocation(DeepglowMod.MOD_ID, "textures/entity/glow_slug_glow.png"));

    public GlowSlugRenderer(EntityRendererProvider.Context context) {
        super(context, new GlowSlugModel(context.bakeLayer(GlowSlugModel.LAYER)), 0.3F);
        addLayer(new EyesLayer<GlowSlug, GlowSlugModel>(this) {
            @Override
            public RenderType renderType() {
                return GLOW;
            }
        });
    }

    @Override
    public ResourceLocation getTextureLocation(GlowSlug entity) {
        return TEXTURE;
    }
}
