package dev.deepglow.client;

import dev.deepglow.DeepglowMod;
import dev.deepglow.entity.DeepGuardian;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

public class DeepGuardianRenderer extends MobRenderer<DeepGuardian, DeepGuardianModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(DeepglowMod.MOD_ID, "textures/entity/deep_guardian.png");
    private static final RenderType GLOW = RenderType.eyes(new ResourceLocation(DeepglowMod.MOD_ID, "textures/entity/deep_guardian_glow.png"));

    public DeepGuardianRenderer(EntityRendererProvider.Context context) {
        super(context, new DeepGuardianModel(context.bakeLayer(DeepGuardianModel.LAYER)), 1.3F);
        addLayer(new EyesLayer<DeepGuardian, DeepGuardianModel>(this) {
            @Override
            public RenderType renderType() {
                return GLOW;
            }
        });
    }

    @Override
    public ResourceLocation getTextureLocation(DeepGuardian entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(DeepGuardian entity, PoseStack pose, float partialTick) {
        pose.scale(1.5F, 1.5F, 1.5F);
    }

    @Override
    protected void setupRotations(DeepGuardian entity, PoseStack pose, float bob, float yBodyRot, float partialTick) {
        super.setupRotations(entity, pose, bob, yBodyRot, partialTick);
        if (entity.isDeadOrDying()) {
            // falls on its face; forward is local -Z here
            float f = entity.getFallProgress(partialTick);
            pose.translate(0.0D, 0.5D * f, 0.0D);
            pose.mulPose(Axis.XP.rotationDegrees(-90.0F * f));
        }
    }
}
