package dev.deepglow;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Every hit puts Lumenite Decay on the target (wither-like damage over time; a player's hearts turn teal). */
public class LumeniteSword extends SwordItem {
    private static final int DECAY_TICKS = 160;

    public LumeniteSword(Properties properties) {
        super(LumeniteTier.INSTANCE, 3, -2.4F, properties);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addEffect(new MobEffectInstance(ModEffects.LUMENITE_DECAY, DECAY_TICKS, 0), attacker);
        return super.hurtEnemy(stack, target, attacker);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("deepglow.sword_hint").withStyle(ChatFormatting.AQUA));
    }
}
