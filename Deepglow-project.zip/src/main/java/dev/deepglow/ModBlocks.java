package dev.deepglow;

import java.util.LinkedHashMap;
import java.util.Map;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

public final class ModBlocks {
    public static final Map<String, Block> ALL = new LinkedHashMap<>();

    public static Block LUMENITE_ORE;
    public static Block DEEPSLATE_LUMENITE_ORE;
    public static Block RAW_LUMENITE_BLOCK;
    public static Block LUMENITE_BLOCK;
    public static Block POLISHED_LUMENITE;
    public static Block LUMENITE_BRICKS;
    public static Block LUMENITE_BRICKS_SLAB;
    public static Block LUMENITE_BRICKS_STAIRS;
    public static Block LUMENITE_LAMP;

    private ModBlocks() {
    }

    private static Block reg(String name, Block block) {
        ResourceLocation id = new ResourceLocation(DeepglowMod.MOD_ID, name);
        Registry.register(BuiltInRegistries.BLOCK, id, block);
        Registry.register(BuiltInRegistries.ITEM, id, new BlockItem(block, new Item.Properties()));
        ALL.put(name, block);
        return block;
    }

    public static void init() {
        LUMENITE_ORE = reg("lumenite_ore", new DropExperienceBlock(BlockBehaviour.Properties.of()
                .mapColor(MapColor.STONE).strength(3.5F, 3.5F).requiresCorrectToolForDrops()
                .sound(SoundType.STONE).lightLevel(state -> 6), UniformInt.of(3, 7)));
        DEEPSLATE_LUMENITE_ORE = reg("deepslate_lumenite_ore", new DropExperienceBlock(BlockBehaviour.Properties.of()
                .mapColor(MapColor.DEEPSLATE).strength(4.5F, 3.5F).requiresCorrectToolForDrops()
                .sound(SoundType.DEEPSLATE).lightLevel(state -> 6), UniformInt.of(3, 7)));
        RAW_LUMENITE_BLOCK = reg("raw_lumenite_block", new Block(BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_CYAN).strength(5.0F, 6.0F).requiresCorrectToolForDrops().sound(SoundType.STONE)));
        LUMENITE_BLOCK = reg("lumenite_block", new Block(BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_CYAN).strength(5.0F, 6.0F).requiresCorrectToolForDrops()
                .sound(SoundType.AMETHYST).lightLevel(state -> 7)));
        POLISHED_LUMENITE = reg("polished_lumenite", new Block(BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_CYAN).strength(3.0F, 6.0F).requiresCorrectToolForDrops().sound(SoundType.STONE)));
        LUMENITE_BRICKS = reg("lumenite_bricks", new Block(BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_CYAN).strength(3.0F, 6.0F).requiresCorrectToolForDrops().sound(SoundType.STONE)));
        LUMENITE_BRICKS_SLAB = reg("lumenite_bricks_slab", new SlabBlock(BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_CYAN).strength(3.0F, 6.0F).requiresCorrectToolForDrops().sound(SoundType.STONE)));
        LUMENITE_BRICKS_STAIRS = reg("lumenite_bricks_stairs", new StairBlock(LUMENITE_BRICKS.defaultBlockState(),
                BlockBehaviour.Properties.copy(LUMENITE_BRICKS)));
        LUMENITE_LAMP = reg("lumenite_lamp", new Block(BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_CYAN).strength(0.6F, 1.0F).sound(SoundType.AMETHYST).lightLevel(state -> 15)));
    }
}
