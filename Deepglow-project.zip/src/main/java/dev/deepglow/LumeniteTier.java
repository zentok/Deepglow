package dev.deepglow;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

/** Tool material of lumenite: a little better than iron, between iron and diamond in feel. */
public final class LumeniteTier implements Tier {
    public static final LumeniteTier INSTANCE = new LumeniteTier();

    private LumeniteTier() {
    }

    @Override
    public int getUses() {
        return 1100;
    }

    @Override
    public float getSpeed() {
        return 8.0F;
    }

    @Override
    public float getAttackDamageBonus() {
        return 2.5F;
    }

    @Override
    public int getLevel() {
        return 3;
    }

    @Override
    public int getEnchantmentValue() {
        return 16;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.of(ModItems.LUMENITE_INGOT);
    }
}
