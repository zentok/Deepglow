package dev.deepglow;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;

/** Lumenite Decay: works like Wither (damage over time that ignores armor); hearts turn teal for the player. */
public class DecayEffect extends MobEffect {
    public DecayEffect() {
        super(MobEffectCategory.HARMFUL, 0x3FD3C1);
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        entity.hurt(entity.damageSources().wither(), 1.0F);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        int interval = 40 >> amplifier;
        return interval <= 0 || duration % interval == 0;
    }
}
