package dev.deepglow;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

public class DeepglowMod implements ModInitializer {
    public static final String MOD_ID = "deepglow";

    @Override
    public void onInitialize() {
        ModEffects.init();
        ModBlocks.init();
        ModItems.init();
        ModEntities.init();
        ModItems.initEggs();
        ModEvents.register();

        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Decoration.UNDERGROUND_ORES,
                ResourceKey.create(Registries.PLACED_FEATURE, new ResourceLocation(MOD_ID, "lumenite_ore")));
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Decoration.UNDERGROUND_STRUCTURES,
                ResourceKey.create(Registries.PLACED_FEATURE, new ResourceLocation(MOD_ID, "lumenite_geode")));
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Decoration.VEGETAL_DECORATION,
                ResourceKey.create(Registries.PLACED_FEATURE, new ResourceLocation(MOD_ID, "glowcap_patch")));
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), MobCategory.CREATURE, ModEntities.GLOW_BEETLE, 14, 2, 4);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), MobCategory.CREATURE, ModEntities.GLOW_SLUG, 10, 1, 3);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), MobCategory.MONSTER, ModEntities.SHARDLING, 12, 1, 3);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), MobCategory.MONSTER, ModEntities.DEEP_GUARDIAN, 1, 1, 1);

        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, new ResourceLocation(MOD_ID, "main"),
                FabricItemGroup.builder()
                        .title(Component.translatable("itemGroup.deepglow.main"))
                        .icon(() -> new ItemStack(ModItems.LUMENITE_INGOT))
                        .displayItems((params, output) -> {
                            ModBlocks.ALL.values().forEach(block -> output.accept(block.asItem()));
                            ModItems.ALL.values().forEach(output::accept);
                        })
                        .build());
    }
}
