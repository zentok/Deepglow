package dev.deepglow;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

public final class LumeniteArmorMaterial implements ArmorMaterial {
    public static final LumeniteArmorMaterial INSTANCE = new LumeniteArmorMaterial();
    private static final int[] BASE_DURABILITY = {13, 15, 16, 11};
    private static final int[] DEFENSE = {3, 6, 7, 3};

    private LumeniteArmorMaterial() {
    }

    private static int slotIndex(ArmorItem.Type type) {
        switch (type) {
            case BOOTS:
                return 0;
            case LEGGINGS:
                return 1;
            case CHESTPLATE:
                return 2;
            default:
                return 3;
        }
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return BASE_DURABILITY[slotIndex(type)] * 30;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return DEFENSE[slotIndex(type)];
    }

    @Override
    public int getEnchantmentValue() {
        return 16;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_DIAMOND;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.of(ModItems.LUMENITE_INGOT);
    }

    @Override
    public String getName() {
        return "lumenite";
    }

    @Override
    public float getToughness() {
        return 1.0F;
    }

    @Override
    public float getKnockbackResistance() {
        return 0.0F;
    }
}
