package dev.deepglow.mixin;

import dev.deepglow.DeepglowMod;
import dev.deepglow.ModEffects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** While the player has Lumenite Decay the health hearts are drawn in the colour of the Heart of the Deep. */
@Mixin(Gui.class)
public abstract class GuiMixin {
    private static final ResourceLocation DEEPGLOW_DECAY_HEARTS = new ResourceLocation(DeepglowMod.MOD_ID, "textures/gui/decay_hearts.png");

    @Shadow
    @Final
    private Minecraft minecraft;

    @Inject(method = "renderHeart(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/gui/Gui$HeartType;IIIZZ)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void deepglow$decayHeart(GuiGraphics graphics, @Coerce Object heartType, int x, int y, int yOffset,
                                     boolean highlight, boolean half, CallbackInfo ci) {
        Player player = this.minecraft.player;
        if (player == null || ModEffects.LUMENITE_DECAY == null || !player.hasEffect(ModEffects.LUMENITE_DECAY)) {
            return;
        }
        int type = ((Enum<?>) heartType).ordinal();
        if (type == 0 || type == 4) {
            return; // keep the empty container and golden absorption hearts as they are
        }
        int u = ((half ? 1 : 0) + (highlight ? 2 : 0)) * 9;
        graphics.blit(DEEPGLOW_DECAY_HEARTS, x, y, (float) u, (float) yOffset, 9, 9, 36, 54);
        ci.cancel();
    }
}
