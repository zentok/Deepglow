package dev.deepglow;

import dev.deepglow.entity.DeepGuardian;
import dev.deepglow.entity.GlowBeetle;
import dev.deepglow.entity.GlowSlug;
import dev.deepglow.entity.Shardling;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;

public final class ModEntities {
    public static EntityType<GlowBeetle> GLOW_BEETLE;
    public static EntityType<GlowSlug> GLOW_SLUG;
    public static EntityType<Shardling> SHARDLING;
    public static EntityType<DeepGuardian> DEEP_GUARDIAN;

    private ModEntities() {
    }

    public static void init() {
        GLOW_BEETLE = Registry.register(BuiltInRegistries.ENTITY_TYPE, new ResourceLocation(DeepglowMod.MOD_ID, "glow_beetle"),
                FabricEntityTypeBuilder.createMob()
                        .<GlowBeetle>entityFactory(GlowBeetle::new)
                        .spawnGroup(MobCategory.CREATURE)
                        .dimensions(EntityDimensions.fixed(0.7F, 0.45F))
                        .spawnRestriction(SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, GlowBeetle::checkSpawn)
                        .defaultAttributes(GlowBeetle::createAttributes)
                        .build());

        GLOW_SLUG = Registry.register(BuiltInRegistries.ENTITY_TYPE, new ResourceLocation(DeepglowMod.MOD_ID, "glow_slug"),
                FabricEntityTypeBuilder.createMob()
                        .<GlowSlug>entityFactory(GlowSlug::new)
                        .spawnGroup(MobCategory.CREATURE)
                        .dimensions(EntityDimensions.fixed(0.5F, 0.35F))
                        .spawnRestriction(SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, GlowSlug::checkSpawn)
                        .defaultAttributes(GlowSlug::createAttributes)
                        .build());
        SHARDLING = Registry.register(BuiltInRegistries.ENTITY_TYPE, new ResourceLocation(DeepglowMod.MOD_ID, "shardling"),
                FabricEntityTypeBuilder.createMob()
                        .<Shardling>entityFactory(Shardling::new)
                        .spawnGroup(MobCategory.MONSTER)
                        .dimensions(EntityDimensions.fixed(0.6F, 1.15F))
                        .spawnRestriction(SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Shardling::checkSpawn)
                        .defaultAttributes(Shardling::createAttributes)
                        .build());
        DEEP_GUARDIAN = Registry.register(BuiltInRegistries.ENTITY_TYPE, new ResourceLocation(DeepglowMod.MOD_ID, "deep_guardian"),
                FabricEntityTypeBuilder.createMob()
                        .<DeepGuardian>entityFactory(DeepGuardian::new)
                        .spawnGroup(MobCategory.MONSTER)
                        .dimensions(EntityDimensions.fixed(2.4F, 2.9F))
                        .spawnRestriction(SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, DeepGuardian::checkSpawn)
                        .defaultAttributes(DeepGuardian::createAttributes)
                        .build());
    }
}
