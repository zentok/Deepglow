package dev.deepglow;

import dev.deepglow.entity.GlowBeetle;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;

public final class ModEntities {
    public static EntityType<GlowBeetle> GLOW_BEETLE;

    private ModEntities() {
    }

    public static void init() {
        GLOW_BEETLE = Registry.register(BuiltInRegistries.ENTITY_TYPE, new ResourceLocation(DeepglowMod.MOD_ID, "glow_beetle"),
                FabricEntityTypeBuilder.createMob()
                        .<GlowBeetle>entityFactory(GlowBeetle::new)
                        .spawnGroup(MobCategory.CREATURE)
                        .dimensions(EntityDimensions.fixed(0.7F, 0.45F))
                        .spawnRestriction(SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, GlowBeetle::checkSpawn)
                        .defaultAttributes(GlowBeetle::createAttributes)
                        .build());
    }
}
